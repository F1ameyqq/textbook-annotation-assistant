# Q16＋三阅读任务 C01 v3 内容复用包

B 内容已就绪，当前真实内容缺口为空。三阅读任务共用一份8片段材料；下一节Q16有独立本地目录身份，不与第一课时Q16合并。

## 本次问题与修正

独审发现旧Q16题文漏掉三个印刷小问标签。已直接核看viewer15及对应裁片，只在q16-task1/2/3的首个plain run补回“（1）”“（2）”“（3）”。SOURCE-CHANGES.json逐项列出原文、新文、完整runs、来源SHA、bbox、PNG及RGB SHA。其余正文、公式、答案、六个null空白、坐标和裁片不变。11公式诊断不增加答案片段。

四题答案关系均为显式B模型来源确认的SELECTED；阅读任务1保留左下到右上的顺序，任务2/3保留答案行的x=228分界，任务3含“答案不唯一”和完整图形。独立人工/A所有者/平台验收未声明，也不据缺少人签将普通题统一列为内容失败。

## 真正的范围限制

C01 PRE_APPLY仍为HOLD，只涉及正式平台policy采纳及整页/全章目标覆盖。Source/structure/answer_matching为PASS。未伪造nativeID，未访问网站，没有新OCR。旧HOLD及UNRESOLVED保留在delivery/history/v2；原始ZIP也以原字节保存在history/original-v2.zip。

## 离线重放

已安装Python 3.12、Pillow 12.3.0、Pydantic 2.14.1的环境运行：

```powershell
python -B tools/replay_lesson_c01_b.py --package . --out FRESH_EXTERNAL_DIRECTORY
```

输出目录须全新且位于包外。重放核全部文件清单，重建50个交付文件并逐字节比较，然后独立校验并通过固定A24的50文件源码调用load_bundle(..., verify_assets=True)，比较完整对象。不会安装依赖或调用旧包里的运行时。

```powershell
python -B -m unittest discover -s tests -v
```

查看index.html与SOURCE-REVISION.md。review和sidecar为内部证据格式，公共交换仍是固定C01。最终QA独审和根会话集成/push另行记录。
