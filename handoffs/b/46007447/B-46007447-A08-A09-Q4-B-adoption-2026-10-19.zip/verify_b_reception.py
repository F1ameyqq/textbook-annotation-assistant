"""B read-only comparison of fixed A08/A09 archives. No targets/plans/execution."""
from pathlib import Path
import argparse
import hashlib
import json
import sys
import zipfile

p = argparse.ArgumentParser(description=__doc__)
p.add_argument('--source', type=Path, required=True)
p.add_argument('--tree', type=Path, required=True)
p.add_argument('--b-package', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
args = p.parse_args()
root = args.source.resolve()
checks = []
sha = lambda b: hashlib.sha256(b).hexdigest()
canonical = lambda x: json.dumps(x, ensure_ascii=False, sort_keys=True, separators=(',', ':'), allow_nan=False).encode('utf-8')
digest = lambda x: sha(canonical({k:v for k,v in x.items() if k != 'content_hash'}))
read = lambda name: json.loads((root/name).read_bytes())
ref = lambda a: {k:a[k] for k in ('artifact_id','revision','kind','content_hash')}

def check(name, condition):
    checks.append({'check': name, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(name)

manifest = read('docs/handoff/a08-a09-q4/manifest.json')
tree_data = json.loads(args.tree.read_bytes())
check('complete fixed Git tree', not tree_data['truncated'])
tree = {v['path']:v for v in tree_data['tree'] if v['type']=='blob'}
members = manifest['source_members'] + manifest['generated_members']
for m in members:
    raw = (root/m['path']).read_bytes()
    oid = hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()
    check('publication ' + m['path'], len(raw)==m['bytes'] and sha(raw)==m['sha256'] and oid==m['blob_oid']==tree[m['path']]['sha'])
sources = [name for name in tree if name.startswith('src/')]
for name in sources:
    raw=(root/name).read_bytes()
    check('source pin '+name, len(raw)==tree[name]['size'] and hashlib.sha1(b'blob '+str(len(raw)).encode()+b'\0'+raw).hexdigest()==tree[name]['sha'])
history_count=0
for name in manifest['frozen_delivery_manifests']:
    frozen=read(name)
    for m in frozen.get('members',frozen.get('entries')):
        raw=(root/m['path']).read_bytes()
        check('frozen '+name+'/'+m['path'],len(raw)==m['bytes'] and sha(raw)==m['sha256'])
        history_count+=1

package_raw=args.b_package.read_bytes()
check('B input ZIP identity', sha(package_raw)=='b646fad9008e03e79a3dddfb4ead912d7ceadefbcee331c2e2af2415abf6f673')
with zipfile.ZipFile(args.b_package) as z:
    batch=json.loads(z.read('staging/batch.json'))
    case_raw=z.read('staging/cases/q4-first-lesson.json')
    case=json.loads(case_raw)
    source_bytes={a['asset_id']:z.read('staging/'+a['path']) for a in batch['assets']}
    source_descriptors={a['asset_id']:a for a in batch['assets']}
proposal_raw=(root/'docs/reviews/q4-first-lesson/proposal.json').read_bytes()
proposal=json.loads(proposal_raw)
approval_raw=(root/'docs/approvals/A09-Q4-offline-business-approval.json').read_bytes()
approval=json.loads(approval_raw)
policy=read('config/policies/a09-q4-offline-v1.json')
check('proposal exact original and source case',sha(proposal_raw)=='e8146fc7a4fe2e16c1fc1194d49de1caa1fe029dd6907848bbaa6c9082dc0bbe' and proposal['source_case_snapshot']==case and proposal['case_member_sha256']==sha(case_raw))
check('approval fixed raw bytes',sha(approval_raw)=='5c73af50262f6bd7e48e2b0d46148026c1c3a953d1ee93c8262e356733d99010')
check('approval proposal and PDF hashes',approval['approved_proposal']['sha256']==sha(proposal_raw) and approval['approved_proposal']['review_pdf_sha256']==sha((root/approval['approved_proposal']['review_pdf_path']).read_bytes()))
check('B original proposal flags remain false',all(value is False for value in proposal['approvals'].values()) and case['decision']=='HOLD' and not case['joint_accepted'] and not case['human_verified'])
check('correct stable question/answer/section',case['question_id']==approval['question_id']==proposal['question_id']=='q-260d10c51f2b7c16fb6fefb5' and case['answer_id']==approval['answer_id']==proposal['answer_id']=='a-92c4d2164ab878c8e6d4c88d' and approval['section_path']==case['section_path'])
check('new authorization only for exact B input',approval['b_commit']==proposal['source_b_commit']=='a76e5a925fec76f20818dfdefa4145aa132ec8a8' and approval['input_zip_sha256']==sha(package_raw) and approval['case_member_sha256']==sha(case_raw))
check('limited offline policy and no platform',approval['allowed_use']=='A_SIDE_OFFLINE_POSITIVE_SIMULATION_ONLY' and approval['business_approval_granted'] is True and all(approval[k] is False for k in ('platform_operations_authorized_by_this_record','original_b_artifact_mutation_authorized','independent_human_visual_review_proven')) and policy['execution_mode']=='SIMULATED' and policy['allowed_operations']==['CREATE_FRAMES'])
check('policy binds new Q4 approval/proposal',policy['approval_sha256']==sha(approval_raw) and policy['proposal_sha256']==sha(proposal_raw))
expected=proposal['proposed_regions_in_physical_order']
check('four exact approved regions',expected==approval['approved_regions_in_physical_order'] and [r['bbox'] for r in expected]==[[334,975,581,1077],[100,1118,592,1193],[99,1202,220,1235],[324,239,342,257]])
check('four exact types/roles', [r['content_type'] for r in expected]==['image','text','text','text'] and [r['proposed_role'] for r in expected]==['Q','Q','Q','A'])
check('13 from original 4.13 span',case['answer_snapshot']['text']=='13' and case['answer_snapshot']['fragments'][0]['raw_text']=='4.13' and case['answer_snapshot']['fragments'][0]['text_span']==[2,4])
raw_stem=''.join(f['text'] for f in case['question_snapshot']['fragments'][:2])[2:]
check('normalized stem retains B semantic text',expected[1]['text'].replace(' ','')==raw_stem.replace(' ',''))
check('blank is explicit representation, no invented explanation',expected[2]['text']=='____ cm.' and expected[3]['text']=='13' and expected[0]['text'] is None and proposal['content_proposal']['explanation'] is None and approval['approved_scope_policy']['no_options_or_explanation_frames'] is True)
check('new single-Q4 scope, not old Q1 exclusions',approval['approved_scope_policy']['scope']=='THIS_FIXED_SINGLE_QUESTION_ONLY' and approval['approved_scope_policy']['q1_authorization_transferred'] is False and approval['approved_scope_policy']['other_three_cases']=='HOLD' and approval['approved_scope_policy']['whole_page_or_chapter_coverage_approved'] is False)

sys.path.insert(0,str(root/'src'))
from annotation.source.b_batch import receive_package
from annotation.contracts import load_bundle
rx=receive_package(args.b_package)
check('A08 actual readonly reception remains HOLD',rx['status']=='RECEIVED_READONLY_HOLD' and rx['summary']=={'cases':4,'assets':3,'question_answer_candidates':1,'answer_evidence_only':3,'hold_cases':4})
check('A08 full external objects not claimed',rx['external_objects']['complete_G_Check_plan_objects_loaded'] is False)
check('other three cases do not acquire IDs or relations',all(c['decision']=='HOLD' and c['question_id'] is None and c['candidate_relation'] is None for c in rx['cases'] if c['case_id']!='q4-first-lesson'))
runs=[]
for side in ('execution','review/archive'):
    trial=root/f'docs/evidence/A09/{side}/candidate-1/trial'
    run=trial/'normal'
    bundle=load_bundle(run/'final-bundle.json',verify_assets=True).model_dump(mode='json')
    arts=bundle['artifacts'];by_id={a['artifact_id']:a for a in arts};by_kind={a['kind']:a for a in arts}
    for a in arts+bundle['policies']:
        check(side+' full hash '+a.get('artifact_id',a.get('policy_id')),digest(a)==a['content_hash'])
    for a in arts:
        for dep in a['input_refs']:
            check(side+' reference '+a['artifact_id']+'/'+dep['artifact_id'],dep==ref(by_id[dep['artifact_id']]))
    for kind in ('SourceBundle','EvidenceBundle','QuestionGraph'):
        check(side+' observed '+kind,by_kind[kind]['producer']['evidence_mode']=='OBSERVED')
    source=by_kind['SourceBundle'];ev=by_kind['EvidenceBundle'];graph=by_kind['QuestionGraph'];plan=by_kind['ApplyPlan'];receipt=by_kind['ExecutionReceipt']
    for asset in source['payload']['assets']:
        check(side+' original source '+asset['asset_id'],asset['provenance']=='ORIGINAL' and (run/asset['path']).read_bytes()==source_bytes[asset['asset_id']])
    check(side+' one question, correct type and same page stem',len(graph['payload']['questions'])==1 and graph['payload']['questions'][0]['question_id']==case['question_id'] and graph['payload']['questions'][0]['question_type']=='free_response' and graph['payload']['questions'][0]['cross_page'] is False)
    check(side+' four graph fragments',len(graph['payload']['fragments'])==4 and [f['role'] for f in graph['payload']['fragments']]==['stem','stem','stem','answer'])
    check(side+' four evidence regions and graph ownership',len(ev['payload']['regions'])==4 and [f['region_ids'] for f in graph['payload']['fragments']]==[[v['proposal_region_id']] for v in expected])
    for i,(region,want) in enumerate(zip(ev['payload']['regions'],expected)):
        transform=region['crop_transform'];box=want['bbox']
        check(side+' C01 approved region/type/text '+str(i),region['region_id']==want['proposal_region_id'] and region['content_type']==want['content_type']==graph['payload']['fragments'][i]['content_type'] and region['text']==want['text'] and region['box']['bbox']==box and region['box']['image']['asset_id']==want['asset_id'])
        check(side+' original-to-crop transform '+str(i),transform['scale_x']==transform['scale_y']==1 and transform['offset_x']==-box[0] and transform['offset_y']==-box[1] and transform['rotation_degrees']==0 and transform['padding']==[0,0,0,0] and [transform['processed_width'],transform['processed_height']]==[box[2]-box[0],box[3]-box[1]])
    rel=graph['payload']['answer_relations']
    check(side+' selected answer13 relation',len(rel)==1 and rel[0]['question_id']==case['question_id'] and rel[0]['status']=='SELECTED' and rel[0]['selected_fragment_ids']==[graph['payload']['fragments'][-1]['fragment_id']])
    check(side+' single create simulated plan',plan['payload']['readiness']=='READY' and plan['payload']['execution_mode']=='SIMULATED' and len(plan['payload']['actions'])==1 and plan['payload']['actions'][0]['operation']=='CREATE_FRAMES')
    projections=json.loads(plan['payload']['actions'][0]['expected_after']['frames'])
    readback_raw=(run/'assets/readback.json').read_bytes();rb=json.loads(readback_raw)
    actual=list(rb['view']['frame_projections'].values());frames=rb['view']['target']['frames']
    check(side+' expected vs actual projections',projections==actual and len(frames)==len(actual)==4 and len(rb['view']['target']['questions'])==1)
    for i,(got,want,frame) in enumerate(zip(actual,expected,frames)):
        check(side+' four-frame fields '+str(i),got['region_id']==want['proposal_region_id'] and got['platform_role']==want['proposed_role']==frame['platform_role'] and got['platform_type']==want['content_type'] and got['text']==want['text'] and got['box']['bbox']==want['bbox']==frame['box']['bbox'] and got['box']['image']['asset_id']==want['asset_id'] and got['box']==frame['box'])
        check(side+' frame source digest and dimensions '+str(i),all(got['box']['image'][key]==source_descriptors[want['asset_id']][key] for key in ('asset_id','sha256','width','height')))
    check(side+' question binding and simulated target',rb['view']['internal_bindings']=={case['question_id']:'mock-question-1'} and rb['execution_mode']=='SIMULATED' and rb['target_id']==policy['target_id'])
    check(side+' standalone receipt equals bundle',json.loads((run/'receipt.json').read_bytes())==receipt)
    rp=receipt['payload'];result=rp['results'][0]
    check(side+' receipt binds plan and readback',rp['plan']==ref(plan) and rp['execution_mode']=='SIMULATED' and len(rp['results'])==1 and result['outcome']=='APPLIED' and result['effect_match']=='MATCH' and result['replay_allowed'] is False and result['readback']['sha256']==sha(readback_raw))
    reports=[a for a in arts if a['kind']=='CheckReport']
    check(side+' recorded PRE and TARGET current',len(reports)==2 and all(a['payload']['graph']==ref(graph) and a['payload']['decision']=='PASS' for a in reports))
    summary=json.loads((trial/'summary.json').read_bytes())
    check(side+' archived one normal dispatch',summary['normal_attempts']==summary['business_dispatches']==1 and summary['actual_frames_added']==4 and summary['platform_calls']==0 and summary['other_three_cases']=='HOLD_NO_RELATIONS_NO_EXECUTION')
    check(side+' archived ten zero-effect refusals',len(summary['refusals'])==summary['refusal_calls']==10 and all(c['rejected'] and c['new_frames']==c['new_questions']==c['business_dispatches']==0 and c['after_sha256']==c['before_sha256'] for c in summary['refusals']))
    check(side+' unsubmitted pending scope',summary['content_check_status']=='PENDING')
    runs.append({'side':side,'receipt':ref(receipt),'plan':ref(plan),'readback_sha256':sha(readback_raw),'archived_normal_dispatches':1,'archived_refusals':10})

record={'schema':'b-a08-a09-q4-reception/0.1','date':'2026-10-19','timezone':'Asia/Shanghai',
        'a_commit':'edf125961be9cdc1642652c038d99872b1c8cdc7','b_input_commit':'a76e5a925fec76f20818dfdefa4145aa132ec8a8',
        'result':'B_ACCEPTS_THREE_FIXED_Q4_OFFLINE_TECHNICAL_TERMS',
        'accepted_items':{'fixed_input_digest_and_q4_answer13_binding':True,'four_frames_exact_geometry_and_single_case_policy':True,'c01_plan_actual_readback_receipt_references':True},
        'publication_members':len(members),'source_members':len(sources),'frozen_manifest_entries':history_count,
        'check_count':len(checks),'checks':checks,'runs':runs,'a08_actual_readonly_reception':{'status':rx['status'],'summary':rx['summary'],'external_objects':rx['external_objects']},
        'open_field_differences':[],'readonly_receptions_in_this_verification_pass':1,'archived_c01_reads_in_this_verification_pass':2,'b_new_normal_simulations':0,
        'b_new_simulation_dispatches':0,'platform_calls':0,'model_calls':0,
        'other_three_cases':'HOLD_EVIDENCE_ONLY_NO_RELATIONS','original_b_artifacts_modified':False,
        'business_or_human_visual_acceptance_repeated':False,'public_contract_frozen':False,'chapter_acceptance':False,
        'full_external_G08_Check08_plan03_loaded':False,'clean_installation_or_wheel_verified':False,
        'script_sha256':sha(Path(__file__).read_bytes()),'approval_sha256':sha(approval_raw),'proposal_sha256':sha(proposal_raw)}
args.output.write_text(json.dumps(record,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k not in ('checks','runs','a08_actual_readonly_reception')},ensure_ascii=False))
