# B fixed A08/A09 Q4 adoption evidence

Date: 2026-10-19 Asia/Shanghai. A commit: edf125961be9cdc1642652c038d99872b1c8cdc7.
B input: a76e5a925fec76f20818dfdefa4145aa132ec8a8.
This selected evidence bundle preserves raw fixed source bytes for 91 src files,
both full normal C01 archives and their assets, policies, approval and proposal.
All members except this manifest are covered by manifest.json length/SHA256.

The archived final proof has 914 checks. It was produced against the COMPLETE
A fixed source tree; this ZIP deliberately omits other A evidence including
mutation ZIPs. acquisition.json inventories all 449 originally obtained files,
not the contents of this selected ZIP. Use manifest.json for ZIP membership.

To repeat the COMPLETE 914-check read-only verification, obtain every file in
acquisition.json at the fixed A commit, validate Git blobs using git-tree.json,
and supply the original B stage ZIP, SHA256:
b646fad9008e03e79a3dddfb4ead912d7ceadefbcee331c2e2af2415abf6f673.
Command:
python -X utf8 verify_b_reception.py --source <complete-A-tree> --tree git-tree.json --b-package <B-stage.zip> --output <new-receipt.json>
Do not skip missing members or reuse archived output as a fresh run.

The included two final-bundle.json files can be read with the bundled fixed
annotation.contracts.load_bundle(path, verify_assets=True), using fixed-source/src
on sys.path and an existing Python/Pydantic/Pillow environment.
This is read-only consumption; do not run historical business scripts or weaken
HEAD/approval pins. No new simulation or platform action is authorized by this ZIP.
A08 staging reception does not load complete external G0.8/Check0.8/plan0.3.
Other three cases remain HOLD; B originals and ledger are unchanged. This ZIP
does not establish human visual, chapter, clean-installation or platform acceptance.
