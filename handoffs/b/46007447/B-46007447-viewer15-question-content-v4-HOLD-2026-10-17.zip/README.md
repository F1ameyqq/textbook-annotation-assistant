# 印刷页 7 QuestionContent v4 独立离线包（HOLD）

固定代码提交：`7d5c3b738a3e28b528e510d16d7cfe2640936964`；固定外部计划文件 SHA-256：`a7a5c43eb33d2e1378d0f82dc7375603a462dba64a60adbdb06f09a3a2f4ac99`。包内 `inputs/` 保留原图、Source/E/G 与计划原字节，`outputs/` 保留固定代码产生的 Application、Check 和 23 张原像素裁片。`fixtures/` 保存 v2/v3/v4 历史输入包及八次未选用的本地 OCR 原观察包，`reports/` 保存独立 v2/v4 审阅及页 7 来源清点。所有文件的相对路径、字节数和 SHA-256 见 `manifest.json`。

这是单页的独立题目内容投影，不是 14 阶段流水线；没有配答、没有生成新图谱，也未改变原 E/G。`check.accepted=true` 只表示固定输入下来源与投影完整性通过。模型草稿文字尚未经人工核准，业务状态始终 HOLD；不是完整章节或 A 侧接收通过。未访问浏览器或网络，没有新的模型调用。

先在已安装本机 B 依赖的固定 Git 导出代码目录中运行，解包为 `$pkg`，输出到一个新的 `$out`：

```powershell
python tools/rebuild_question_content_b.py --source "$pkg/inputs/source.json" --evidence "$pkg/inputs/evidence.json" --graph "$pkg/inputs/graph.json" --plan "$pkg/inputs/plan.json" --plan-sha256 a7a5c43eb33d2e1378d0f82dc7375603a462dba64a60adbdb06f09a3a2f4ac99 --out $out
```

比较新输出的 application/check 文件 SHA 与 `manifest.json`；核对 23 张裁片的逐文件摘要。包自身可用 `python verify_package.py B-46007447-viewer15-question-content-v4-HOLD-2026-10-17.zip --self-test` 检查（需要 Pillow）。`--self-test` 会证明内部重签的改动计划、篡改裁片和篡改代码均被拒绝。不得从收到的替换计划自行重算新 SHA 作为授权。
