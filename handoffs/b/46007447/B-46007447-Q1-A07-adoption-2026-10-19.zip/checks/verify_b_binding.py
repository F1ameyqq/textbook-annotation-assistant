"""Independent archive-only B comparison; no product imports or dispatch."""
from pathlib import Path
import argparse
import hashlib
import json
import zipfile

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--inputs', type=Path, default=Path(__file__).resolve().parent)
parser.add_argument('--b-root', type=Path)
parser.add_argument('--output', type=Path)
args = parser.parse_args()
ROOT = args.inputs.resolve()
REPO = args.b_root or ROOT.parent / 'textbook-annotation-assistant'
OUT = args.output or ROOT.parents[1] / 'outputs' / 'A07第1题独立来源与六框核对-20261019.json'
checks = []

def sha(raw):
    return hashlib.sha256(raw).hexdigest()

def canonical(data):
    return json.dumps(data, ensure_ascii=False, sort_keys=True,
                      separators=(',', ':'), allow_nan=False).encode('utf-8')

def digest(data):
    return sha(canonical({k: v for k, v in data.items() if k != 'content_hash'}))

def check(label, condition):
    checks.append({'check': label, 'passed': bool(condition)})
    if not condition:
        raise AssertionError(label)

def load(path):
    return json.loads(path.read_bytes())

def ref(obj):
    return {k: obj[k] for k in ('artifact_id', 'revision', 'kind', 'content_hash')}

pkg = REPO / 'handoffs/b/46007447/B-46007447-Q1-source-candidate-v1-HOLD-2026-10-18.zip'
check('B source ZIP SHA', sha(pkg.read_bytes()) == '3039645ca69c2604f542c479cb180049604788a3ca28ffac1b5063dee533afac')
with zipfile.ZipFile(pkg) as z:
    candidate_raw = z.read('candidate.json')
    candidate = json.loads(candidate_raw)
    native = json.loads(z.read('native-selection.json'))
    scope_raw = z.read('scope-applicability-proposal.json')
    scope = json.loads(scope_raw)
    manifest_sha = sha(z.read('manifest.json'))
    binding = json.loads(z.read('base-package-binding.json'))

payload = candidate['payload']
check('B candidate payload digest', sha(canonical(payload)) == candidate['content_hash'])
check('B candidate HOLD remains unmodified', payload['decision'] == 'HOLD' and all(payload[k] is False for k in ('business_acceptance', 'human_verified', 'production_applied', 'a_accepted')))
ids = payload['proposed_semantic_region_ids']
regions = {r['region_id']: r for r in payload['regions']}
selected = [regions[rid] for rid in ids]
expected_roles = ['Q', 'W', 'W', 'W', 'W', 'A']
expected_text = [payload['candidate_content']['stem_body_normalized_without_number']] + payload['candidate_content']['option_texts'] + [payload['candidate_content']['answer_text']]
policy = load(ROOT / 'config/policies/a07-q1-offline-v1.json')
approval = load(ROOT / 'docs/approvals/A07-Q1-offline-business-approval.json')
check('policy six-region whitelist exact', policy['semantic_region_ids'] == ids)
check('policy limited offline scope', policy['scope'] == 'THIS_FIXED_SINGLE_QUESTION_ONLY' and policy['execution_mode'] == 'SIMULATED' and not policy['platform_eligible'])
check('policy source hashes exact', policy['input_sha256']['candidate_file'] == sha(candidate_raw) and policy['input_sha256']['candidate_zip'] == sha(pkg.read_bytes()) and policy['input_sha256']['manifest'] == manifest_sha and policy['input_sha256']['scope_proposal'] == sha(scope_raw) and policy['input_sha256']['base_zip'] == binding['sha256'])
history_raw = (REPO / 'handoffs/b/46007447/single-question-q1/historical-evidence-revision1.json').read_bytes()
history = json.loads(history_raw)
check('historical E0.1 original bytes and payload digest', sha(history_raw) == policy['input_sha256']['history'] == 'a763af50c0515f863eeb6dbaf533f4215535591096dd06b81632cec4acbb4493' and sha(canonical(history['payload'])) == history['content_hash'])
check('historical E0.1 identity matches native selection', all(history[k] == native['historical_evidence'][k] for k in ('artifact_id', 'revision', 'content_hash', 'schema_version', 'kind')))
check('approval binds source version and content', approval['b_commit'] == 'ef6ba4dd083e7fd5378e80123b2b038dd11d7052' and approval['approved_content']['stem'] == expected_text[0] and approval['approved_content']['options'] == expected_text[1:5] and approval['approved_content']['answer'] == 'D' and approval['approved_content']['explanation_present'] is False)
check('approval has no platform or B mutation scope', all(approval[k] is False for k in ('platform_operations_authorized_by_this_record', 'book_submission_authorized', 'original_b_artifact_mutation_authorized', 'independent_human_visual_review_proven')))
outside = {d['issue_id']: d for d in scope['dispositions'] if d['proposed_applicability'] == 'OUTSIDE_SELECTED_CONTENT_PENDING_A_SCOPE_POLICY'}
check('exact thirty issue IDs; business issue retained', len(policy['exclusions']) == len(outside) == 30 and {e['issue_id'] for e in policy['exclusions']} == set(outside) and policy['business_issue_id'] not in outside)
for e in policy['exclusions']:
    d = outside[e['issue_id']]
    check('exclusion evidence ' + e['issue_id'], e['entry_sha256'] == sha(canonical(d)) and e['original_issue_pointer'] == d['original_issue_pointer'] and e['proof_pointers'] == [p['pointer'] for p in d['proof']] and e['reason'] == d['reason'])

runs = []
for name in ('execution', 'review'):
    run = ROOT / f'docs/evidence/A07/F01/{name}/normal/run'
    exchange = load(run / 'exchange.json')
    receipt = load(run / 'receipt.json')
    readback_raw = (run / 'assets/readback.json').read_bytes()
    readback = json.loads(readback_raw)
    provenance_raw = (run / 'assets/input/provenance.json').read_bytes()
    provenance = json.loads(provenance_raw)
    artifacts = exchange['artifacts']
    by_id = {a['artifact_id']: a for a in artifacts}
    by_kind = {a['kind']: a for a in artifacts}
    check(name + ': eight unique artifact identities', len(artifacts) == len(by_id) == 8)
    for a in artifacts + exchange['policies']:
        check(name + ': full C01 digest ' + a.get('artifact_id', a.get('policy_id')), digest(a) == a['content_hash'])
    for a in artifacts:
        for r in a['input_refs']:
            check(name + ': input reference ' + a['artifact_id'] + '/' + r['artifact_id'], r == ref(by_id[r['artifact_id']]))
    check(name + ': standalone receipt equals envelope member', receipt == by_kind['ExecutionReceipt'])
    evidence_index = {e['evidence_id']: e for e in exchange['evidence']}
    check(name + ': provenance resource hash', evidence_index['ev-provenance']['resource']['sha256'] == sha(provenance_raw))
    check(name + ': provenance B snapshots unchanged', provenance['native_question'] == native['native_question_snapshot'] and provenance['native_answer'] == native['native_answer_snapshot'])
    check(name + ': printed 1.D and original span', provenance['answer_source_span']['raw_text'] == '1.D' and provenance['answer_source_span']['source_text_span'] == [2, 3] and provenance['answer_source_span']['source_text_span'][0] == 2 and provenance['normalized_body'] == expected_text[0] and provenance['raw_line_view'] == payload['candidate_content']['stem_with_number_and_source_linebreaks'])
    check(name + ': B ledger and original issue counts retained', provenance['original_check_issue_count'] == 127 and provenance['original_unassigned_ledger_count'] == len(provenance['original_unassigned_ledger']) == 19 and provenance['whole_page_coverage_claim'] is False and provenance['independent_human_visual_review'] is False)
    check(name + ': original provenance regions exact', provenance['region_mapping'] == selected)
    graph = by_kind['QuestionGraph']
    ev = by_kind['EvidenceBundle']
    source = by_kind['SourceBundle']
    for a in (graph, ev, source):
        check(name + ': observed ' + a['kind'], a['producer']['evidence_mode'] == 'OBSERVED')
    check(name + ': original asset identities', all(a['provenance'] == 'ORIGINAL' and any(a['asset_id'] == b['asset_id'] and a['sha256'] == b['sha256'] and a['width'] == b['width'] and a['height'] == b['height'] for b in payload['sources']) for a in source['payload']['assets']) and len(source['payload']['assets']) == 2)
    check(name + ': six Evidence regions and normalized text', [r['region_id'] for r in ev['payload']['regions']] == ids and [r['text'] for r in ev['payload']['regions']] == expected_text)
    for ar, br in zip(ev['payload']['regions'], selected):
        check(name + ': region ' + br['key'], ar['box']['bbox'] == br['bbox'] and ar['box']['image']['asset_id'] == br['asset_id'] and ar['box']['image']['sha256'] == br['source_sha256'] and [ar['box']['image']['width'], ar['box']['image']['height']] == br['source_size'])
        t = ar['crop_transform']
        x, y, right, bottom = br['bbox']
        check(name + ': original-to-crop is inverse of B crop-to-original ' + br['key'],
              t['scale_x'] == t['scale_y'] == 1 and t['offset_x'] == -x and t['offset_y'] == -y
              and t['rotation_degrees'] == 0 and t['padding'] == [0, 0, 0, 0]
              and [t['processed_width'], t['processed_height']] == [right-x, bottom-y] == br['crop']['size']
              and t['invertible'] is True and br['crop']['crop_to_original'] == [[1, 0, x], [0, 1, y], [0, 0, 1]])
    check(name + ': only fixed Q1 and six graph fragments', len(graph['payload']['questions']) == 1 and graph['payload']['questions'][0]['question_id'] == payload['question_id'] and len(graph['payload']['fragments']) == 6)
    relation = graph['payload']['answer_relations']
    check(name + ': explicit answer relation to source D', len(relation) == 1 and relation[0]['question_id'] == payload['question_id'] and relation[0]['status'] == 'SELECTED' and relation[0]['selected_fragment_ids'] == [graph['payload']['fragments'][-1]['fragment_id']] and graph['payload']['fragments'][-1]['region_ids'] == [ids[-1]])
    p = exchange['policies'][0]
    check(name + ': internal policy remains proposal', p['confirmation_status'] == 'A_INTERNAL_PROPOSAL' and p['applicability'] == 'PROPOSAL_ONLY' and p['role_mapping']['option'] == 'W')
    reports = [a for a in artifacts if a['kind'] == 'CheckReport']
    check(name + ': recorded checks bind current graph/policy', len(reports) == 2 and all(a['payload']['decision'] == 'PASS' and a['payload']['graph'] == ref(graph) and a['payload']['policy']['content_hash'] == p['content_hash'] for a in reports))
    plan = by_kind['ApplyPlan']
    check(name + ': bounded simulated plan', plan['payload']['readiness'] == 'READY' and plan['payload']['execution_mode'] == 'SIMULATED' and len(plan['payload']['actions']) == 1 and plan['payload']['actions'][0]['operation'] == 'CREATE_FRAMES')
    projection = json.loads(plan['payload']['actions'][0]['expected_after']['frames'])
    actual_projection = list(readback['view']['frame_projections'].values())
    check(name + ': expected and actual six projections identical', projection == actual_projection and len(projection) == 6)
    target = readback['view']['target']
    check(name + ': all three role paths Q/W/W/W/W/A', [r['platform_role'] for r in projection] == [r['platform_role'] for r in actual_projection] == [r['platform_role'] for r in target['frames']] == expected_roles)
    for frame, br in zip(projection, selected):
        check(name + ': actual frame binding ' + br['key'], frame['region_id'] == br['region_id'] and frame['box']['bbox'] == br['bbox'] and frame['box']['image']['asset_id'] == br['asset_id'] and frame['box']['image']['sha256'] == br['source_sha256'])
    check(name + ': exactly one real Q1 mapped to one mock question', len(target['questions']) == 1 and len(target['frames']) == 6 and readback['view']['internal_bindings'] == {payload['question_id']: target['questions'][0]['platform_question_id']})
    rp = receipt['payload']
    check(name + ': receipt linked to fixed plan and readback', rp['plan'] == ref(plan) and rp['execution_mode'] == 'SIMULATED' and len(rp['results']) == 1 and rp['results'][0]['outcome'] == 'APPLIED' and rp['results'][0]['readback']['sha256'] == sha(readback_raw) and rp['results'][0]['effect_match'] == 'MATCH')
    check(name + ': target explicitly simulated', readback['execution_mode'] == 'SIMULATED' and readback['target_id'] == policy['target_id'])
    runs.append({'run': name, 'receipt': ref(receipt), 'readback_sha256': sha(readback_raw), 'roles': expected_roles, 'frames': len(projection), 'static_verified_only': True})

report = {'schema': 'b-a07-independent-source-role-binding-review/0.1',
          'a_commit': 'e37606d74d7e538052c563d02df11c6c961b742f',
          'b_input_commit': 'ef6ba4dd083e7fd5378e80123b2b038dd11d7052',
          'result': 'PASS_FIXED_Q1_ARCHIVE_BINDING_ONLY', 'checks': checks, 'check_count': len(checks),
          'runs': runs, 'new_business_runs': 0, 'new_dispatches': 0, 'platform_calls': 0,
          'independent_human_visual_acceptance': False, 'whole_chapter_acceptance': False,
          'original_b_artifacts_modified': False,
          'scope': 'Archive comparison and reference/digest recomputation only; A stored execution is not a new B execution.',
          'script_sha256': sha(Path(__file__).read_bytes()),
          'inputs': [{'path': p.relative_to(ROOT).as_posix(), 'sha256': sha(p.read_bytes())} for p in sorted(ROOT.rglob('*.json'))]}
OUT.write_text(json.dumps(report, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')
print(json.dumps({'result': report['result'], 'check_count': len(checks), 'output': str(OUT)}, ensure_ascii=False))
