"""Read archive bytes only. No imports of A product code, target or dispatch."""
from pathlib import Path
import argparse
import hashlib
import json

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--a-root', type=Path, required=True)
parser.add_argument('--tree', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
root = args.a_root
sha = lambda b: hashlib.sha256(b).hexdigest()
blob = lambda b: hashlib.sha1(b'blob '+str(len(b)).encode()+b'\0'+b).hexdigest()
read = lambda p: json.loads((root / p).read_bytes())
tree_data = json.loads(args.tree.read_bytes())
assert not tree_data['truncated']
assert tree_data['sha'] == 'e37606d74d7e538052c563d02df11c6c961b742f'
tree = {x['path']: x for x in tree_data['tree'] if x['type'] == 'blob'}
manifest_path = 'docs/handoff/a07-q1/manifest.json'
manifest = read(manifest_path)
members = manifest['source_members'] + manifest['generated_members']
assert len({m['path'] for m in members}) == len(members)
for m in members:
    raw = (root / m['path']).read_bytes()
    assert sha(raw) == m['sha256'] and len(raw) == m['bytes'], m['path']
    assert blob(raw) == m['blob_oid'] == tree[m['path']]['sha'], m['path']
all_sources = [p for p in tree if p.startswith('src/')]
for p in all_sources:
    raw = (root / p).read_bytes()
    assert len(raw) == tree[p]['size'] and blob(raw) == tree[p]['sha'], p
overrides = {(m['manifest'], m['original_path']): m['published_path'] for m in manifest['historical_overrides']}
historical = []
for p in manifest['frozen_delivery_manifests']:
    h = read(p)
    for m in h['members']:
        target = overrides.get((p, m['path']), m['path'])
        raw = (root / target).read_bytes()
        assert len(raw) == m['bytes'] and sha(raw) == m['sha256'], (p, target)
    historical.append({'manifest': p, 'members': len(h['members']), 'sha256': sha((root/p).read_bytes())})

oldpaths = {
    'execution': 'docs/evidence/A07/execution/candidate-1/run/assets/readback.json',
    'review': 'docs/evidence/A07/review/candidate-1/normal/run/assets/readback.json',
}
deltas = []
for side, oldpath in oldpaths.items():
    newpath = f'docs/evidence/A07/F01/{side}/normal/run/assets/readback.json'
    old, new = read(oldpath), read(newpath)
    oldframes, newframes = old['view']['target']['frames'], new['view']['target']['frames']
    assert [f['platform_role'] for f in oldframes] == ['Q']*5+['A']
    assert [f['platform_role'] for f in newframes] == ['Q','W','W','W','W','A']
    for before, after in zip(oldframes, newframes):
        assert {k:v for k,v in before.items() if k!='platform_role'} == {k:v for k,v in after.items() if k!='platform_role'}
    assert len(oldframes) == len(newframes) == 6
    op, np = old['view']['frame_projections'], new['view']['frame_projections']
    assert op.keys() == np.keys()
    for frameid in op:
        assert {k:v for k,v in op[frameid].items() if k!='platform_role'} == {k:v for k,v in np[frameid].items() if k!='platform_role'}
    deltas.append({'side': side, 'old_readback': oldpath, 'old_sha256': sha((root/oldpath).read_bytes()),
                   'current_readback': newpath, 'current_sha256': sha((root/newpath).read_bytes()),
                   'changed_role_indices': [1,2,3,4], 'all_other_frame_and_projection_fields_equal': True})

record = {'schema': 'b-a07-publication-and-delta-review/0.1',
          'a_commit': 'e37606d74d7e538052c563d02df11c6c961b742f',
          'result': 'PASS_ARCHIVE_INTEGRITY_AND_RECORDED_ROLE_DELTA',
          'publication_members_verified': len(members), 'all_source_members_verified': len(all_sources),
          'manifest_sha256': sha((root/manifest_path).read_bytes()),
          'fixed_tree_response_sha256': sha(args.tree.read_bytes()),
          'historical_manifests': historical, 'role_deltas': deltas,
          'new_business_runs': 0, 'new_dispatches': 0, 'platform_calls': 0,
          'script_sha256': sha(Path(__file__).read_bytes())}
args.output.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({k:v for k,v in record.items() if k not in ('historical_manifests','role_deltas')}, ensure_ascii=False))
