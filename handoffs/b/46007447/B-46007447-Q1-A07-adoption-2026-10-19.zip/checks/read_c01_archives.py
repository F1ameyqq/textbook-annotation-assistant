"""Load two frozen C01 archives with resources; create no plans or targets."""
from pathlib import Path
import argparse
import hashlib
import json
import sys

parser = argparse.ArgumentParser(description=__doc__)
parser.add_argument('--a-root', type=Path, required=True)
parser.add_argument('--output', type=Path, required=True)
args = parser.parse_args()
sys.path.insert(0, str(args.a_root.resolve() / 'src'))
from annotation.contracts import load_bundle, artifact_ref

rows = []
for side in ('execution', 'review'):
    p = args.a_root / f'docs/evidence/A07/F01/{side}/normal/run/exchange.json'
    bundle = load_bundle(p, verify_assets=True)
    rows.append({'side': side, 'exchange_sha256': hashlib.sha256(p.read_bytes()).hexdigest(),
                 'artifacts': [artifact_ref(a) for a in bundle.artifacts],
                 'evidence_count': len(bundle.evidence), 'resource_verification': True})
record = {'a_commit': 'e37606d74d7e538052c563d02df11c6c961b742f',
          'result': 'PASS_C01_ARCHIVE_READ_WITH_RESOURCES', 'rows': rows,
          'new_business_runs': 0, 'new_dispatches': 0, 'platform_calls': 0,
          'clean_environment_install': False,
          'script_sha256': hashlib.sha256(Path(__file__).read_bytes()).hexdigest()}
args.output.write_text(json.dumps(record, ensure_ascii=False, indent=2)+'\n', encoding='utf-8')
print(json.dumps({'result': record['result'], 'archives_read': len(rows)}, ensure_ascii=False))
