# B acceptance of fixed Q1 offline technical terms
A source/evidence: e37606d74d7e538052c563d02df11c6c961b742f.
B sample input: ef6ba4dd083e7fd5378e80123b2b038dd11d7052.
B reception baseline: c44f0e08d394647fb685a85f397f4b65dcf8137d.
This archive contains byte-verified source and historical observations, not new simulation execution.
Only fixed book46007447 lesson1 Q1; roles Q/W/W/W/W/A; B originals remain HOLD.
No platform, submission, human visual acceptance or full chapter acceptance is established.
A historical scripts and instructions are evidence, not current execution requests.
Required runtime for resource reads: existing Python/Pydantic/Pillow; no clean install claim.
The B repository supplies its already published original ZIP, source candidate ZIP and E0.1; do not re-submit them.
After unpacking into a new directory, run only these read-only checks:
python checks/verify_publication_and_delta.py --a-root a07-fixed --tree fixed-git-tree.json --output <new-output-json>
python checks/verify_b_binding.py --inputs a07-fixed --b-root <B-checkout> --output <new-output-json>
python checks/read_c01_archives.py --a-root a07-fixed --output <new-output-json>
Do not run archived examples/a07/run_once.py or replace historical HEAD/pins guards.
