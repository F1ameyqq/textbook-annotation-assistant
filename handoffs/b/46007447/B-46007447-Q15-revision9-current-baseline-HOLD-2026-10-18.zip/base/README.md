# B side offline handoff — 46007447 Q16 region, HOLD

This archive is an immutable, read-only export from one fixed 14-stage B trial run. It is a local candidate for the five observed pages plus a distinct adjacent answer resource, **not** a complete chapter or accepted A/B public contract. No website annotation was changed.

- B code baseline: `c3cc2df7a0be24c125c83681c0499c0d328d78f6` (plus the verifier committed with this package).
- Run: `pipeline-run-0a2c03e193694ef88953f3ca08b8cde2`
- Schema: `b-pipeline-report-trial/0.1`; B trial schemas remain provisional.
- Book: `46007447`; scope: `existing-annotations-five-observed-pages`.
- Pipeline state: READY (14 stage receipts); business decision: HOLD. READY only means the pipeline completed.
- Final objects: `artifacts/evidence.json`, `artifacts/graph.json`, `artifacts/check.json`; full report and original stage wrappers are also present. Do not trim JSON while retaining a previous content hash.
- Source: five exact viewer images and a separate adjacent `resource-173` original. The latter is not interchangeable with `viewer-173`. Supporting fixture crops are included with their original paths; match their hashes and crop transforms to the receipts before using them.
- Graph: 34 question candidates, 66 answer candidates. Check: 127 issues. These figures describe this fixed local scope only.
- All historical `file_sha256` input receipts except the original inline ZIP container have exact byte copies in this archive. Ten JSON inputs were reconstructed in their original CRLF form from equal semantic fixture content and matched to their recorded SHA. The inline ZIP container's historical byte stream is unavailable, but all 95 named members in the included ZIP match the run's recorded member byte counts and SHA-256 values. The container itself must not be presented as byte-identical to the historical one.
- `manifest.json` maps exact receipt hashes to their package paths and names that one ZIP-container exception. The included `supporting-fixtures/` files are useful for inspection; prefer `inputs/` for exact historical receipt bytes.
- Verification: `python verify_b_handoff.py B-46007447-Q16-offline-HOLD-2026-10-17.zip --self-test` using the verifier in the repository, or extract this archive and run its bundled verifier against the ZIP. Python standard library suffices for verification; full B runtime dependencies are listed in `requirements-b.txt`.
- The three self-test controls reject a stale graph reference, unknown source asset, and corrupted adjacent resource. They do not establish A consumer acceptance.

A-side receipt and contract compatibility are pending. The complete chapter requires missing source pages, answer pages, a verified directory/resource map, independent census and human content review.
