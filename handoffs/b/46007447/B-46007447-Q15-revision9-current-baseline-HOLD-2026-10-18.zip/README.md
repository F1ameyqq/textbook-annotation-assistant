# 46007447 Q15 当前基线 revision 9 离线交接包

此包仅重放旧六资产内容链，固定生产代码提交 `b5cc1ea2a0cc1b50b051ffc5ad429e7b473f516a`。`code/` 的源码和所需工具逐字节取自该提交的 Git blob；`base/` 是先前 revision 8 包内的原图、来源、输入收据和支持材料，`inline/` 保存清单所列的行内素材，`plans/` 分开保存当前基线 revision 8 与 revision 9 两个计划。印刷第 5/7 页新增资产不在旧六资产链内。

在解包根目录运行 `python replay_verify.py --workdir <空目录> --receipt <回执.json>`。脚本屏蔽网络和模型导入、不启用 OCR，先核对包内所有字节、原图尺寸和原运行阶段对象，再用包内输入冷、暖重放 14 阶段，核对 G/Check 等最终引用，并运行 Q15 独立高层断言及两个负例。需本地 Python 图像/数值依赖；没有凭证或平台会话。

`reference/final/` 保留原四轮运行：冷 0 缓存、暖 14 缓存、回到当前 rev8 时 12 缓存、再应用 rev9 时 14 缓存，均 READY 且审计接受。`history/stale-plan/` 是旧计划在当前 E/G/Check 上被 content_apply 拒绝的失败记录，不应替换正式当前计划。原始当前基线对账为 34 题、66 答、137 问题，仍有 19 条未归属源行与 32 个未匹配答案实体。Q15 改动仍未人工核准，业务状态 `HOLD`，未修改网站标注。
