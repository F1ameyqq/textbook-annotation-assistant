"""Verify and cold/warm replay the Q15 revision-9 portable offline package."""
from __future__ import annotations

import argparse
from collections import Counter
import hashlib
import importlib.abc
import importlib.util
import json
from pathlib import Path, PurePosixPath
import socket
import sys


ROOT = Path(__file__).resolve().parent
COMMIT = "b5cc1ea2a0cc1b50b051ffc5ad429e7b473f516a"
LABELS = ("merged-cold", "merged-warm", "restore-revision8", "reapply-merged")
EXPECTED_HITS = (0, 14, 12, 14)


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value) -> bytes:
    return json.dumps(value, ensure_ascii=False, sort_keys=True,
                      separators=(",", ":"), allow_nan=False).encode("utf-8")


def load(rel: str):
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def ref(value: dict) -> dict:
    return {key: value[key] for key in ("artifact_id", "revision", "content_hash")}


def check_artifact(value: dict, expected: dict | None = None) -> None:
    assert value["content_hash"] == sha(canonical(value["payload"])), value["artifact_id"]
    if expected is not None:
        assert ref(value) == expected, value["artifact_id"]


def collect_file_shas(value, found: set[str]) -> None:
    if isinstance(value, dict):
        if isinstance(value.get("file_sha256"), str):
            found.add(value["file_sha256"])
        for child in value.values():
            collect_file_shas(child, found)
    elif isinstance(value, list):
        for child in value:
            collect_file_shas(child, found)


def static_verify() -> dict:
    manifest = load("manifest.json")
    assert manifest["schema_version"] == "b-q15-current-baseline-revision9-portable/0.1"
    assert manifest["code_commit"] == COMMIT and manifest["source_scope"] == "OLD_SIX_ASSETS_ONLY"
    paths, file_shas = set(), set()
    for entry in manifest["files"]:
        name = entry["path"]
        path = PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts and "\\" not in name
        assert name not in paths
        paths.add(name)
        data = (ROOT / name).read_bytes()
        assert len(data) == entry["bytes"] and sha(data) == entry["sha256"], name
        file_shas.add(entry["sha256"])

    base = load("base/manifest.json")
    for item in base["files"]:
        name = "base/" + item["path"]
        data = (ROOT / name).read_bytes()
        assert len(data) == item["bytes"] and sha(data) == item["sha256"], name
    inline = load("inline/inline-package.json")
    for name, item in inline["members"].items():
        data = (ROOT / "inline" / name).read_bytes()
        assert len(data) == item["bytes"] and sha(data) == item["sha256"], name

    source = load("base/source/source.json")
    assert source["book_id"] == "46007447" and len(source["assets"]) == 5
    from PIL import Image
    for asset in source["assets"]:
        path = ROOT / "base/source" / asset["path"]
        assert sha(path.read_bytes()) == asset["sha256"]
        with Image.open(path) as image:
            assert image.size == (asset["width"], asset["height"])
            image.verify()
    adjacent = ROOT / "base/source/adjacent/46007447_resource_173.jpg"
    assert sha(adjacent.read_bytes()) == base["adjacent_source"]["sha256"]
    with Image.open(adjacent) as image:
        image.verify()

    plans = {version: load(f"plans/revision{version}.json") for version in (8, 9)}
    for version, plan in plans.items():
        check_artifact(plan)
        assert sha((ROOT / f"plans/revision{version}.json").read_bytes()) == \
            manifest["plan_sha256"][f"revision{version}.json"]
    assert len(plans[8]["payload"]["operations"]) == 14
    assert len(plans[9]["payload"]["operations"]) == 16
    stale = load("history/stale-plan/merged-cold-report.json")
    assert stale["payload"]["pipeline_state"] == "FAILED"
    assert next(row for row in stale["payload"]["stages"] if row["stage_id"] == "content_apply")["last_error"] == \
        "revision plan is stale for current E/G05/Check05"

    original = {}
    for label, hits in zip(LABELS, EXPECTED_HITS):
        report = load(f"reference/final/{label}-report.json")
        audit = load(f"reference/final/{label}-audit.json")
        check_artifact(report)
        check_artifact(audit)
        payload, checked = report["payload"], audit["payload"]
        assert payload["pipeline_state"] == "READY" and checked["accepted"] is True
        assert payload["counts"]["declared_stages"] == payload["counts"]["done"] == 14
        assert payload["counts"]["cache_hits"] == hits
        assert payload["decision"] == checked["decision"] == "HOLD"
        assert payload["business_acceptance"] is checked["business_acceptance"] is False
        assert payload["transcription_verified"] is checked["transcription_verified"] is False
        assert payload["platform_actions"] == checked["platform_actions"] == []
        assert len(payload["stages"]) == 14
        for stage in payload["stages"]:
            assert stage["state"] == "DONE"
            descriptor = stage["output"]
            assert descriptor["path"] == "objects/" + descriptor["sha256"] + ".json"
            data = (ROOT / "reference/objects" / Path(descriptor["path"]).name).read_bytes()
            assert sha(data) == descriptor["sha256"]
            wrapper = json.loads(data)
            check_artifact(wrapper, descriptor["artifact_ref"])
            check_artifact(wrapper["payload"]["result"], stage["result_ref"])
        receipts = set()
        collect_file_shas(payload["input_receipts"], receipts)
        assert receipts <= file_shas, (label, sorted(receipts - file_shas))
        original[label] = {"report_ref": ref(report), "audit_ref": ref(audit),
                           "final_outputs": payload["final_outputs"], "counts": payload["counts"]}

    graph, check, application = (load(f"reference/final/{name}.json")
                                 for name in ("graph", "check", "application"))
    for artifact in (graph, check, application):
        check_artifact(artifact)
    assert ref(graph) == original["merged-cold"]["final_outputs"]["graph_ref"]
    assert ref(check) == original["merged-cold"]["final_outputs"]["quality_ref"]
    assert application["payload"]["graph"] == graph
    assert len(graph["payload"]["questions"]) == 34
    assert len(graph["payload"]["answers"]) == 66
    assert len(check["payload"]["issues"]) == 137
    assert len(graph["payload"]["unmatched_answer_ids"]) == 32
    assert Counter(row["status"] for row in graph["payload"]["answer_coverage"])["UNASSIGNED"] == 19
    assert graph["payload"]["decision"] == check["payload"]["decision"] == "HOLD"
    assert load("reference/master-integration.json")["graph_ref"] == ref(graph)
    assert load("reference/master-integration.json")["check_ref"] == ref(check)

    spec = importlib.util.spec_from_file_location("q15_assertions",
        ROOT / "fixtures/q15-v9-high-level-assertions.py")
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    high_level = module.self_test(plans[9], graph)
    assert high_level["accepted"] is True
    assert high_level["negative_printed_number_duplicate"]["accepted"] is False
    assert high_level["negative_fraction_plain_run"]["accepted"] is False
    return {"file_count": len(paths), "source_images": 6, "original": original,
            "high_level": high_level, "final_refs": original["merged-cold"]["final_outputs"]}


class DenyModels(importlib.abc.MetaPathFinder):
    def find_spec(self, fullname, path=None, target=None):
        if fullname.split(".")[0] in {
            "torch", "transformers", "onnxruntime", "rapidocr_onnxruntime", "pix2tex", "paddleocr"}:
            raise RuntimeError("model import prohibited: " + fullname)
        return None


def replay(workdir: Path, expected: dict) -> dict:
    if workdir.exists() and any(workdir.iterdir()):
        raise ValueError("replay workdir must be empty")
    workdir.mkdir(parents=True, exist_ok=True)
    sys.meta_path.insert(0, DenyModels())
    def deny_network(*_args, **_kwargs):
        raise RuntimeError("network prohibited during offline replay")
    socket.create_connection = deny_network
    socket.socket.connect = deny_network
    socket.socket.connect_ex = deny_network
    sys.path.insert(0, str(ROOT / "code/src"))
    from annotation.recognition.pipeline import run_pipeline
    from annotation.recognition.pipeline_quality import audit_pipeline

    base = ROOT / "base"
    args = (base / "source/source.json", base / "inputs/context.json",
            base / "supporting-fixtures/review.json", workdir)
    common = dict(evidence_path=base / "inputs/evidence.json",
                  recovery_path=base / "supporting-fixtures/recovery-package.json",
                  continuation_path=base / "supporting-fixtures/continuation-package.json",
                  adjacent_source_path=base / "source/adjacent/46007447_resource_173.jpg",
                  inline_path=ROOT / "inline/inline-package.json",
                  inline_source_path=base / "source/adjacent/46007447_resource_173.jpg",
                  content_revision_path=ROOT / "plans/revision9.json")
    out = {}
    for label, hits in (("cold", 0), ("warm", 14)):
        report = run_pipeline(*args, **common)
        audit = audit_pipeline(*args[:3], report, workdir, **common)
        check_artifact(report)
        check_artifact(audit)
        payload, checked = report["payload"], audit["payload"]
        assert payload["pipeline_state"] == "READY" and checked["accepted"] is True
        assert payload["counts"]["declared_stages"] == payload["counts"]["done"] == 14
        assert payload["counts"]["cache_hits"] == hits
        assert payload["decision"] == checked["decision"] == "HOLD"
        assert payload["business_acceptance"] is checked["business_acceptance"] is False
        assert payload["transcription_verified"] is checked["transcription_verified"] is False
        assert payload["platform_actions"] == checked["platform_actions"] == []
        assert payload["final_outputs"] == expected["final_refs"]
        out[label] = {"report_ref": ref(report), "audit_ref": ref(audit),
                      "counts": payload["counts"], "final_outputs": payload["final_outputs"],
                      "decision": "HOLD", "audit_accepted": True}
    return out


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workdir", type=Path, required=True)
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    static = static_verify()
    runs = replay(args.workdir, static)
    result = {"schema_version": "b-q15-revision9-portable-replay/0.1",
              "code_commit": COMMIT, "manifest_files": static["file_count"],
              "source_images": static["source_images"],
              "original_runs": static["original"],
              "replay": runs,
              "high_level_assertions": static["high_level"],
              "new_ocr_model_network_calls": 0, "business_decision": "HOLD"}
    if args.receipt:
        args.receipt.parent.mkdir(parents=True, exist_ok=True)
        args.receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2,
                                          sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"manifest_files": static["file_count"], "source_images": 6,
                      "cold_cache_hits": runs["cold"]["counts"]["cache_hits"],
                      "warm_cache_hits": runs["warm"]["counts"]["cache_hits"],
                      "refs_match": True, "decision": "HOLD"}, sort_keys=True))


if __name__ == "__main__":
    main()
