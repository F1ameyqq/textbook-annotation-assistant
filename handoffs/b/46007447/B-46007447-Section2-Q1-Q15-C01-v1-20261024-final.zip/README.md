# 一定是直角三角形吗：Q1–Q15 C01便携包

本包只含本节Q1–Q15，排除已交付的Q16与相邻三阅读任务。当前B内容缺口为空，15组题答关系均为B模型来源确认的SELECTED。

包含3张原图、65个原字节裁片/活动片段、28个独立选项、5张题图、5个null题空及72个公式片段。全解答保留在answer，analysis为null。Q7给定错误解答仍在题面，按左栏底部→右栏顶部顺序；正确答案另存。Q15答案同页跨栏接续；Q9的8²/15²/17²与Q13错误选项5/2原样保留。公式使用精确源词+LaTeX侧车表达，未新增公共C01字段。

## 范围与来源

SOURCE-PROJECTION.json、SOURCE-COLUMN-FLOW.json及delivery/basis.json是明示派生证据，不冒充原始HTTP或原始source-spec字节。保留原始包/spec/manifest/OCR/页元数据的SHA、原图、区域和原始OCR行观察，后者可能含邻题token，不当作定稿。原始业务响应、个人绝对路径、profile/凭据不入发布包。私有来源ZIP也未包含。

C01 PRE_APPLY仍HOLD，范围为正式平台policy采纳与整页/全章目标覆盖；不表示本批B内容失败，也不因缺少人签统一阻断普通题。未声明A所有者、独立人工或平台接受。

## 离线重放

预装Python 3.12、Pillow 12.3.0、Pydantic 2.14.1：

```powershell
python -B tools/replay_lesson_c01_b.py --package . --out FRESH_EXTERNAL_DIRECTORY
python -B -m unittest discover -s tests -v
```

输出目录须全新且在包外。重放检查清单全部成员，重建73个交付文件并逐字节比较，独立核原图/裁片、题答/顺序/空白/公式，然后经固定A24的50文件源码调用load_bundle(..., verify_assets=True)，比较完整对象。不安装软件、不重OCR、不访问网站。

原始source-spec仅供私有投影入口使用；发布包可直接从delivery/冻结重建，无需原始业务数据。详见SOURCE-PROJECTION-NOTES.md。index.html提供离线全文、公式和全部来源裁片预览。新最终ZIP的独立QA及根会话集成另行记录。
