# “漫话勾股世界”答案几何候选

本目录从已冻结的 viewer 173 原图裁出 7 个原像素 PNG，用于复核印刷页 25 上同一无主编号材料的三个答案子任务。

- 任务 (1)：`task1-line1.png`
- 任务 (2)：`task2-line1-tail.png`、`task2-line2.png`、`task2-line3-prefix.png`
- 任务 (3)：`task3-line3-suffix.png`、`task3-line4-continuation.png`、`task3-diagram.png`

同一物理行中的 `(1) → (2)` 与 `(2) → (3)` 已按可见空白分别切开，候选框互不重叠。任务 (3) 图框包含外框、横纵分割线以及顶部和左侧共四个 `a/b` 标签，不以原 OCR 的单个 `b` 字形代替整图。

全部坐标、PNG SHA-256、原 OCR 行的包含/分段关系和开放歧义见 `manifest.json`。这些材料仅为 `MODEL_VISUAL` 几何候选，不建立平台题目身份，不修改 `UNASSIGNED` 状态，也不构成人工金标。
