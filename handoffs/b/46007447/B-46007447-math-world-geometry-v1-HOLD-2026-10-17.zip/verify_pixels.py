from pathlib import Path
import json,hashlib
from PIL import Image
root=Path(__file__).resolve().parent
m=json.loads((root/'manifest.json').read_text(encoding='utf-8'))
assert hashlib.sha256((root/'manifest.json').read_bytes()).hexdigest()=='44534f326649eadf32c267afe92bf812cfeeb107e5ef0a4956ec61560a03ccb2'
source=root/'source/46007447_viewer_173.jpg'
assert hashlib.sha256(source.read_bytes()).hexdigest()==m['source']['sha256']
im=Image.open(source).convert('RGB')
for s in m['segments']:
 p=root/s['png'];assert hashlib.sha256(p.read_bytes()).hexdigest()==s['png_sha256']
 saved=Image.open(p).convert('RGB');expected=im.crop(tuple(s['bbox_xyxy']))
 assert saved.size==expected.size and saved.tobytes()==expected.tobytes()
print('7 source crops exact; MODEL_VISUAL / UNVERIFIED / UNASSIGNED / HOLD')
