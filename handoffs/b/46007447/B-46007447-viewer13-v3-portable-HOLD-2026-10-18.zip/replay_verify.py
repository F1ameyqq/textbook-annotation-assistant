"""Verify and replay the frozen viewer-13 v3 offline handoff.

Run from an extracted package with a Python environment containing the local
runtime dependencies (not an OCR model). This script never enables live OCR.
"""
from __future__ import annotations

import argparse
import hashlib
import importlib.util
import json
from pathlib import Path, PurePosixPath
import socket
import sys


ROOT = Path(__file__).resolve().parent
STAGES = ("evidence", "assemble", "quality")
SCHEMAS = ("b-evidence-trial/0.4", "b-graph-trial/0.9", "b-check-trial/0.9")


def sha(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def canonical(value) -> bytes:
    return json.dumps(value, sort_keys=True, separators=(",", ":"),
                      ensure_ascii=False, allow_nan=False).encode("utf-8")


def read_json(rel: str):
    return json.loads((ROOT / rel).read_text(encoding="utf-8"))


def ref(value: dict) -> dict:
    return {key: value[key] for key in ("artifact_id", "revision", "content_hash")}


def check_artifact(value: dict, expected: dict | None = None) -> None:
    assert value["content_hash"] == sha(canonical(value["payload"])), value["artifact_id"]
    if expected is not None:
        assert ref(value) == expected, value["artifact_id"]


def verify_static() -> dict:
    manifest = read_json("manifest.json")
    assert manifest["schema_version"] == "b-viewer13-v3-portable/0.1"
    assert manifest["code_commit"] == "b5cc1ea2a0cc1b50b051ffc5ad429e7b473f516a"
    names = [item["path"] for item in manifest["files"]]
    assert len(names) == len(set(names))
    for entry in manifest["files"]:
        name = entry["path"]
        path = PurePosixPath(name)
        assert not path.is_absolute() and ".." not in path.parts and "\\" not in name
        data = (ROOT / name).read_bytes()
        assert len(data) == entry["bytes"] and sha(data) == entry["sha256"], name

    source = read_json("inputs/source/source.json")
    assert source["book_id"] == "46007447" and len(source["assets"]) == 1
    asset = source["assets"][0]
    assert asset["asset_id"] == "viewer-13" and asset["sha256"] == manifest["source_sha256"]
    image_path = ROOT / "inputs/source" / asset["path"]
    assert sha(image_path.read_bytes()) == asset["sha256"]
    from PIL import Image
    with Image.open(image_path) as image:
        assert image.size == (asset["width"], asset["height"]) == (1219, 1691)
        image.verify()

    original_refs = {}
    original_runs = {}
    for label in ("cold", "warm", "recovery"):
        report = read_json(f"reference/reports/{label}-report.json")
        audit = read_json(f"reference/reports/{label}-audit.json")
        check_artifact(report)
        check_artifact(audit)
        payload = report["payload"]
        checked = audit["payload"]
        assert payload["pipeline_state"] == "READY"
        assert payload["decision"] == checked["decision"] == "HOLD"
        assert payload["business_acceptance"] is checked["business_acceptance"] is False
        assert payload["transcription_verified"] is checked["transcription_verified"] is False
        assert payload["platform_actions"] == checked["platform_actions"] == []
        assert checked["accepted"] is True
        assert payload["counts"]["declared_stages"] == 3
        if label == "cold":
            assert payload["counts"]["cache_hits"] == 0
        elif label == "warm":
            assert payload["counts"]["cache_hits"] == 3
        else:
            assert payload["counts"]["cache_hits"] == 1
            assert payload["counts"]["invalidated"] == 1
        stages = payload["stages"]
        assert tuple(row["stage_id"] for row in stages) == STAGES
        refs = {}
        for stage, schema in zip(stages, SCHEMAS):
            assert stage["state"] == "DONE"
            descriptor = stage["output"]
            relative = descriptor["path"]
            assert relative == "objects/" + descriptor["sha256"] + ".json"
            group = "recovery" if label == "recovery" else "coldwarm"
            wrapper_path = ROOT / "reference/objects" / group / Path(relative).name
            data = wrapper_path.read_bytes()
            assert sha(data) == descriptor["sha256"]
            wrapper = json.loads(data)
            check_artifact(wrapper, descriptor["artifact_ref"])
            result = wrapper["payload"]["result"]
            check_artifact(result, stage["result_ref"])
            assert result["schema_version"] == schema
            refs[stage["stage_id"]] = ref(result)
        if not original_refs:
            original_refs = refs
        else:
            assert refs == original_refs
        original_runs[label] = {"report_ref": ref(report), "audit_ref": ref(audit),
                                "counts": payload["counts"]}

    for stage, name in zip(STAGES, ("evidence", "graph", "check")):
        artifact = read_json(f"reference/artifacts/{name}.json")
        check_artifact(artifact, original_refs[stage])

    receipts = read_json("reference/reports/cold-report.json")["payload"]["input_receipts"]
    for key, relative in (("source", "inputs/source/source.json"),
                          ("context", "inputs/context.json"),
                          ("review", "inputs/review.json"),
                          ("evidence", "inputs/evidence.json")):
        assert sha((ROOT / relative).read_bytes()) == receipts[key]["file_sha256"]

    graph = read_json("reference/artifacts/graph.json")
    check = read_json("reference/artifacts/check.json")
    evaluation = read_json("reference/evaluation.json")
    assert evaluation["decision"] == "HOLD"
    assert evaluation["outputs"]["cold"]["final_outputs"] == original_refs
    assert len(graph["payload"]["questions"]) == 2
    assert len(graph["payload"]["shared_materials"]) == 1
    assert len(graph["payload"]["shared_materials"][0]["tasks"]) == 3
    coverage = graph["payload"]["question_source_coverage"]
    assert len(coverage) == 48
    assert {row["line_id"] for row in coverage} == {
        f"viewer-13/ocr/{index}" for index in range(48)}
    assert len(graph["payload"]["answers"]) == 0
    assert len(check["payload"]["issues"]) == 12
    return {"source_sha256": asset["sha256"], "original_refs": original_refs,
            "original_runs": original_runs, "manifest_files": len(names)}


def reject_old_reader() -> str:
    path = ROOT / "code/tools/adapt_chapter_candidate_b.py"
    spec = importlib.util.spec_from_file_location("old_chapter_adapter", path)
    module = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    spec.loader.exec_module(module)
    assert set(module.SCHEMA_PAIRS) == {"b-graph-trial/0.7", "b-graph-trial/0.8"}
    try:
        module.adapt(ROOT / "reference/artifacts/graph.json",
                     ROOT / "reference/artifacts/check.json")
    except ValueError as exc:
        assert "unsupported graph schema" in str(exc), str(exc)
        return str(exc)
    raise AssertionError("old chapter adapter accepted G0.9")


def replay(workdir: Path, expected: dict) -> dict:
    if workdir.exists() and any(workdir.iterdir()):
        raise ValueError("replay workdir must be empty")
    workdir.mkdir(parents=True, exist_ok=True)

    def deny_network(*_args, **_kwargs):
        raise RuntimeError("network disabled during portable replay")
    socket.socket.connect = deny_network
    socket.socket.connect_ex = deny_network
    socket.create_connection = deny_network

    sys.path.insert(0, str(ROOT / "code/src"))
    from annotation.recognition.pipeline import run_pipeline
    from annotation.recognition.pipeline_quality import audit_pipeline

    inputs = [ROOT / "inputs/source/source.json", ROOT / "inputs/context.json",
              ROOT / "inputs/review.json"]
    results = {}
    for label, expected_hits in (("cold", 0), ("warm", 3)):
        report = run_pipeline(*inputs, workdir, use_ocr=False,
                              evidence_path=ROOT / "inputs/evidence.json")
        audit = audit_pipeline(*inputs, report, workdir,
                               evidence_path=ROOT / "inputs/evidence.json")
        check_artifact(report)
        check_artifact(audit)
        rp, ap = report["payload"], audit["payload"]
        assert rp["pipeline_state"] == "READY" and ap["accepted"] is True
        assert rp["counts"]["cache_hits"] == expected_hits
        assert rp["decision"] == ap["decision"] == "HOLD"
        assert rp["business_acceptance"] is ap["business_acceptance"] is False
        assert rp["transcription_verified"] is ap["transcription_verified"] is False
        assert rp["platform_actions"] == ap["platform_actions"] == []
        stages = rp["stages"]
        assert tuple(row["stage_id"] for row in stages) == STAGES
        actual_refs = {row["stage_id"]: row["result_ref"] for row in stages}
        assert actual_refs == expected["original_refs"]
        results[label] = {"report_ref": ref(report), "audit_ref": ref(audit),
                          "counts": rp["counts"], "result_refs": actual_refs,
                          "decision": rp["decision"], "integrity_accepted": ap["accepted"]}
    return results


def main() -> None:
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--workdir", type=Path, required=True)
    parser.add_argument("--receipt", type=Path)
    args = parser.parse_args()
    static = verify_static()
    old_reader_error = reject_old_reader()
    replay_result = replay(args.workdir, static)
    result = {"schema_version": "b-viewer13-v3-portable-replay/0.1",
              "code_commit": "b5cc1ea2a0cc1b50b051ffc5ad429e7b473f516a",
              "manifest_files": static["manifest_files"],
              "source_sha256": static["source_sha256"],
              "original_result_refs": static["original_refs"],
              "original_runs": static["original_runs"],
              "old_chapter_reader_rejected": old_reader_error,
              "replay": replay_result,
              "new_ocr_model_network_calls": 0,
              "business_decision": "HOLD"}
    if args.receipt:
        args.receipt.parent.mkdir(parents=True, exist_ok=True)
        args.receipt.write_text(json.dumps(result, ensure_ascii=False, indent=2,
                                          sort_keys=True) + "\n", encoding="utf-8")
    print(json.dumps({"code_commit": result["code_commit"],
                      "manifest_files": result["manifest_files"],
                      "old_reader_rejected": True,
                      "cold_cache_hits": replay_result["cold"]["counts"]["cache_hits"],
                      "warm_cache_hits": replay_result["warm"]["counts"]["cache_hits"],
                      "result_refs_match": True, "decision": "HOLD"},
                     ensure_ascii=False, sort_keys=True))


if __name__ == "__main__":
    main()
