# 46007447 第 5 页 viewer-13 结构 v3 离线交接包

固定代码提交：`b5cc1ea2a0cc1b50b051ffc5ad429e7b473f516a`。本包内 `code/` 包含该提交的 `src/`、运行 CLI 与旧章节适配器；58 个代码文件逐字节匹配 Git blob，不使用共享工作树的未提交文件。初始 `git archive` 在本机将两份 CSS/HTML 文本转换为 CRLF；打包前已从固定提交恢复其 Git blob 原字节。

已观察原图 `inputs/source/46007447_page_12.jpg` 为 viewer-13、模型目视印刷页 5，1219×1691，SHA-256 `997b37d35fca57f73ab71e53f6721be145d10c436deab5fab38bf1ae0d31dc1e`。`inputs/` 包含来源声明、原图、既有 baseline、context 0.2、review、冻结 evidence 0.4；baseline 仅为来源追溯，缓存重放不重新运行 OCR。

`reference/artifacts/` 是原冷运行的 E0.4、G0.9、Check0.9；`reference/reports/` 保存原冷／暖／损坏缓存恢复报告与独立审计；`reference/objects/` 保存这些报告指向的阶段对象；`reference/evaluation.json` 和独立终审报告保存既有结论。本包重新校验所有成员字节、源图尺寸、输入收据、阶段对象和 `result_ref`。

在解包根目录、具备本机 Python 依赖（至少 numpy、Pillow、opencv-python）的环境运行：

```text
python replay_verify.py --workdir <一个空目录> --receipt <回执文件.json>
```

脚本禁用网络，不启用 OCR／模型，从包内输入在固定代码上冷、暖重放，核对 E/G/Check 引用、3 阶段缓存计数和 `HOLD`。旧章节适配器只接受配对的 G/Check 0.7 或 0.8；包内还会实测它拒绝 G0.9，故不能把此结果直接送入旧 reader。

结构结果为 2 题实体（Q8 与变式）、1 个共享材料、3 个任务、48 条来源行、0 个答案、12 个待处理问题。技术结构集成已通过，文字、数学、图形边界与整章完整性尚未人工核准，业务状态保持 `HOLD`；未替换旧六图内容图谱，也未修改网站标注。历史失败证据仍在仓库 `docs/reviews/viewer13-reviewed-layout-v1-failure-report.md`、`docs/reviews/viewer13-reviewed-layout-v2-failure-report.md` 与相应 fixtures，本包不重复附入。原验证归档 SHA-256 `c27416c3f142088e1ca13622b1fdae28c731104b155e1d40a0b510f3b2066d4f`，本包新增独立可搬运重放，不声称重跑 65 项测试。
