"""Verify local package bytes, pixels and referenced candidate identities, not semantic truth."""
import hashlib
import json
from pathlib import Path
from PIL import Image

ROOT = Path(__file__).resolve().parent

def sha(data):
    return hashlib.sha256(data).hexdigest()

def read(relative):
    p = (ROOT / relative).resolve()
    assert p.is_relative_to(ROOT) and p.is_file(), relative
    return p.read_bytes()

def artifact(relative, expected):
    obj = json.loads(read(relative))
    assert {k: obj[k] for k in expected} == expected, relative
    canonical = json.dumps(obj['payload'], sort_keys=True, ensure_ascii=False,
                           separators=(',', ':'), allow_nan=False).encode()
    assert sha(canonical) == obj['content_hash'], relative
    return obj

def verify():
    manifest = json.loads(read('manifest.json'))
    actual = {p.relative_to(ROOT).as_posix() for p in ROOT.rglob('*') if p.is_file()}
    assert actual == set(manifest['files']) | {'manifest.json'}
    for name, desc in manifest['files'].items():
        data = read(name)
        assert len(data) == desc['bytes'] and sha(data) == desc['sha256'], name
    c = json.loads(read('crosswalk.json'))
    assert c['decision'] == 'HOLD'
    assert c['human_verified'] is False and c['graph_assignment_performed'] is False
    assert c['independent_final_review_completed'] is False and c['platform_actions'] == []
    assert c['unassigned_count_before'] == c['unassigned_count_after'] == 19
    for name, digest in c['input_file_sha256'].items():
        assert sha(read(name)) == digest, name
    qg = artifact('inputs/question-graph.json', c['question_graph_ref'])
    app = artifact('inputs/question-content.json', c['question_content_ref'])
    ag = artifact('inputs/answer-graph-revision8.json', c['answer_graph_ref'])
    assert app['payload']['answer_matching_performed'] is False
    assert app['payload']['source_graph_archive'] == qg
    assert len(qg['payload']['questions']) == 6 and len(ag['payload']['answers']) == 66
    assert len(ag['payload']['unmatched_answer_ids']) == c['unmatched_answer_entities_before'] == c['unmatched_answer_entities_after'] == 32
    assert all(x['candidate_answer_id'] in ag['payload']['unmatched_answer_ids'] for x in c['candidates'])
    review = c['independent_candidate_identity_review']
    assert sha(read(review['report'])) == review['sha256']
    sources = {}
    for s in c['source_files']:
        assert sha(read(s['path'])) == s['sha256']
        im = Image.open(ROOT / s['path']).convert('RGB')
        assert list(im.size) == s['size']
        sources[s['asset_id']] = im
    assert len(sources) == 3
    regions = {}
    for r in c['source_regions']:
        assert r['region_id'] not in regions
        box = r['bbox_xyxy']; im = sources[r['asset_id']]
        assert all(type(v) is int for v in box)
        assert 0 <= box[0] < box[2] <= im.width and 0 <= box[1] < box[3] <= im.height
        assert sha(read(r['path'])) == r['sha256']
        crop = Image.open(ROOT / r['path']).convert('RGB')
        assert crop.size == im.crop(box).size
        assert crop.tobytes() == im.crop(box).tobytes()
        assert sha(crop.tobytes()) == r['rgb_sha256']
        regions[r['region_id']] = r
    assert len(regions) == 9
    questions = {q['question_id']: q for q in qg['payload']['questions']}
    answers = {a['answer_id']: a for a in ag['payload']['answers']}
    assert [x['printed_number'] for x in c['candidates']] == ['11','12','13','14','15','16']
    assert len({x['candidate_answer_id'] for x in c['candidates']}) == 6
    for x in c['candidates']:
        q = questions[x['question_id']]; a = answers[x['candidate_answer_id']]
        assert q['printed_number'] == a['printed_number'] == x['printed_number']
        assert q['section_path'] == a['section_path'] == x['section_path']
        assert q['asset_id'] == x['question_asset_id'] == 'viewer-15'
        assert a['asset_id'] == x['answer_asset_id'] == 'viewer-173'
        assert q['selected_answer_id'] is None and q['candidate_answer_ids'] == []
        assert x['answer_text_verified'] is False and x['verification_status'] == 'UNVERIFIED'
        assert x['existing_answer_source_line_ids'] == a['source_line_ids']
        assert all(r in regions for r in x['answer_region_ids'])
        rejected = {v['answer_id'] for v in x['same_number_rejected']}
        expected = {v['answer_id'] for v in answers.values() if v['printed_number'] == x['printed_number'] and v['section_path'] != x['section_path']}
        assert rejected == expected
    assert c['candidates'][4]['answer_region_ids'] == ['q15-start','q15-continuation']
    return {'integrity_verified': True, 'source_images': 3, 'pixel_regions': 9,
            'candidate_pairs': 6, 'production_assignment_performed': False,
            'semantic_or_human_acceptance': False, 'decision': 'HOLD'}

if __name__ == '__main__':
    print(json.dumps(verify(), ensure_ascii=False))
