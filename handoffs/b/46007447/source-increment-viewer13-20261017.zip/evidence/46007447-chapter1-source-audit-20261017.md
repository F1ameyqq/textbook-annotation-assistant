# 46007447 第一章来源核查（初轮）

时间：2026-10-17，Asia/Shanghai  
职责：只读来源核查；未修改共享仓库、网站标注、共同状态或既有输出包。  
共享仓库核查基线：`c3cc2df7a0be24c125c83681c0499c0d328d78f6`。  
目标章节：`dir-1792063578574-ug3232apl`，第一章“勾股定理”。

## 结论

当前只能冻结“6 个已观察资产”，不能冻结第一章完整分母。可核实的观察顺序是印刷页 2、3、4、6、25、26；其中印刷页 25–26 是参考答案页，印刷页 26 只在页首继续第一章内容，随后已经进入第二章。题页至少缺印刷页 5，第一章其余题页及题页结束边界仍未知；不能从 214 页全书元数据、22 个目录题节点或这 6 个资产外推章节页数。

现有章节报告的结论与本轮字节核查一致：`inventory_frozen=false`、`scope_state=PARTIAL`、`decision=HOLD`，唯一机器缺口码为 `INVENTORY_NOT_FROZEN`。

## 当前网站通道状态

- 目标站真实页面 URL（既有静态快照）：`https://www.usense.com/qieti/annotateUnified`。
- 本轮 Computer Use 能唯一识别一个 Microsoft Edge 窗口；在读取页面状态时停止，原文为：`Computer Use has been stopped for this turn because it could not determine the current browser URL on Windows with enough confidence to enforce policy.`
- 按 computer-use 技能停止规则，本轮没有继续浏览器输入、没有改用坐标或其他方式绕过，也没有网站写入、保存或提交。
- 因此下表的在线 URL/索引来自既有只读网络记录和本地 acquisition 记录；本轮没有宣称重新在线读回。

## 六个可核实资产

|观察身份|历史平台/资源身份|真实资产 URL|SHA-256|尺寸|可见印刷页|可见内容与边界|
|---|---|---|---|---|---:|---|
|`viewer-10`|viewer page 10；resource index 9；`46007447_page_9.jpg`|`https://oss-ef-bd-2026-gz.oss-cn-guangzhou.aliyuncs.com/upload_images/46007447/46007447_page_9.jpg`|`eb7cc17e6b58a55a005ce1cdef5bd5058ad258c3dd44dc891b3d830ed3db3626`|1217×1691|2|第一章 1“探索勾股定理”第1课时，题 1–9；题页。|
|`viewer-11`|viewer page 11；resource index 10；`46007447_page_10.jpg`|`https://oss-ef-bd-2026-gz.oss-cn-guangzhou.aliyuncs.com/upload_images/46007447/46007447_page_10.jpg`|`7c433368bbe7ccea76c1c2b8a53559a87a9e2b99e23d692ba9ca005e16f507a3`|1222×1692|3|同一课时，题 10–16；题页。|
|`viewer-12`|viewer page 12；resource index 11；`46007447_page_11.jpg`|`https://oss-ef-bd-2026-gz.oss-cn-guangzhou.aliyuncs.com/upload_images/46007447/46007447_page_11.jpg`|`774c8a29bbdcaa35fcb88479129d2b523ec077edfa4e0ac3db6f11e9bcae9b87`|1220×1692|4|第2课时“勾股定理的验证及简单应用”，题 1–7；题页。|
|`viewer-14`|viewer page 14；resource index 13；`46007447_page_13.jpg`|`https://oss-ef-bd-2026-gz.oss-cn-guangzhou.aliyuncs.com/upload_images/46007447/46007447_page_13.jpg`|`4186d57ffad14f576fe7c967c96697d25c83ffe3512217c79b8371134181c1d9`|1218×1694|6|第一章 2“一定是直角三角形吗”，题 1–10；题页。|
|`viewer-173`|viewer page 173；resource index 172；`46007447_page_172.jpg`|`https://oss-ef-bd-2026-gz.oss-cn-guangzhou.aliyuncs.com/upload_images/46007447/46007447_page_172.jpg`|`a231f0247cd0444cc34ed699c4cca99245d2ac6cfda5ef10a38ca3f8164510be`|1148×1621|25|第一章参考答案；含 1、2、3、小专题1、小专题2及反思等答案。19 条未归属行全部来自此资产。|
|`resource-173`|resource index 173；`46007447_page_173.jpg`；不是 `viewer-173`|`https://oss-ef-bd-2026-gz.oss-cn-guangzhou.aliyuncs.com/upload_images/46007447/46007447_page_173.jpg`|`8380f9a1872c830b1cf4fba12fa00e3b6d9c50ddaed357587de7333086e9cdbf`|1145×1620|26|页首续第一章反思答案，随后“回顾与思考（一） 勾股定理”；在“核心素养提升 12.B”后进入“第二章 实数”。只有该边界前属于第一章答案尾部。|

重要身份边界：`viewer-173` 与 `resource-173` SHA、尺寸、印刷页和 URL 均不同，不能因数字 173 相同而合并。现有 `source-descriptor.json` 中的 reading order 0–5 只是“观察清单顺序”，不是完整章节连续页序。

## 只读样本包与目录

- `46007447只读样本包.zip` SHA-256：`8c6b872805d9dd9f2c9c128fb68c8afd9aab240c6525c35169ce4241c13a8307`；共 19 个成员，其中 5 张完整原图。包内 `scope_id=existing-annotations-five-observed-pages`，不能充当第一章分母。
- `directory.json` SHA-256：`a639dbdf852298540a5b5ac4351f1562c1ec1249a6001cd7c95708fa044b08b5`；第一章有 9 个子组。
- 目录中只有“1 探索勾股定理 / 第1课时”下 1–21 共 21 个题节点，以及“2 一定是直角三角形吗”下题节点 22；共 22 个现有题节点。它们是平台已有目录进度，不是独立逐页清点得到的全章题数。
- 与 19 条未归属来源对应的 3 个目录组均存在，但其 `children=0`：
  - `dir-1792063578574-6n9eryan5`：小专题1 方程思想在勾股定理中的运用；
  - `dir-1792063578574-qfhemzkmn`：漫话勾股世界——教材 P6“阅读·思考”变式；
  - `dir-1792063578574-yzhjtylax`：小专题2 勾股定理在折叠问题中的运用。
- `pre-annotation-source.json` 只证明全书 `total_pages=214`、`manifest_exists=false`；不提供第一章边界。

## 19 条未归属来源的可读定位

19 条均绑定 `viewer-173`（印刷页 25、SHA `a231…10be`），保留 `UNASSIGNED`；本轮只核对来源位置，不把模型目视转写升格为人工金标。

|局部来源组|原行数|局部材料候选|原图位置（像素）|已知目录映射|仍缺|
|---|---:|---|---|---|---|
|`topic1-examples`|2|明确【例1】【例2】共 2 个|右栏，context window 6，约 y=840–1088；活动框 `[577,837,1079,889]`|小专题1 目录组存在，`children=0`|相应题页原图、稳定 page/asset ID、平台题目 ID、逐条题答映射|
|`math-world`|5|未编号阅读材料 1 个，含 (1)(2)(3) 与配图|左栏，window 2，约 y=1010–1240；活动框 `[54,1012,548,1240]`|漫话勾股世界目录组存在，`children=0`|完整题页及图形区域、稳定 page/asset/question ID、混合行字级几何|
|`topic2-example`|6|原文只有【例】，未编号例题 1 个|右栏，window 7，约 y=1113–1260；活动框 `[576,1113,1079,1207]`|小专题2 目录组存在，`children=0`|相应题页、稳定 ID、完整公式核对；不得伪造“例1”|
|`topic2-training`|6|局部题号 1–5，共 5 个训练材料|右栏，window 7，约 y=1113–1260；答案行框 `[577,1224,805,1261]`|同一小专题2 目录组存在，`children=0`|5 个题页题干、稳定 ID；混合 OCR 行 `1.C2.`、`3.14` 的精细几何与题号分割|

19 个原始 line IDs：

- 小专题1：`viewer-173/ocr/86`、`/87`。
- 漫话勾股世界：`/102`、`/104`、`/108`、`/110`、`/112`。
- 小专题2例题：`/111`、`/113`、`/114`、`/115`、`/116`、`/117`。
- 小专题2训练：`/119`、`/120`、`/121`、`/122`、`/123`、`/125`。

具体开放项保持不变：`QUESTION_IDENTITY_NOT_CAPTURED`、`FORMULA_TRANSCRIPTION_UNVERIFIED`、`RAW_MIXED_ROW_GEOMETRY`、`READING_DIAGRAM_REGION`。最关键的来源缺口不是答案页不可读，而是 4 组/9 个材料对应的题页与平台稳定身份未采集。

## 当前明确未知清单

1. 第一章全部题页/答页资产数与完整页序；章节题页结束边界未知。
2. 印刷页、viewer page、resource index、平台 page ID 的全章可靠映射；当前只确认表中 6 个点，不推广 N−1。
3. 至少缺印刷页 5；其真实 viewer/resource/URL/asset ID 未核实，不猜测或批量扫描。
4. 第一章 9 个目录子组各自对应的题页范围；7 个组没有任何题节点，现有 22 节点不是章节分母。
5. 19 条未归属答案的 9 个题材料所对应题页、稳定 question ID 与可验证题答关联。
6. 印刷页 25/26 的章节答案边界之外，是否还有第一章答页；当前只能确认页 26 上可见的切换点。

## 证据路径

- 只读样本包：`C:/Users/LIHAOYANG/Documents/Codex/2026-10-16/ni/outputs/46007447只读样本包.zip`
- 五图、目录与历史网络记录：`C:/Users/LIHAOYANG/Documents/Codex/2026-10-16/ni/work/usense-readonly/`
- 第六图及获取回执：`C:/Users/LIHAOYANG/Documents/Codex/2026-10-16/ni/work/adjacent-source/`
- 六资产章节观察清单：`C:/Users/LIHAOYANG/Documents/Codex/2026-10-16/ni/work/textbook-annotation-assistant/data/runs/46007447-chapter1-observed-source/`
- 19 条来源身份：`C:/Users/LIHAOYANG/Documents/Codex/2026-10-16/ni/work/textbook-annotation-assistant/evaluation/book-46007447-unassigned-identities.json`
- 章节边界记录：`C:/Users/LIHAOYANG/Documents/Codex/2026-10-16/ni/work/textbook-annotation-assistant/docs/b-chapter-46007447.md`

## 复核动作与结果

- `git rev-parse HEAD`：退出码 0，得到完整基线 `c3cc2df7a0be24c125c83681c0499c0d328d78f6`。
- PowerShell/.NET 只读列举 zip 成员、计算 SHA-256、解码 6 张 JPEG 尺寸：退出码 0；值与现有 descriptor 全部一致。
- PowerShell 解析 `directory.json`：退出码 0；第一章 9 个子组、22 个现有题节点及上述 3 个空子组均实际读出。
- 本地原图逐张视觉核查：6 张均成功打开；可见印刷页与内容边界如表。
- Computer Use：`list_apps` 成功且 Edge 唯一；`get_window_state` 因无法可靠确定 URL 被安全停止。此项没有网站动作。

## 下一步与恢复条件

浏览器恢复条件满足其一后，来源成员才继续网站只读采集：

1. 新一轮中浏览器控制能明确返回当前 Edge 标签 URL 为 `https://www.usense.com/qieti/annotateUnified`，并成功读取标签状态；或
2. 用户提供该标签的可用 tab 引用，使浏览器接口可直接绑定目标标签；或
3. 用户/平台按正常只读导出流程提供第一章候选题页与答页原图清单（包含真实 URL 或稳定资产 ID）。

恢复后应从目录分组进入、逐页记录真实 viewer page/resource index/image URL/SHA/尺寸/印刷页/前后边界；先覆盖缺失印刷页 5 及小专题1、漫话、小专题2对应题页。不得按 `...page_N.jpg` 猜测批量扫描。只有冻结完整题页与答案页清单并由第二人独立清点，G2 才能从当前 HOLD 进入后续章节门禁。

## 重新登录后的第二轮恢复（2026-10-17）

用户明确告知已在 `https://www.usense.com/qieti/home` 重新登录后，本轮重新执行只读恢复；这是上次安全停止后的新外部状态变化。

- Edge 标签清单实际返回站点首页 `https://www.usense.com/qieti/home`（标题“数据标注平台”）和旧标注页 `https://www.usense.com/qieti/annotateUnified`。
- 两个旧站点标签仍被既有输出包会话 `01a1445e-2f9f-7c73-8a2a-1f16b0f341fb` 的浏览器会话占用。经用户既有团队授权联系该会话后，对方确认只重置浏览器控制、保留标签和登录状态、未采集或写入；但浏览器后端仍报告旧标签归属原会话，不能由本会话接管。
- 本会话在同一 Edge 配置中新建了独立标签，实际 URL 为 `https://www.usense.com/qieti/home`、标题“数据标注平台”，标签组为“🔎 第一章来源”。创建调用曾超时，但随后标签清单确认页面确已创建。
- 该新标签的 URL 与标题可读；DOM、截图和 `pageAssets` 三条只读路径均返回 `Debugger unattached`。因此当前只能验证站点首页 URL，不能验证已选择书 `46007447`、目录状态或页图资产。
- 新标签已标记 handoff 保留；没有点击选择书、没有输入、没有标注、保存、提交、上传、付费或下载资产。
- 新增可核实页：0。原 6 资产及 19 条来源定位结论不变；不因登录成功或标签存在而解除 `PARTIAL/HOLD`。

本轮后续恢复条件更具体：用户需在 Edge 中打开“🔎 第一章来源”标签，并让 Codex/浏览器控制扩展附着到该标签（使 DOM 或截图读取至少一项成功）；或由产品端完全释放旧 browser session 对原站点标签的所有权。满足后先只读确认当前 URL 和书籍 `46007447`，再从可见目录/页导航采集真实来源，仍禁止按文件名规律批量猜测。

## 第三轮：连接成功、书籍实证与再次脱离（2026-10-17）

用户再次附着扩展后，本轮用工具而非口头状态实际验证成功：

- 首页 DOM 可读，URL `https://www.usense.com/qieti/home`，登录显示 `YX-雪秀`。
- 经首页可见“通用标注”链接进入 `https://www.usense.com/qieti/annotateUnified`；在“选择认领的书籍”对话框中实际读到唯一一行：ID `46007447`、书名 `0917-136-9787555396581-名校课堂八年级数学上册`、状态“标注中”、标注人 `YX-雪秀`。只点击“选择”以加载只读工作视图。
- 页面随后明确显示当前书 `46007447`，目录第一章展开；实际 DOM 再次确认 9 个第一章子组、已有题节点 1–22，且第 4 题显示“部分失败”。第2课时、漫话、3 勾股定理的应用、小专题1、小专题2、反思、回顾与思考、周测等组仍没有题节点。
- 当前题目区/答案区初始页码均为 1；页面资源清单实际观察到题页资产 `46007447_page_0.jpg`，对应可见 API `...pre_annotation/46007447?pageNum=1...`。这只证明当前 viewer page 1 与资源文件 page_0 的本书局部映射，不用于推算其余页。
- 页面用两个 canvas 呈现题目区和答案区；第一页时分别为 592×781、498×781 的显示画布。原图尺寸仍须通过资产下载后单独核对，不能把 canvas 尺寸当原图尺寸。
- 随后使用题目区自身页码控件从 1 跳转到 13，以采集现有观察序列中缺失的印刷页 5（不是直接猜 URL）。导航加资产清单读取超过 30 秒，调用超时并重置控制内核；页面跳转是否完成未知。重置后站点标签仍存在且 URL 仍为 annotateUnified，但 DOM 再次返回 `Debugger unattached`。
- 由于动作结果未知，本轮未重复页码输入，也未根据 `page_12.jpg` 规律下载。新增冻结原图仍为 0；书籍身份和目录读回是新增实证，来源范围仍 `PARTIAL/HOLD`。

下一次恢复应再次附着当前站点标签；所有页面读取调用使用更长的有界超时，并把“页码改变”和“资产清单读取”拆成两步。第一步先读回题目区页码是否为 13；只有确认后才从 `pageAssets` 取得当前页面真实 URL 并下载/哈希。不得重放状态未知的输入。

## 第四轮：缺失印刷页 5 已冻结；顺序采集在 viewer 16 后再次脱离（2026-10-17）

用户再次附着后，本轮实际验证新标签 `1199071635` 可读并成功载入目标书：

- 标签 URL 为 `https://www.usense.com/qieti/annotateUnified`，登录显示 `YX-雪秀`。书籍选择表再次只显示 ID `46007447`、书名 `0917-136-9787555396581-名校课堂八年级数学上册`、状态“标注中”、标注人 `YX-雪秀`；选择后页面页眉明确显示 `46007447`，目录与 22 个已有题节点重新读回。
- 题目区初始 viewer page 为 1。使用页面自身页码控件跳至 13 后，输入框实际读回 `13`；资产清单实际观察到 API `https://www.usense.com/qieti/api/annotate_pic/pre_annotation/46007447?pageNum=13&annotationType=mr_pre` 与图像资产 ID `58bb638d0ad845af`、文件名 `46007447_page_12.jpg`、URL `https://oss-ef-bd-2026-gz.oss-cn-guangzhou.aliyuncs.com/upload_images/46007447/46007447_page_12.jpg`。
- 该图经 `pageAssets.bundle` 下载成功并复制到本轮只读工作目录 `work/browser-assets/46007447_page_12.jpg`；SHA-256 为 `997b37d35fca57f73ab71e53f6721be145d10c436deab5fab38bf1ae0d31dc1e`，尺寸 1219×1691，417144 字节。原图目视确认右下角印刷页码为 5；上半页承接“勾股定理的验证及简单应用”第 8 题及变式，下半页为“漫话勾股世界——教材 P6‘阅读·思考’变式”。因此缺失印刷页 5 的真实映射已从未知改为：viewer 13 / resource file `page_12` / 上述真实 URL 与 SHA。
- 随后只用页码控件顺序前进。一次多页循环超时，回读确认最终 viewer 输入框停在 16；资产记录证明 viewer 14、15 的 API 请求曾实际发生，其中 viewer 15 还观察到图像资产 ID `5e95d184d28da244`、文件名 `46007447_page_14.jpg`、URL `https://oss-ef-bd-2026-gz.oss-cn-guangzhou.aliyuncs.com/upload_images/46007447/46007447_page_14.jpg`。但该图尚未 bundle/download/hash/目视，故只能列为“已观察资产”，不能计入冻结页清单。viewer 14 只见 API 请求，未见对应图像资产；viewer 16 最初仅回读输入值，之后按状态核对再按一次 Enter，才观察到 `...pageNum=16...` 请求，仍未观察到图像资产。
- 尝试截取 viewer 16 显示状态再次超时并重置控制内核；重置后的第一次绑定返回 `Debugger unattached`。因此本轮在此安全停止，不重复 viewer 16 动作、不猜测 `page_15.jpg` URL，也不把 viewer 14–16 推断为印刷页 6–8。

本轮新增冻结原图：1 张（viewer 13 / 印刷页 5）。第一章来源范围仍为 `PARTIAL/HOLD`：章起始前界、viewer 14 之后的完整题页、题页结束边界、答案页前界及 19 条未归属答案对应题页均未完成。恢复后必须每次只做一个页的一个动作或读取；先从当前 UI 实际页码与 `pageAssets` 状态继续，并优先冻结已观察但尚未下载的 viewer 15 图像。另需通过实际页面控件检查 viewer 9 及其前页，确认第一章标题/起始边界，不能由 viewer 10=印刷页 2 反推。
