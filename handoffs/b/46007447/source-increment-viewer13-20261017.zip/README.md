# 46007447 第一章来源增量：viewer 13 / 印刷页 5

本包只增加一张由网站只读 pageAssets.bundle 取得并验证的原图，不代表整章题页或答案页齐全。`facts.json` 记录实际观察到的 URL、资产 ID、viewer 页、印刷页、原图尺寸与 SHA-256；`manifest.json` 给出所有文件的相对路径、字节数与 SHA-256。`evidence/` 保存第四轮来源核查报告的原始完整字节，供复核上下文。

原图仅作来源材料，内容范围未经过人工签核。第一章门禁仍为 PARTIAL/HOLD。未修改网站标注；不含凭证、Cookie 或浏览器状态。
