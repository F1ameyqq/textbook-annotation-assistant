# 离线书页预框演示版 · 2026-10-21

先用仓库 evaluation/book-46007447-prebox-demo-20261021.json 核对ZIP与manifest摘要。
需要已有Python3.11+、NumPy、Pillow、OpenCV（requirements-b.txt），不会自动安装依赖。
本包不需要OCR/公式模型、浏览器登录态、账号、网络服务或付费调用。

在本目录运行，打开打印的本机地址：
python -X utf8 tools/prebox_b.py --workspace data/runs/demo --images examples/46007447_page_12.jpg examples/46007447_page_14.jpg

Windows也可双击start-demo.cmd。后续重开只传--workspace，无须再次传图片。
导入后生成几何候选：可画框、移动、四角调整、改类型、保存和导出自包含JSON。
两张示例分别17/16个几何候选，不是33道题，不保证题块、图形或共享材料完整。
所有框DRAFT，工作区HOLD。MANUAL只表示人工调整，网站标注不参与。
JSON携带图片，可在空工作区重新导入；导入框统一记为IMPORTED_DRAFT。
EXIF旋转须先转正另存，单图25MB/4000万像素内；工作区100页/原图36MB/10000框内。

离线复核包成员并重放导入、自动预框、保存、JSON恢复和历史重开：
python -X utf8 tools/verify_prebox_demo_b.py --out replay-new

回归（已有Python依赖；Node只供第二条坐标回归）：
python -X utf8 -m unittest discover -s tests -v
node tests/prebox_geometry.cjs

使用说明见 docs/b-prebox-demo-20261021.md；其中仓库机器回执/主线链接请到固定仓库查阅。
本包不包含浏览器令牌、本机数据库或人工验收记录；不是A公共执行合同或整章交付。
