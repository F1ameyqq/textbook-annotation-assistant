@echo off
cd /d "%~dp0"
if exist "data\runs\demo\drafts.sqlite3" (
  python -X utf8 tools\prebox_b.py --workspace data\runs\demo
) else (
  python -X utf8 tools\prebox_b.py --workspace data\runs\demo --images examples\46007447_page_12.jpg examples\46007447_page_14.jpg
)
pause
