# B side Q4/Q9/Q16 revision8 — MODEL_DRAFT / HOLD

Fixed code baseline: `af8e17c2ed60219db4f0da40daea6be0396c4b5b`. Fixed run: `pipeline-run-85c20d4acab3496ea33296b54cc5b8e7`. This is a successor to the earlier local handoff; the earlier ZIP is retained unchanged. The run has 14 READY stages but the business decision remains HOLD. It covers five observed pages and distinct adjacent `resource-173`, not the full first chapter. No website annotations were changed.

Current Evidence/G07/Check07 are in `artifacts/`; all 14 original stage wrappers and the full report are included. `manifest.json` gives relative paths, byte sizes, SHA-256, exact final references and all 45 input receipts. All 45 receipt files match the recorded bytes. The observed inline bundle contains all 95 recorded consumed members with exact sizes and SHA-256. 29 image crop receipts were matched against original source pixels, dimensions and image bytes at export.

The revision8 plan and application use trial schema 0.3; G07/Check07 use trial 0.8. An older 0.7 review interface cannot consume this graph/check without migration. `artifacts/application.json` and `inputs/content-revision-plan.json` retain those complete objects.

The Q4/Q9/Q16 source-region text is MODEL_DRAFT: no human transcription approval, no business acceptance and no platform action. Graph candidates remain 34 questions/66 answers; Check07 has 134 issues. The package must not be treated as a complete chapter, public contract acceptance or A-side consumer PASS. A reception is pending.

Verify without a B runtime: `python verify_b_handoff.py B-46007447-Q4-Q9-Q16-revision8-HOLD-2026-10-17.zip --self-test` (or run `tools/verify_b_handoff.py` from the repository). The self-tests reject stale graph refs, unknown assets and corrupted adjacent resource bytes. `REPLAY.md` gives the exact offline CLI inputs and staging steps; `requirements-b.txt` lists B's local runtime dependencies.
