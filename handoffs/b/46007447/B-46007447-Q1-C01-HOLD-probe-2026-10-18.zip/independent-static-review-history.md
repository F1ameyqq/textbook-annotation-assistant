# Q1 A02 HOLD probe — independent static review and acceptance plan

Date: 2026-10-18  
Scope: book `46007447`, question `q-e92a499995ca1bbd570a2a09` only  
Current verdict: **STATIC ROUTE ACCEPTABLE; ACTUAL OUTPUT PENDING**  
Business/content verdict: **HOLD**

## Frozen A basis

The reviewed A tree is the published stage-2 source snapshot identified as commit `37089f9e0229da76ae1c45461b7e63929590be56`. The snapshot is not itself a Git checkout, so identity must be established through the B-side 76-member source pin, not `git rev-parse`.

The following central A files match the original A publication manifest byte-for-byte:

- planner: `78c4242c48730eb7b8fec5e7c13b0164a111a6475383c5a4cc4e9fb22c0bdfb4`
- in-memory simulator: `918e1c882d1ec7901386bdf9a4d0927c24cd0f756a919dd076a5a72134f7974d`
- TARGET checker: `a88d99f1f81fe33ce99a22a48e84585be663087e2eaeac27fa239ec9ccaedb3a`
- C01 semantic validator: `6b98eefe7c1a308f3846ba2f3acce1ffae5c64ec0b5c4d3675ee5872f055a0f7`
- C01 models: `993c6d5081dcb6dad0b20107ed68860564acee8390e65285fb5a36761cbc19b9`

The current normalized 76-member B pin file has SHA-256 `3174f9981ffc336b3d576d78afe3e6932e042521011555272dc94d9b564e1fe0`.

## Route permitted by the public contract

The proposed route is structurally valid as a **negative diagnostic chain**:

1. A C01 bundle contains the real Q1 `SourceBundle`, `EvidenceBundle`, and `QuestionGraph` as `OBSERVED`, with source assets remaining `ORIGINAL`.
2. B adds a five-check PRE_APPLY diagnostic whose decision is `HOLD`, not PASS.
3. A local empty `PlatformSnapshot` is explicitly `SYNTHETIC`, has no verified capabilities, grants no operations, and is labelled as not being a platform observation or authorization.
4. A's unchanged `check_target` recomputes TARGET. Because A02 supports only synthetic source chains, and because Q1's answer relation remains unresolved, TARGET must remain non-PASS.
5. A's unchanged `create_plan` may generate a valid `BLOCKED` diagnostic plan with no actions.
6. A's unchanged `MockSession.execute` short-circuits a BLOCKED plan into an `ExecutionReceipt` with `execution_mode=NOT_EXECUTED`, `results=[]`, and `write_disposition=NOT_EXECUTED`.

C01 forbids an `OBSERVED` artifact from depending on a `SYNTHETIC` artifact. It does **not** forbid a synthetic diagnostic artifact from depending on observed source evidence. Therefore the observed Q1 input plus synthetic local target is valid for this fail-closed diagnostic route. It would not be valid evidence of a positive observed/platform execution.

## Static contract traps

- `UNSELECTED` is not a valid C01 answer-relation status. An unapproved candidate must use `UNRESOLVED` or `AMBIGUOUS` and keep `selected_fragment_ids=[]`.
- PRE_APPLY `HOLD` is valid only when all five required checks exist and at least one specific issue is present. HOLD with no issues fails schema validation.
- `READY` requires both PRE_APPLY and TARGET PASS. Any held/failed check can only produce `BLOCKED`; a blocked plan must contain no actions and must carry blocking issue IDs.
- A blocked receipt must be NOT_EXECUTED and contain no action results.
- Out-of-bounds/non-finite boxes and duplicate region IDs are rejected by C01.
- Two different region IDs with an identical original-image bbox are currently accepted by generic C01. Exact duplicate geometry therefore needs a Q1-specific mapper/precheck assertion and must not be described as a generic contract rejection.
- A resource hash and image dimensions are checked independently by `load_bundle`, but this does not establish that the six regions are the intended Q1/D candidate. The frozen mapping JSON hash is the necessary semantic-package identity gate.

## Reviewed integration driver

Current driver: `tools/probe_q1_a_hold_b.py`, SHA-256 `a7a1872f0ccb8301941a671cb4270dde12fdb0a72afa56b41b1e543e011177e0` at the time of this review.

The driver correctly:

- verifies the entire 76-member A source tree before importing `annotation`;
- reloads copied mapping bytes and assets through A's independent public consumer;
- restricts the chain to book 46007447, one Q1, one policy, three mapped artifacts, observed/original provenance, unresolved answer matching, and six unique source geometries;
- labels the empty local target synthetic, supplies no capabilities or allowed operations, and obtains TARGET/plan/receipt from unchanged A code;
- verifies zero actions, zero dispatches, empty action log, unchanged target state, and a NOT_EXECUTED receipt;
- records no platform request or model call and keeps all acceptance flags false.

Two initial review findings were addressed before execution:

1. New diagnostic artifacts now use a new timezone-aware probe timestamp, rather than inheriting the historical graph timestamp.
2. The mapping gate now fails closed while `MAPPING_SHA` is pending. It must be replaced with the final mapper JSON SHA before any run; the JSON embeds the resource, artifact, and evidence references that A then verifies against actual bytes.

The final run must be rejected if the expected mapping hash remains the pending sentinel or differs from the supplied mapping.

## Independent acceptance plan

The isolated checker is `work/q1_a_hold_acceptance.py`. It is prepared to run only after the mapper JSON and probe output are frozen. It will independently verify:

- exact A 76-member source pins;
- exact frozen mapping JSON SHA and all mapped assets through A `load_bundle`;
- book/Q1/scope and observed/original provenance;
- unresolved answer relation and absence of duplicate geometry;
- five-check PRE_APPLY HOLD with blocking issues;
- A TARGET non-PASS with both observed-input and unresolved-answer reasons;
- exact blocked issue ledger, zero-action BLOCKED plan, NOT_EXECUTED receipt, empty action log, and unchanged target state;
- all summary non-acceptance and zero-call flags.

It also performs these independent negative tests:

1. blocked plan fails `assert_plan_ready`;
2. changed current snapshot invalidates the old chain;
3. changed graph cannot reuse the old PRE_APPLY/TARGET;
4. changed policy cannot reuse the old PRE_APPLY/TARGET;
5. wrong source asset digest is rejected;
6. unknown candidate fragment is rejected;
7. out-of-bounds source geometry is rejected;
8. duplicate exact geometry is accepted by generic C01 but rejected by the Q1 high-level guard, documenting the capability boundary.

## What this cannot replace

- A06 read-only acceptance does not supply A's formal PRE_APPLY PASS.
- B's candidate mapping and a valid C01 envelope do not approve the answer D relation, text normalization, exclusions, or six semantic regions.
- The local synthetic target is not a platform observation, authorization, or capability proof.
- A TARGET failure, blocked plan, and NOT_EXECUTED receipt prove that the gate remained closed; they do not form a positive A/B simulation loop.
- Technical validation does not provide human verification, content correctness, platform persistence, submission, or business acceptance.
- Historical I01/Q22 evidence is neither run nor used as a substitute.

## Pending evidence

The final verdict remains pending until the content mapper supplies its frozen JSON, the driver pins that SHA, and root supplies the new output directory. No platform, model, pre-box, DeepSeek, or historical Q22 action is authorized or required for this acceptance.
