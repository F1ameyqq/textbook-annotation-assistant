# Q1 B source candidate → A C01 mapping candidate

Technical mapping result: **VALID C01 source/evidence/graph candidate**  
Business/release result: **HOLD**

Mapper configuration: `q1-c01-mapping-v2`  
Artifact creation time: `2026-10-18T12:05:44Z`

This directory maps only `Q1 q-e92a499995ca1bbd570a2a09` from the frozen B source-review candidate into the fixed A C01 proposal types. It does not create a check, plan, receipt, PASS decision, READY state, platform action, human approval, or A policy confirmation.

## C01 artifact refs

- Source: `source-q1-c01-55886e21fe56d8e891a268b7` / revision `1` / `100c8a5ac5f195e1de136eb550f63ce6dfa5340d9fec3add01d293fa4afddab7`
- Evidence: `evidence-q1-c01-55886e21fe56d8e891a268b7` / revision `1` / `abcec8c919eb1de18321a1335de81c549346169924d1f0ebbd0e909d758ac283`
- Graph: `graph-q1-c01-55886e21fe56d8e891a268b7` / revision `1` / `f6038862a0cca69d726aef466b7974aa3be0fb8ac8a310c248558680140b5d1b`
- Diagnostic policy: `policy-q1-c01-dd1bad730124ca11e6fdc7bf` / revision `1` / `f5517faf42c6c0d07fdcfbdfc9d05e92300effeef2e98c46a742471478037b0c`; `UNRESOLVED`, `PROPOSAL_ONLY`

## Deliberate semantics

- Both C01 assets retain the B candidate's exact JPEG SHA-256, dimensions, asset IDs, and `ORIGINAL` provenance.
- All three artifacts use `evidence_mode=OBSERVED`.
- Exactly six semantic regions are emitted: stem including the printed response parentheses, options A–D, and the D answer crop.
- The nested parentheses evidence region is not emitted separately. It is recorded in `mapping-sidecar.json` as absorbed by the stem, preventing a duplicate frame.
- Region provenance is `HISTORICAL` with `certainty=UNCERTAIN`; C01 has no honest `MODEL_VISUAL` enum and these regions are neither HUMAN-confirmed nor newly OCR/DETECTOR-produced.
- The answer fragment is the sole candidate, but `selected_fragment_ids=[]` and relation status is `UNRESOLVED`.

## Contract gaps preserved outside C01

`mapping-sidecar.json` retains the external B trial refs, source fragment IDs, normalization proposal, B changes, context-only regions and crops, relation-review basis, scope-applicability input, and HOLD flags. These are not forced into incompatible C01 fields.

Before mapping, the generator verifies the frozen B manifest SHA-256 `240622443df3c1f31cf76dc490fb7b2cedb9cecb09f47f086909cbe9e9fbd345` and every one of its listed members by path, byte count, and SHA-256. The closed C01 bundle carries only its direct resource closure; the original B package remains required for the candidate's embedded crop/context dependency closure.

The included policy exists only because a closed `c01-exchange-1` requires a policy list. It is explicitly `UNRESOLVED` / `PROPOSAL_ONLY`, with frame and OCR status `UNVERIFIED`; it is not A policy and cannot support an ordinary-choice positive target.

## Verification performed

The script validates the generated closed bundle with the fixed A `annotation.contracts.validate_bundle` consumer, including local JPEG bytes, dimensions, hashes, references, geometry, scope, question ownership, and the unresolved answer relation. Re-running into a new empty directory is deterministic.

## Remaining boundary

Root may append diagnostic PRE_APPLY/TARGET handling, but real Q1 inputs must remain OBSERVED/ORIGINAL. The A synthetic positive-target helper is inapplicable. Any plan should remain BLOCKED and any receipt NOT_EXECUTED unless a later, separately authorized and valid policy/check chain changes that conclusion. Business status remains HOLD.
