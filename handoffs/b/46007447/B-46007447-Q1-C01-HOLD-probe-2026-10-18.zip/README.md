# Real Q1 offline HOLD diagnostic

This archive records an actual negative-gate chain using unmodified A commit
37089f9e0229da76ae1c45461b7e63929590be56. It is not A acceptance or positive
simulation: B PRE HOLD -> A TARGET EXCEPTION -> BLOCKED -> NOT_EXECUTED.
No action was dispatched; target before/after are identical. Business HOLD.

- source-candidate/: complete 24-member original candidate plus its manifest;
  includes two originals and 13 source-pixel crops.
- mapping/: frozen C01 candidate, sidecar and manifest. Only C01 direct resources
  close within this folder; embedded native crop/context references use the
  complete source-candidate/ directory and the original B package below.
- run/: actual five appended stage bundles, current diagnostic, plan, receipt,
  empty action log, explicit local target fixture and unchanged before/after.
- independent-acceptance.json and q1_a_hold_acceptance.py: independent negative
  gate verification, not human approval. independent-replay-receipt.json records
  a second session's actual replay; its external directory is not this root run.
- minimal-rejection.json: exact A blocking reasons and refs.
- report.md: mapping limits and six A confirmation items.

External fixed dependencies (not rewritten or silently replaced):
1. A source directory at commit 37089f9e0229da76ae1c45461b7e63929590be56;
   all 76 src members are pinned in q1-a-stage2-source-pins.json.
2. Original B-46007447-Q16-offline-HOLD-2026-10-17.zip when auditing native
   E/G/Check dependencies: SHA256
   b2bed674f87cde7fb2df4fdf31dec9ede08f494fc6190f654abda51dd4dae89d.
   Available in the existing repository handoffs/b/46007447/.
3. Original candidate archive identity: SHA256
   3039645ca69c2604f542c479cb180049604788a3ca28ffac1b5063dee533afac;
   its complete extracted members are included here, never changed.

Run in a fresh Python process with Pydantic and Pillow. Existing evidence used
Python 3.11.8 / Pydantic 2.13.4 / Pillow 12.2.0, not a clean-install acceptance.
Use new output directories. These commands replay the frozen timestamps:

    python -X utf8 build_q1_c01_mapping.py --a-source <A-root> --b-candidate-dir source-candidate --output-dir <new-mapping> --created-at 2026-10-18T12:05:44Z
    python -X utf8 probe_q1_a_hold_b.py --a-root <A-root> --mapping <new-mapping>/c01-candidate-bundle.json --output <new-run> --pins q1-a-stage2-source-pins.json --created-at 2026-10-18T12:08:20+00:00
    python -X utf8 verify_q1_source_candidate_b.py source-candidate --base-package <original-B-zip>

Do not relabel OBSERVED inputs as SYNTHETIC. The empty synthetic diagnostic target
is not a platform observation, has no VERIFIED capabilities, and permits no
operations. A's real-source five-check producer and an OBSERVED/SIMULATED path,
plus explicit policy/content/relation acceptance, remain required.
