# 第1题来源修订候选 · HOLD

打开 review.html 查看两张原图派生的裁片、建议正文和区域；candidate.json 包含全部原图引用、区域、规范化记录及 A-Q1-01～06 确认事项。

本题为书46007447第一章第1课时第1题，题 ID q-e92a499995ca1bbd570a2a09，答案候选 D。B 已复核来源：补回作答括号，题干区域包括括号，四选项分别定位，D区域排除题号与下一个答案。所有改动只在此候选中；原图、原生图谱、检查与题答关系没有覆盖。

candidate 是 b-question-source-review-trial/0.1 / QuestionSourceReviewCandidate，不是 G0.7 或 A 公共合同。模型视觉复核不等于人工签核；decision 始终 HOLD，human_verified/production_applied/a_accepted/business_acceptance 均 false。

scope-applicability-proposal.json 包含31项旧范围问题：30项附非本题来源或实体依据，等待A单题范围政策确认；1项业务复核继续适用。未删除旧问题或减少19条未归属源行。

A待确认：新旁文件接收与固定引用；题号/括号/换行规范；6个语义组的平台映射及题答关系；31项问题适用性；C01新信封/摘要、政策、五项PRE_APPLY和模拟TARGET；已补交的历史E0.1引用必要性。

只读验证（需要Pillow）：

    python verify.py . --base-package /path/to/B-46007447-Q16-offline-HOLD-2026-10-17.zip

原包SHA b2bed674f87cde7fb2df4fdf31dec9ede08f494fc6190f654abda51dd4dae89d；原manifest SHA3952a42e5ea966a0ec039564c71dc1db242c061af807aa730ac1f7f015e8189f。完整依赖仍是原固定包和历史E0.1补件（B提交4bb0a0086c3f69e9ad46d55466295870a409ec59，handoffs/b/46007447/single-question-q1/historical-evidence-revision1.json），本候选不截断或替代旧依赖。

13个证据区域包含嵌套括号和上下文，不能都转成平台框；候选只有6个语义组，实际平台框数待A确认。括号的两个全角空格是建议规范化，不是原图可识别的字符编码。D的16×19来源框不是逐像素分割金标准；无原书解析，不生成空解析框。

本轮无新OCR、外部付费模型、平台请求、生产图谱修改、A计划或模拟执行。
