# Viewer-13 v3 hash clarification

The v3 patch is unchanged:

- `viewer13-reviewed-layout-v3.patch`
- SHA-256: `316a9ebb164135e1b40daf3c5b5ef7abccf518502c25bb119279494db243163b`

The source hashes in the v3 verification report were calculated in an LF
checkout. They are simultaneously that checkout's raw file SHA-256 values and
the repository's cross-platform `code_digest` values. `code_digest` reads text
before encoding it, so Python universal-newline handling normalizes a CRLF
checkout to LF.

The coordinating export used CRLF. Converting the verified LF files only from
LF to CRLF reproduces all four coordinating raw hashes exactly. No source text,
patch hunk, or behavior differs.

| File | LF raw SHA-256 / `code_digest` | CRLF raw SHA-256 |
|---|---|---|
| `offline.py` | `f5e125c77ed4c8d227d69570183e3421d1601d7b2716c11411ec1162561144bd` | `81ba385a8587eec4800f694ddcd36bbb2e73bf2fe730c856724e492c5eec14bd` |
| `pipeline.py` | `bb600b1aa457ae23bdca22f3787b0e488e048fbacdf46f73e3dcb2ca2908d31e` | `39dfd3aad238a707650ec71447ff0a22080bb3320f275efe3918b20e0a1cc6a9` |
| `pipeline_quality.py` | `afb71b3838da9094b92ac4b3cef6b48906a1d6e86855f23605d0a972166c453c` | `5695c7673463b1cbc10d9fdc27b280c1ad0b5192a8efa2c1280dadaab86f3e15` |
| `question_quality.py` | `69b5632f760eb9338931677d68f94a79d0a64308a56d506d9e7cf9fe4ddae961` | `0d42155e5e297635b2f8c9c51b5145379f9927bda313f584d85c1711f8d1f790` |

Verified source directories:

- Original implementation: `C:\Users\LIHAOYANG\Documents\Codex\2026-10-17\chapter1-content-sol56\work\viewer13-layout-design`
- Fresh replay: `C:\Users\LIHAOYANG\Documents\Codex\2026-10-17\chapter1-content-sol56\work\viewer13-v3-latest-replay`

The fresh replay was cloned at shared commit
`65139f43e5ae8a6caf3f9c8f9ded8834cbe3e2de`, then received the fixed patch.
Both directories have identical LF raw hashes for the four files above.

Therefore the v3 report hashes should be read as LF-normalized implementation
hashes (`code_digest`), not as a promise about the checkout's physical newline
bytes. The existing patch and bundle remain valid and were not overwritten.
