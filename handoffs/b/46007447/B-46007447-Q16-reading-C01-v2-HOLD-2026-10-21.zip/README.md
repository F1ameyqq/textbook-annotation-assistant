# Q16与三个阅读任务：固定离线候选输出包

日期2026-10-21。B输入基线d48b066；A消费者固定edf125961be9cdc1642652c038d99872b1c8cdc7。

## A直接读取

解压后在本目录运行（Python，已安装Pillow 12.2.0、Pydantic 2.13.4）：

```powershell
python -X utf8 tools/consume_q16_reading_a.py --a-source consumer-a --pins consumer-pins.json --delivery delivery --out a-readback.json
```

这个命令实际调用原字节A `annotation.contracts.load_bundle(..., verify_assets=True)`，读取全部Source/Evidence/Graph/Check及原图，逐项核对当前正文和配答，并输出完整读回。不会调用A业务、目标、计划、派发或平台。

`delivery/bundle.json`是实际C01入口；`delivery/delivery.json`是富文本、三问跨度与来源对照；`delivery/current-review.json`是本轮模型逐图记录；`delivery/pending-review.json`是绑定新内容的18项独立人工核对入口；`SOURCE-REVIEW.md`可直接看正文和原图裁片。

## 从固定输入重建并读回

```powershell
python -X utf8 replay.py --out ../q16-reading-replay-new
```

输出目录必须不存在。脚本校验全部清单成员，再在禁止网络与OCR/付费模型导入的独立进程重建46个交付文件并逐字节对照、调用固定A消费者并逐字节对照参考回执。不重验未携带历史父ZIP容器，不重跑历史全流水线，不下载依赖，不代表干净安装。

## 时间与版本

`delivery/generation.json`冻结本候选首次构建时读取的UTC生成时间、配置及A/B输入摘要。run/artifact身份同时绑定这些值；同一冻结输入重放身份不变，改变时间/配置会生成不同run/artifact身份，题目/任务/片段等语义ID保持。旧固定午夜候选作为历史保留，不能当实际生成时间。

## 固定范围与边界

- Q16：viewer-15/印刷7四题目块，viewer-173/印刷25三答行，11分式槽；60/61、第三数、三行证明分开映射。三空保留null，本题非跨页。
- 阅读：viewer-13/印刷5一个共享材料和三个稳定任务，无主印刷题号；任务1同页左下→右上，恢复三空/面积符号/整行展开式；任务2保留S1/S2整段推导；任务3包括恒等式、括注续文及完整图形。答案在viewer-173。
- 37来源窗口、26语义片段；11公式诊断窗口没有重复成为答案片段。保留原图SHA/尺寸、裁片SHA、RGB像素摘要、原始观察、旧错误和候选历史。
- 本轮18项完成的是模型逐图核对。独立人工核对尚未完成，原图谱/旧Check/19条账本不改；四个关系UNRESOLVED，PRE_APPLY HOLD。无执行计划/平台回执/送审。
- A原生B G0.8/0.9消费者、平台精框与共享材料分组政策、选择关系仍需A在实际接收后记录。这里验证的是固定公共提案C01读取兼容，不代A共同验收。
- 三张图不是整章范围。Q9题页、独立章节分母及其余答案证据对应题页仍未解决，不属于本包。
