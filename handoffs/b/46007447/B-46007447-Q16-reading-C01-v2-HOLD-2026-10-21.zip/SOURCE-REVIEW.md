# 本轮来源核图与当前内容

本轮直接查看三幅原图及Q16答案/阅读题答放大裁片；逐槽对照，不使用模型多数票或公式推理代替像素。

中文标点、空格、换行及LaTeX上下标作呈现规范化；题目空值保留null；装饰A保留原像素且不解释为选项。

**模型核图记录；不是独立人工金标准。全部HOLD。**

## Q16

16. 清华附中校本经典题 我们在课堂上学习了勾股定理后，知道“勾三、股四、弦五”。王老师给出一组数让学生观察：3，4，5；5，12，13；7，24，25；9，40，41……学生发现这些勾股数的勾都是奇数，且从3起就没有间断，于是王老师提出以下问题让学生解决。

![q16-stem](delivery/crops/q16-stem.png)

请根据上述的规律写出下一组勾股数：11，____，____。

![q16-task1](delivery/crops/q16-task1.png)

若第一个数用字母a（a为奇数，且a≥3）表示，则后两个数用含a的代数式分别怎么表示？聪明的小明发现每组第二个数有这样的规律：$4=\frac{3^2-1}{2}$，$12=\frac{5^2-1}{2}$，$24=\frac{7^2-1}{2}$……于是他很快表示出了第二个数为$\frac{a^2-1}{2}$，则用含a的代数式表示第三个数为____。

![q16-task2](delivery/crops/q16-task2.png)

用所学知识说明（2）中用字母a表示的三个数是勾股数。

![q16-task3](delivery/crops/q16-task3.png)

16.解：（1）60 61（2）$\frac{a^{2}+1}{2}$（3）∵a²+（$\frac{a^{2}-1}{2}$）²=$\frac{a^{4}+2a^{2}+1}{4}$，

![automatic-row-3c07fe7650f2739d493c9ee9](delivery/crops/automatic-row-3c07fe7650f2739d493c9ee9.png)

（$\frac{a^{2}+1}{2}$）²=$\frac{a^{4}+2a^{2}+1}{4}$，∴a²+（$\frac{a^{2}-1}{2}$）²=（$\frac{a^{2}+1}{2}$）²。又∵a为奇数，且

![automatic-row-702e7841f43c03ec98356f12](delivery/crops/automatic-row-702e7841f43c03ec98356f12.png)

a≥3，∴a，$\frac{a^{2}-1}{2}$，$\frac{a^{2}+1}{2}$都是正整数。∴a，$\frac{a^{2}-1}{2}$，$\frac{a^{2}+1}{2}$是勾股数。

![automatic-row-a309aab8fb02f91a26d8a024](delivery/crops/automatic-row-a309aab8fb02f91a26d8a024.png)

|槽|当前LaTeX|各自来源窗口|
|---|---|---|
|F1|`\frac{a^{2}+1}{2}`|[[765, 268, 802, 294]](delivery/crops/q16-F1.png)|
|F2|`\frac{a^{2}-1}{2}`|[[917, 267, 954, 295]](delivery/crops/q16-F2.png)|
|F3|`\frac{a^{4}+2a^{2}+1}{4}`|[[994, 269, 1070, 296]](delivery/crops/q16-F3.png)|
|F4|`\frac{a^{2}+1}{2}`|[[619, 301, 656, 329]](delivery/crops/q16-F4.png)|
|F5|`\frac{a^{4}+2a^{2}+1}{4}`|[[686, 301, 761, 329]](delivery/crops/q16-F5.png)|
|F6|`\frac{a^{2}-1}{2}`|[[823, 302, 861, 330]](delivery/crops/q16-F6.png)|
|F7|`\frac{a^{2}+1}{2}`|[[900, 303, 938, 330]](delivery/crops/q16-F7.png)|
|F8|`\frac{a^{2}-1}{2}`|[[681, 338, 718, 364]](delivery/crops/q16-F8.png)|
|F9|`\frac{a^{2}+1}{2}`|[[727, 337, 764, 364]](delivery/crops/q16-F9.png)|
|F10|`\frac{a^{2}-1}{2}`|[[884, 339, 922, 365]](delivery/crops/q16-F10.png)|
|F11|`\frac{a^{2}+1}{2}`|[[930, 339, 969, 365]](delivery/crops/q16-F11.png)|

## 阅读共享材料

漫话勾股世界——教材P6“阅读·思考”变式

![reading-title](delivery/crops/reading-title.png)

阅读与思考：请阅读下列材料，并完成相应的任务。

![reading-intro](delivery/crops/reading-intro.png)

勾股定理又称毕达哥拉斯定理、商高定理、百牛定理等，是人类早期发现并证明的重要数学定理之一，大约有五百多种证明方法。下面是我国三国时期的数学家赵爽和意大利著名画家达·芬奇的证明方法：

![reading-body1](delivery/crops/reading-body1.png)

赵爽利用4个全等的直角三角形拼成如图1所示的“弦图”（史称“赵爽弦图”），其中a，b和c分别表示直角三角形的两直角边和斜边，四边形ABDE和四边形CFGH是正方形。

![reading-body2](delivery/crops/reading-body2.png)



![reading-figure1](delivery/crops/reading-figure1.png)

达·芬奇用如图2所示的方法证明，其中剪开前的空白部分由2个正方形和2个全等的直角三角形组成，面积记为$S_1$；剪开翻转后的空白部分由2个全等的直角三角形和1个正方形组成，面积记为$S_2$。

![reading-body3](delivery/crops/reading-body3.png)



![reading-figure2](delivery/crops/reading-figure2.png)

任务：

![reading-task-heading](delivery/crops/reading-task-heading.png)

## 阅读任务(1)

（1）下面是小颖利用赵爽弦图验证勾股定理的过程，请你帮她补充完整。证明：由图1，知$S_{\text{正方形}ABDE}=4S_{\triangle ABC}+S_{\text{正方形}CFGH}$，正方形CFGH的边长为____。

![reading-task1-left](delivery/crops/reading-task1-left.png)

∵$S_{\text{正方形}ABDE}=c^2$，$S_{\triangle ABC}=$____，$S_{\text{正方形}CFGH}=$____，∴$c^2=4\times\frac{1}{2}ab+(a-b)^2=2ab+a^2-2ab+b^2$，即$a^2+b^2=c^2$。

![reading-task1-right](delivery/crops/reading-task1-right.png)

解：（1）a-b　$\frac{1}{2}ab$　$(a-b)^2$

![task1-line1](delivery/crops/task1-line1.png)

## 阅读任务(2)

（2）请你参照小颖的验证过程，利用图2及图中标明的字母写出勾股定理的验证过程。

![reading-task2](delivery/crops/reading-task2.png)

（2）根据题意，得$S_1=a^2+b^2+2\times$

![task2-line1-tail](delivery/crops/task2-line1-tail.png)

$\frac{1}{2}ab=a^2+b^2+ab,S_2=c^2+2\times\frac{1}{2}ab=c^2+ab$。∵$S_1=S_2$，∴$a^2+b^2+$

![task2-line2](delivery/crops/task2-line2.png)

$ab=c^2+ab$，即$a^2+b^2=c^2.$

![task2-line3-prefix](delivery/crops/task2-line3-prefix.png)

## 阅读任务(3)

（3）这种根据图形直观推论或验证数学规律和公式的方法，简称“无字证明”。实际上，初中数学还有一些代数恒等式（除上述涉及的）也可以借助“无字证明”来直观解释，请你举出一例，画出图形并直接写出所解释的代数恒等式。

![reading-task3](delivery/crops/reading-task3.png)

（3）$(a+b)^2=a^2+2ab+b^2$，图形如图所示。（答

![task3-line3-suffix](delivery/crops/task3-line3-suffix.png)

案不唯一）

![task3-line4-continuation](delivery/crops/task3-line4-continuation.png)



![task3-diagram](delivery/crops/task3-diagram.png)

