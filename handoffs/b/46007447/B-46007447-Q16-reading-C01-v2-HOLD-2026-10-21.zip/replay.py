"""Verify fixed members, rebuild bounded delivery and run actual A consumer, offline."""
from pathlib import Path,PurePosixPath
import argparse,hashlib,json,os,subprocess,sys
sys.dont_write_bytecode=True
root=Path(__file__).resolve().parent
sha=lambda b:hashlib.sha256(b).hexdigest()
p=argparse.ArgumentParser();p.add_argument('--out',required=True,type=Path);a=p.parse_args()
out=a.out.resolve()
if out.exists():raise ValueError('OUTPUT_MUST_BE_NEW')
if root==out or root in out.parents:raise ValueError('OUTPUT_MUST_BE_OUTSIDE_PACKAGE')
manifest=json.loads((root/'manifest.json').read_bytes())
expected=set()
for m in manifest['members']:
 path=PurePosixPath(m['path'])
 if path.is_absolute() or '..' in path.parts or '\\' in m['path']:raise ValueError('UNSAFE_MEMBER')
 if m['path'] in expected:raise ValueError('DUPLICATE_MEMBER')
 expected.add(m['path']);local=root/m['path']
 if local.is_symlink():raise ValueError('SYMLINK_MEMBER')
 raw=local.read_bytes()
 if sha(raw)!=m['sha256'] or len(raw)!=m['bytes']:raise ValueError('MEMBER_HASH:'+m['path'])
actual={x.relative_to(root).as_posix() for x in root.rglob('*') if x.is_file()}
if actual!=expected|{'manifest.json'}:raise ValueError('UNMANIFESTED_MEMBER')
out.mkdir(parents=True)
guard="""import sys,socket,importlib.abc,runpy
sys.dont_write_bytecode=True
def blocked(*a,**k):raise RuntimeError('NETWORK_DISABLED_FOR_REPLAY')
socket.create_connection=blocked;socket.getaddrinfo=blocked;socket.socket.connect=blocked;socket.socket.connect_ex=blocked
class NoModels(importlib.abc.MetaPathFinder):
 def find_spec(self,fullname,path=None,target=None):
  if fullname.split('.')[0] in {'torch','onnxruntime','rapidocr_onnxruntime','rapid_latex_ocr','openai','httpx','requests'}:raise ImportError('MODEL_OR_NETWORK_CLIENT_DISABLED:'+fullname)
sys.meta_path.insert(0,NoModels());entry=sys.argv.pop(1);sys.path.insert(0,str(__import__('pathlib').Path(entry).parent));runpy.run_path(entry,run_name='__main__')
"""
env=dict(os.environ,PYTHONDONTWRITEBYTECODE='1',PYTHONNOUSERSITE='1')
def call(entry,args):
 cmd=[sys.executable,'-X','utf8','-c',guard,str(root/entry)]+list(map(str,args))
 r=subprocess.run(cmd,cwd=root,env=env,capture_output=True,text=True,encoding='utf-8')
 (out/(Path(entry).stem+'.stdout.txt')).write_text(r.stdout,encoding='utf-8')
 (out/(Path(entry).stem+'.stderr.txt')).write_text(r.stderr,encoding='utf-8')
 if r.returncode:raise RuntimeError(entry+': '+r.stderr)
call('tools/export_q16_reading_b.py',['--frozen',root/'delivery','--out',out/'delivery'])
reference={p.relative_to(root/'delivery').as_posix():p.read_bytes() for p in (root/'delivery').rglob('*') if p.is_file()}
rebuilt={p.relative_to(out/'delivery').as_posix():p.read_bytes() for p in (out/'delivery').rglob('*') if p.is_file()}
if reference!=rebuilt:raise ValueError('DELIVERY_REPLAY_BYTES_DIFFER')
call('tools/consume_q16_reading_a.py',['--a-source',root/'consumer-a','--pins',root/'consumer-pins.json','--delivery',out/'delivery','--out',out/'a-consumer-receipt.json'])
if (out/'a-consumer-receipt.json').read_bytes()!=(root/'reference/a-consumer-receipt.json').read_bytes():raise ValueError('A_READBACK_REPLAY_BYTES_DIFFER')
receipt=dict(status='OFFLINE_FIXED_DELIVERY_AND_A_READBACK_REPLAYED',manifest_members=len(expected),delivery_files=len(reference),
 a_sources=91,a_commit=manifest['a_consumer_commit'],bundle_sha256=sha(rebuilt['bundle.json']),network_disabled=True,model_imports_disabled=True,
 delivery_byte_equal=True,a_readback_byte_equal=True,clean_dependency_install=False,full_historical_pipeline=False,decision='HOLD')
(out/'replay-receipt.json').write_bytes((json.dumps(receipt,ensure_ascii=False,indent=2)+'\n').encode('utf-8'));print(json.dumps(receipt))
