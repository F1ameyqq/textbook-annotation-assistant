# B side Q16 source revision — MODEL_DRAFT / HOLD

Fixed code baseline: `56278cbb7e65c613e723ce7c34168e9190e77cf1`. Fixed run: `pipeline-run-5dccc68b9873417a94d61f32a6df4d52`. This is a successor to the earlier local handoff; the earlier ZIP is retained unchanged. The run has 14 READY stages but the business decision remains HOLD. It covers five observed pages and distinct adjacent `resource-173`, not the full first chapter. No website annotations were changed.

Current Evidence/G07/Check07 are in `artifacts/`; all 14 original stage wrappers and the full report are included. `manifest.json` gives relative paths, byte sizes, SHA-256, exact final references and all 45 input receipts. All 45 receipt files match the recorded bytes. The observed inline bundle contains all 95 recorded consumed members with exact sizes and SHA-256. 29 image crop receipts were matched against original source pixels, dimensions and image bytes at export.

The Q16 source-region text is MODEL_DRAFT: no human transcription approval, no business acceptance and no platform action. Graph candidates remain 34 questions/66 answers; Check07 has 127 issues. The package must not be treated as a complete chapter, public contract acceptance or A-side consumer PASS. A reception is pending.

Verify without a B runtime: `python verify_b_handoff.py B-46007447-Q16-source-revision-HOLD-2026-10-17.zip --self-test` (or run `tools/verify_b_handoff.py` from the repository). The self-tests reject stale graph refs, unknown assets and corrupted adjacent resource bytes. `REPLAY.md` gives the exact offline CLI inputs and staging steps; `requirements-b.txt` lists B's local runtime dependencies.
