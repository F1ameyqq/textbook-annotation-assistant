# Offline replay from this handoff (PowerShell)

Use a clean repository checkout at code commit `56278cbb7e65c613e723ce7c34168e9190e77cf1`
with `requirements-b.txt` installed. Extract this ZIP into `$pkg`, then run:

```powershell
$pkg = 'PATH_TO_EXTRACTED_PACKAGE'
$inline = 'PATH_TO_EMPTY_INLINE_DIRECTORY'
$run = 'PATH_TO_EMPTY_REPLAY_RUN_DIRECTORY'
Expand-Archive -LiteralPath "$pkg/inputs/inline-observed.zip" -DestinationPath $inline
Copy-Item -LiteralPath "$pkg/inputs/inline-package.json" -Destination "$inline/inline-package.json"
python tools/run_pipeline_b.py --source "$pkg/source/source.json" --context "$pkg/inputs/context.json" --review "$pkg/supporting-fixtures/review.json" --evidence "$pkg/inputs/evidence.json" --recovery "$pkg/supporting-fixtures/recovery-package.json" --continuation "$pkg/supporting-fixtures/continuation-package.json" --adjacent-source "$pkg/source/adjacent/46007447_resource_173.jpg" --inline "$inline/inline-package.json" --inline-source "$pkg/source/adjacent/46007447_resource_173.jpg" --content-revision "$pkg/inputs/content-revision-plan.json" --workdir $run
```

Run the same command again against the same `$run` to exercise the warm cache.
Check the new report's `final_outputs` against `manifest.json`; `READY` only
means the offline pipeline completed. Business decision remains `HOLD`.
No `--ocr`, model download, browser connection or website operation is needed.
