from pathlib import Path
import argparse, hashlib, importlib, json, sys
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args();root=Path(__file__).resolve().parent
sha=lambda raw:hashlib.sha256(raw).hexdigest()
manifest=json.loads((root/'manifest.json').read_bytes())
for row in manifest['members']:
    file=(root/row['path']).resolve()
    if not file.is_relative_to(root):raise RuntimeError('unsafe path')
    raw=file.read_bytes()
    if len(raw)!=row['bytes']or sha(raw)!=row['sha256']:raise RuntimeError('manifest member mismatch '+row['path'])
if a.out.exists():raise RuntimeError('use a fresh output directory')
def guard(event,args):
    if event=='socket.connect':raise RuntimeError('network disabled')
    if event=='import'and str(args[0]).split('.')[0]in {'torch','transformers','rapidocr_onnxruntime','onnxruntime','openai'}:raise RuntimeError('model import disabled')
sys.addaudithook(guard)
sys.path.insert(0,str(root/'tools'));import build_chapter_workspace_b as m;import render_chapter_workspace_b as render
catalog=json.loads((root/'inputs.json').read_bytes())
if catalog['parent_archive_sha256']!={k:v[1]for k,v in {**m.PINS,**m.EXTRA}.items()}:raise RuntimeError('parent provenance differs')
inputs={'packages':{}}
for key,members in catalog['packages'].items():
    inputs['packages'][key]={}
    for name,row in members.items():
        raw=(root/row['blob']).read_bytes()
        if len(raw)!=row['bytes']or sha(raw)!=row['sha256']:raise RuntimeError('source member mismatch')
        inputs['packages'][key][name]=raw
for key,(name,pin)in m.JSON_PINS.items():
    raw=(root/name).read_bytes()
    if sha(raw)!=pin:raise RuntimeError('fixed review binding differs')
    inputs[key]=m.unique_object(raw)
view=m.build_workspace(inputs);audit=m.audit_workspace(view,inputs)
if not audit['source_and_structure_accepted']:raise RuntimeError(audit['errors'])
if m.encode(view)!=(root/'reference/workspace.json').read_bytes()or m.encode(audit)!=(root/'reference/audit.json').read_bytes():raise RuntimeError('workspace/audit mismatch')
html=render.render(view,inputs).encode('utf-8')
if sha(html)!=(root/'reference/html-sha256.txt').read_text().strip():raise RuntimeError('HTML differs')
a.out.mkdir(parents=True)
(a.out/'workspace.json').write_bytes(m.encode(view));(a.out/'audit.json').write_bytes(m.encode(audit));(a.out/'review.html').write_bytes(html)
receipt={'members_verified':len(manifest['members']),'workspace_and_audit_bytes_match':True,'html_bytes_match':True,'workspace_hash':view['content_hash'],'counts':view['payload']['counts'],'network_disabled':True,'model_import_disabled':True,'new_ocr_or_paid_calls':0,'platform_calls':0,'parent_archive_containers_reverified':False,'historical_14_stage_pipeline_rerun':False,'clean_dependency_installation':False,'decision':'HOLD','human_acceptance':False,'chapter_acceptance':False}
(a.out/'receipt.json').write_bytes(m.encode(receipt));print(json.dumps(receipt))
