# B 第一章来源对账及Q16未选定题答候选

2026-10-19 Asia/Shanghai。输入基线186330f，固定输入摘要见source-reconciliation.json。
这是八原图当前库存、Q16跨内容链来源候选和既有viewer15内容投影的离线增量。
Q16题页已在本机，不需A重交；Q9反思题页仍未定位；整章分母未知。
候选三小问映射尚未选定，不是人工核准，也不是新的C01或A执行计划。

本包含所需三份原固定输入ZIP及当前源码，默认入口可自行读取原包。
manifest.json覆盖其他全部成员（长度、SHA256）；先自行核验manifest身份。
在已有Python、numpy、Pillow环境，全新目录运行：
python -X utf8 replay.py --out <尚不存在的输出目录>

replay.py逐成员核验、重建库存和Q16候选并与封存字节对比，再实际重建并独立
审核既有viewer15题目内容应用，要求应用/检查与封存JSON相同、23原像素裁片。
网络和模型导入被禁止；不调用平台/新OCR/付费模型，不改原图谱/Check/19行账本。
使用本机已有依赖不等于清洁安装，机器来源/结构通过不等于独立人工内容或整章验收。
详细A材料请求和B剩余工作见docs/b-chapter-source-reconciliation-20261019.md。
