from pathlib import Path
import argparse, hashlib, importlib.util, json, sys
p=argparse.ArgumentParser();p.add_argument('--out',type=Path,required=True);a=p.parse_args()
root=Path(__file__).resolve().parent
def sha(raw): return hashlib.sha256(raw).hexdigest()
manifest=json.loads((root/'manifest.json').read_bytes())
for item in manifest['members']:
    path=(root/item['path']).resolve()
    if not path.is_relative_to(root): raise RuntimeError('unsafe member')
    raw=path.read_bytes()
    if len(raw)!=item['bytes'] or sha(raw)!=item['sha256']: raise RuntimeError('member hash '+item['path'])
if a.out.exists(): raise RuntimeError('fresh output directory required')
a.out.mkdir(parents=True)
def audit(event,args):
    if event=='socket.connect': raise RuntimeError('network forbidden in offline replay')
    if event=='import' and str(args[0]).split('.')[0] in {'torch','transformers','rapidocr_onnxruntime','onnxruntime','openai'}:
        raise RuntimeError('model import forbidden')
sys.addaudithook(audit)
spec=importlib.util.spec_from_file_location('reconcile',root/'tools/reconcile_chapter_sources_b.py')
mod=importlib.util.module_from_spec(spec);spec.loader.exec_module(mod)
inputs=[mod.unpack_fixed(root/path,pin) for path,pin in mod.PINS.values()]
report,candidate=mod.build(*inputs)
for name,value in [('source-reconciliation.json',report),('q16-source-link-candidate.json',candidate)]:
    raw=mod.encode(value)
    if raw!=(root/name).read_bytes(): raise RuntimeError('replay output differs '+name)
    (a.out/name).write_bytes(raw)
question_input=a.out/'question-input';question_input.mkdir()
for name,raw in inputs[1].items():
    path=(question_input/name).resolve()
    if not path.is_relative_to(question_input.resolve()): raise RuntimeError('unsafe input')
    path.parent.mkdir(parents=True,exist_ok=True);path.write_bytes(raw)
sys.path.insert(0,str(root/'src'))
from annotation.recognition.question_content import apply_question_content,read_json
from annotation.recognition.question_content_quality import audit_question_content
e=read_json(question_input/'evidence.json');g=read_json(question_input/'graph.json')
app=apply_question_content(question_input/'source.json',e,g,question_input/'plan.json',expected_plan_sha256=mod.PLAN_SHA,output_dir=a.out/'source-crops')
check=audit_question_content(question_input/'source.json',e,g,question_input/'plan.json',app,expected_plan_sha256=mod.PLAN_SHA,crop_dir=a.out/'source-crops')
if app!=json.loads((root/'expected-question-application.json').read_bytes()) or check!=json.loads((root/'expected-question-check.json').read_bytes()):
    raise RuntimeError('question application/check replay mismatch')
if not check['accepted']: raise RuntimeError('question source audit failed')
receipt={'scope':'B_SOURCE_INVENTORY_Q16_CANDIDATE_AND_EXISTING_QUESTION_CONTENT_ONLY','members_verified':len(manifest['members']),'original_images_verified':8,'candidate_bytes_match':True,'question_application_matches':True,'question_check_matches':True,'question_crops':len(list((a.out/'source-crops').glob('*.png'))),'network_forbidden':True,'model_import_forbidden':True,'new_platform_calls':0,'new_model_calls':0,'production_graph_mutations':0,'decision':'HOLD','clean_dependency_installation':False,'chapter_acceptance':False}
(a.out/'receipt.json').write_text(json.dumps(receipt,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
print(json.dumps(receipt,ensure_ascii=False))
