# A24 offline replay handoff

This package is an offline reconstruction and synthetic replay aid only.

- `baseline/` contains exactly the 522 public members bound by the preserved original manifest.
- `overlays/` contains two replacements and one added focused regression test.
- `manifests/effective-manifest.json` binds the resulting 523-path effective tree.
- No credentials, cookies, private business response bodies, status directories, or `__pycache__` are included.

From this extracted package directory, using an already installed Python with Pydantic and Pillow:

```powershell
python .\offline_replay.py verify
python .\offline_replay.py rebuild --target C:\path\to\a-new-effective-tree
python .\offline_replay.py test --tree C:\path\to\a-new-effective-tree --report-dir C:\path\to\a-new-report-dir --temp-dir C:\path\to\a-new-long-temp-dir
```

Every output path supplied to `rebuild` or `test` must not already exist. Before creating report or temp directories or importing any test module, the test command verifies the required root manifest and the exact 523-file effective tree. It then installs `MemoryPolicy` and blocks these limited entry points during the suites: `socket.create_connection`, `socket.socket.connect`, `subprocess.Popen`, and `urllib.request.urlopen`. This is not an OS filesystem sandbox and does not prove that every possible I/O API is blocked. It runs controlled-capture 7 + minimum-gate 10 + book-snapshot 4 synthetic tests; the zero count is limited to observed calls at those guarded entry points in these fixed tests. Failure records retain the test ID and original traceback.

## HOLD

This artifact does not establish the current platform schema, natural-export compatibility, platform acceptance, or write authorization. Real book/directory/full-frame/export originals and their hash manifest are still absent. Do not mark `VERIFIED`, unlock writes, launch live activation, or treat this package as platform validation.
