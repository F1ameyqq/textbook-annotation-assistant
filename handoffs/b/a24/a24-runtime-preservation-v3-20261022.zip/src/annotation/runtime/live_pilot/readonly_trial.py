"""Bounded read-only A24 record adaptation and local readback.

This module does not confer platform identity or write eligibility.  It reuses
the byte-exact JSONL preservation layer and emits private full-value artifacts
plus a value-free public receipt.
"""
import argparse
import copy
import hashlib
import json
from pathlib import Path

from annotation.quality.live_pilot import require
from annotation.runtime.live_pilot.historical_preservation import (
    HistoricalArchive,
    load_historical_original,
)
from annotation.runtime.storage.common import digest


SOURCE_TYPES = {"HISTORICAL_EXPORT", "CURRENT_RAW_RECORD"}
MAPPED_FIELDS = ("question", "option", "answer")
EXPECTED_PRECHECK_ERRORS = (
    ("1", "choice", "tishi 为 xuanze/duoxuan 时 choice 必填"),
    ("2", "choice", "tishi 为 xuanze/duoxuan 时 choice 必填"),
    ("7", "question", "question 不能为空"),
    ("7", "answer", "answer 不能为空"),
    ("7", "choice", "tishi 为 xuanze/duoxuan 时 choice 必填"),
    ("19", "question", "question 不能为空"),
    ("19", "answer", "answer 不能为空"),
    ("22", "question", "question 不能为空"),
    ("22", "answer", "answer 不能为空"),
)


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _json_type(value):
    if value is None:
        return "null"
    if type(value) is bool:
        return "boolean"
    if type(value) is int:
        return "integer"
    if isinstance(value, str):
        return "string"
    if isinstance(value, list):
        return "array"
    if isinstance(value, dict):
        return "object"
    require(False, "READONLY_FIELD_TYPE", type(value).__name__)


def _field_evidence(record, field_name):
    if field_name not in record:
        return {"state": "MISSING", "value_type": None, "value_sha256": None}
    value = record[field_name]
    value_type = _json_type(value)
    if value is None:
        state = "NULL"
    elif ((isinstance(value, str) and value == "") or
          (isinstance(value, (list, dict)) and len(value) == 0)):
        state = "EMPTY"
    else:
        state = "PRESENT"
    return {
        "state": state,
        "value_type": value_type,
        "value_sha256": digest({"type": value_type, "value": value}),
    }


def _adapt_record(preserved, record, source_type):
    mapped = {name: copy.deepcopy(record[name]) for name in MAPPED_FIELDS if name in record}
    extra = {name: copy.deepcopy(value) for name, value in record.items()
             if name not in MAPPED_FIELDS}
    reconstructed = {}
    for name in record:
        reconstructed[name] = copy.deepcopy(mapped[name] if name in mapped else extra[name])
    require(reconstructed == record, "READONLY_ADAPTER_ROUNDTRIP")
    return {
        "schema": "A24ReadonlyAdaptedRecord/v1",
        "source_type": source_type,
        "local_source_line": preserved.line_number,
        "line_identity": preserved.line_identity,
        "canonical_question_id": None,
        "write_allowed": False,
        "original_field_order": list(record),
        "mapped_fields": mapped,
        "extra_fields": extra,
        "field_states": {name: _field_evidence(record, name)["state"]
                         for name in MAPPED_FIELDS},
    }


def load_precheck_diagnosis(path, expected_sha256, expected_bytes):
    """Load the frozen v3 visible-UI precheck without inferring field contents."""
    raw = Path(path).read_bytes()
    require(len(raw) == expected_bytes and _sha(raw) == expected_sha256,
            "PRECHECK_SOURCE_BYTES")
    try:
        value = json.loads(raw.decode("utf-8"))
    except (UnicodeDecodeError, json.JSONDecodeError) as exc:
        require(False, "PRECHECK_SOURCE_JSON", type(exc).__name__)
    require(isinstance(value, dict) and value.get("schema") ==
            "A24CurrentPlatformObservations/v3", "PRECHECK_SOURCE_SCHEMA")
    reconciliation = value.get("export_questions_reconciliation")
    require(isinstance(reconciliation, dict), "PRECHECK_SOURCE_SCHEMA")
    errors = reconciliation.get("errors")
    observed = tuple((item.get("importShitiID"), item.get("field"), item.get("message"))
                     for item in errors) if isinstance(errors, list) else ()
    require(observed == EXPECTED_PRECHECK_ERRORS and
            reconciliation.get("error_count") == 9 and
            reconciliation.get("warning_count") == 0,
            "PRECHECK_ERROR_LEDGER")
    dom = next((item for item in value.get("artifacts", [])
                if item.get("collection_method") == "DOM_SNAPSHOT_TEXT"), None)
    require(isinstance(dom, dict) and isinstance(dom.get("sha256"), str) and
            type(dom.get("bytes")) is int, "PRECHECK_DOM_REF")
    return {
        "schema": "A24CurrentPrecheckDiagnosis/v1",
        "evidence_type": "CURRENT_DOM",
        "source": {"sha256": expected_sha256, "bytes": expected_bytes},
        "dom_source": {"sha256": dom["sha256"], "bytes": dom["bytes"],
                       "representation": "DOM_SNAPSHOT_TEXT"},
        "error_count": 9,
        "warning_count": 0,
        "errors": [{
            "sequence": index,
            "importShitiID": import_id,
            "field": field,
            "message": message,
            "underlying_field_state": "UNOBSERVED",
            "missing": None,
            "null": None,
            "empty": None,
        } for index, (import_id, field, message) in enumerate(observed, 1)],
        "identity_boundary": "importShitiID_IS_VISIBLE_VALUE_NOT_SERVER_QUESTION_ID",
        "write_allowed": False,
    }


def _selected_records(archive, source_type, source_line):
    require(isinstance(archive, HistoricalArchive), "READONLY_ARCHIVE")
    if source_type == "CURRENT_RAW_RECORD":
        require(len(archive.records) == 1 and source_line in (None, 1),
                "CURRENT_RECORD_CARDINALITY")
        return list(archive.records)
    if source_line is None:
        return list(archive.records)
    require(type(source_line) is int and source_line > 0, "READONLY_SOURCE_LINE")
    selected = [record for record in archive.records if record.line_number == source_line]
    require(len(selected) == 1, "READONLY_SOURCE_LINE")
    return selected


def _prepare_output_dir(path):
    output = Path(path)
    if output.exists():
        require(output.is_dir() and not output.is_symlink() and not any(output.iterdir()),
                "READONLY_OUTPUT_DIR")
    else:
        output.mkdir(parents=True)
    private = output / "private"
    private.mkdir()
    return output, private


def run_readonly_trial(input_path, output_dir, expected_sha256, expected_bytes,
                       source_type, source_line=None, precheck=None):
    """Adapt records locally, emit artifacts, and immediately read them back."""
    require(source_type in SOURCE_TYPES, "READONLY_SOURCE_TYPE")
    archive = load_historical_original(input_path, expected_sha256, expected_bytes)
    selected = _selected_records(archive, source_type, source_line)
    diagnosis = None
    if precheck is not None:
        diagnosis = load_precheck_diagnosis(
            precheck["path"], precheck["sha256"], precheck["bytes"])
    output, private = _prepare_output_dir(output_dir)

    raw_output = b"".join(record.raw_span for record in selected)
    raw_path = private / "records.full.jsonl"
    raw_path.write_bytes(raw_output)
    adapted = [_adapt_record(record, record.value(), source_type) for record in selected]
    adapted_raw = (json.dumps(adapted, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    adapted_path = private / "records.adapted.json"
    adapted_path.write_bytes(adapted_raw)

    public = {
        "schema": "A24ReadonlyTrial/v1",
        "status": "READ_ONLY_LOCAL_ROUNDTRIP_COMPLETE_IDENTITY_UNBOUND",
        "source_type": source_type,
        "source_type_basis": "CALLER_DECLARED",
        "fresh_capture_proven": False,
        "http_status": "UNKNOWN",
        "canonical_question_id": None,
        "write_allowed": False,
        "source": {"sha256": archive.source_sha256, "bytes": archive.source_bytes,
                   "representation": "UTF8_JSONL"},
        "selection": {"kind": "ALL_RECORDS" if source_line is None else "LOCAL_SOURCE_LINE",
                      "local_source_line": source_line},
        "record_count": len(selected),
        "records": [{
            "local_source_line": preserved.line_number,
            "line_identity": preserved.line_identity,
            "canonical_question_id": None,
            "raw_byte_ref": preserved.byte_reference(archive.source_sha256),
            "field_evidence": {name: _field_evidence(record, name)
                               for name in MAPPED_FIELDS},
            "field_names": list(record),
        } for preserved, record in zip(selected, (item.value() for item in selected))],
        "private_outputs": {
            "records.full.jsonl": {"bytes": len(raw_output), "sha256": _sha(raw_output)},
            "records.adapted.json": {"bytes": len(adapted_raw), "sha256": _sha(adapted_raw)},
        },
        "precheck_diagnosis": diagnosis,
        "limits": [
            "LOCAL_SOURCE_LINE_IS_NOT_QUESTION_ID",
            "VALUE_HASH_IS_NOT_IDENTITY",
            "NO_AUTOMATIC_JOIN_TO_DOM_OR_HISTORY_NUMBER",
            "NO_PLATFORM_READ_OR_WRITE",
        ],
    }
    public_raw = (json.dumps(public, ensure_ascii=False, indent=2) + "\n").encode("utf-8")
    public_path = output / "public-summary.json"
    public_path.write_bytes(public_raw)

    # Independent file readback: hashes, exact selected bytes, adapted content,
    # and the value-free public summary are all re-read from disk.
    reread_raw = raw_path.read_bytes()
    reread_adapted_raw = adapted_path.read_bytes()
    reread_public_raw = public_path.read_bytes()
    require(reread_raw == raw_output and _sha(reread_raw) ==
            public["private_outputs"]["records.full.jsonl"]["sha256"],
            "READBACK_RAW_MISMATCH")
    require(_sha(reread_adapted_raw) ==
            public["private_outputs"]["records.adapted.json"]["sha256"],
            "READBACK_ADAPTED_MISMATCH")
    require(json.loads(reread_adapted_raw.decode("utf-8")) == adapted,
            "READBACK_ADAPTED_MISMATCH")
    require(json.loads(reread_public_raw.decode("utf-8")) == public,
            "READBACK_PUBLIC_MISMATCH")
    receipt = {
        "schema": "A24ReadonlyReadbackReceipt/v1",
        "result": "PASS_EXACT_LOCAL_READBACK",
        "source_type": source_type,
        "record_count": len(selected),
        "canonical_question_id": None,
        "write_allowed": False,
        "public_summary_sha256": _sha(reread_public_raw),
        "private_full_sha256": _sha(reread_raw),
        "private_adapted_sha256": _sha(reread_adapted_raw),
    }
    receipt_path = output / "readback-receipt.json"
    receipt_path.write_text(json.dumps(receipt, ensure_ascii=False, indent=2) + "\n",
                            encoding="utf-8", newline="\n")
    return public, receipt


def _parser():
    parser = argparse.ArgumentParser(
        description="A24 read-only JSONL adapter with exact local readback")
    parser.add_argument("--input", required=True)
    parser.add_argument("--out", required=True)
    parser.add_argument("--source-type", required=True, choices=sorted(SOURCE_TYPES))
    parser.add_argument("--expected-sha256", required=True)
    parser.add_argument("--expected-bytes", required=True, type=int)
    parser.add_argument("--line", type=int, default=None,
                        help="local JSONL line only; never a question identity")
    parser.add_argument("--precheck-observation")
    parser.add_argument("--precheck-sha256")
    parser.add_argument("--precheck-bytes", type=int)
    return parser


def main(argv=None):
    args = _parser().parse_args(argv)
    supplied = (args.precheck_observation, args.precheck_sha256, args.precheck_bytes)
    require(all(item is None for item in supplied) or all(item is not None for item in supplied),
            "PRECHECK_SOURCE_REF")
    precheck = None if supplied[0] is None else {
        "path": supplied[0], "sha256": supplied[1], "bytes": supplied[2]}
    public, receipt = run_readonly_trial(
        args.input, args.out, args.expected_sha256, args.expected_bytes,
        args.source_type, args.line, precheck)
    print(json.dumps({
        "status": public["status"],
        "source_type": public["source_type"],
        "record_count": public["record_count"],
        "write_allowed": False,
        "readback": receipt["result"],
        "output": str(Path(args.out).resolve()),
    }, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
