"""Byte-exact preservation for an A24 historical JSONL original.

This layer is deliberately separate from current-schema codecs and write
admission. It preserves evidence without assigning platform identities,
inventing five-zone semantics, or asserting current export completeness.
"""
import copy
from dataclasses import dataclass
import hashlib
import json
from pathlib import Path

from annotation.quality.live_pilot import require
from annotation.runtime.storage.common import digest


REPARSE_POINT = 0x400
DOM_LINK_FIELDS = {"source_line", "evidence_type", "candidate_value", "evidence_sha256"}
DOM_LINK_TYPE = "DOM_DATA_KEY_LOCAL_CANDIDATE"


def _sha(raw):
    return hashlib.sha256(raw).hexdigest()


def _unique_object(pairs):
    value = {}
    for key, item in pairs:
        require(key not in value, "HISTORICAL_JSON_DUPLICATE_KEY")
        value[key] = item
    return value


def _decode_record(raw):
    try:
        text = raw.decode("utf-8", errors="strict")
    except UnicodeDecodeError as exc:
        require(False, "HISTORICAL_SOURCE_ENCODING", type(exc).__name__)
    try:
        value = json.loads(text, object_pairs_hook=_unique_object,
                           parse_float=lambda token: require(
                               False, "HISTORICAL_JSON_NUMBER", "FLOAT_UNSUPPORTED"),
                           parse_constant=lambda token: require(False, "HISTORICAL_JSON_NONFINITE", token))
    except json.JSONDecodeError as exc:
        require(False, "HISTORICAL_JSONL_RECORD", type(exc).__name__)
    require(isinstance(value, dict), "HISTORICAL_JSONL_RECORD")
    return value


def _split_span(span):
    if span.endswith(b"\r\n"):
        return span[:-2], "CRLF"
    if span.endswith(b"\n"):
        return span[:-1], "LF"
    if span.endswith(b"\r"):
        return span[:-1], "CR"
    return span, "NONE"


@dataclass(frozen=True)
class HistoricalRecord:
    line_number: int
    byte_offset: int
    raw_span: bytes
    record_bytes: bytes
    line_ending: str
    line_identity: str
    content_fingerprint: str

    def value(self):
        return _decode_record(self.record_bytes)

    def byte_reference(self, source_sha256):
        return {
            "schema": "A24HistoricalRawByteRef/v1",
            "source_sha256": source_sha256,
            "line_number": self.line_number,
            "byte_offset": self.byte_offset,
            "byte_length": len(self.raw_span),
            "record_byte_length": len(self.record_bytes),
            "raw_span_sha256": _sha(self.raw_span),
            "record_sha256": _sha(self.record_bytes),
            "line_ending": self.line_ending,
        }


@dataclass(frozen=True)
class HistoricalArchive:
    path: Path
    source_sha256: str
    source_bytes: int
    records: tuple

    def reconstruct_bytes(self):
        return b"".join(record.raw_span for record in self.records)

    def full_records(self):
        return [record.value() for record in self.records]

    def public_preservation_manifest(self):
        return {
            "schema": "A24HistoricalOriginalPreservation/v1",
            "status": "PRESERVED_HISTORICAL_BYTES_IDENTITY_UNBOUND",
            "fresh_capture_proven": False,
            "write_allowed": False,
            "source": {"bytes": self.source_bytes, "sha256": self.source_sha256,
                       "representation": "UTF8_JSONL"},
            "record_count": len(self.records),
            "records": [{
                "line_identity": record.line_identity,
                "content_fingerprint": record.content_fingerprint,
                "raw_byte_ref": record.byte_reference(self.source_sha256),
                "field_names": list(record.value()),
            } for record in self.records],
        }


def load_historical_original(path, expected_sha256, expected_bytes):
    """Verify and preserve a historical JSONL file without schema promotion."""
    require(isinstance(expected_sha256, str) and len(expected_sha256) == 64 and
            all(ch in "0123456789abcdef" for ch in expected_sha256) and
            type(expected_bytes) is int and expected_bytes > 0, "HISTORICAL_SOURCE_REF")
    candidate = Path(path)
    require(candidate.is_file() and not candidate.is_symlink() and
            not (getattr(candidate.lstat(), "st_file_attributes", 0) & REPARSE_POINT),
            "HISTORICAL_SOURCE_PATH")
    source = candidate.resolve()
    require(source.is_file() and not source.is_symlink() and
            not (getattr(source.lstat(), "st_file_attributes", 0) & REPARSE_POINT),
            "HISTORICAL_SOURCE_PATH")
    raw = source.read_bytes()
    require(len(raw) == expected_bytes and _sha(raw) == expected_sha256,
            "HISTORICAL_SOURCE_BYTES")
    require(raw and not raw.startswith(b"\xef\xbb\xbf"), "HISTORICAL_SOURCE_ENCODING")

    records, offset = [], 0
    for line_number, span in enumerate(raw.splitlines(keepends=True), 1):
        record_bytes, line_ending = _split_span(span)
        require(record_bytes and record_bytes.strip(), "HISTORICAL_JSONL_RECORD")
        value = _decode_record(record_bytes)
        raw_span_sha256 = _sha(span)
        line_identity = digest({"source_sha256": expected_sha256, "line_number": line_number,
                                "byte_offset": offset, "raw_span_sha256": raw_span_sha256})
        records.append(HistoricalRecord(
            line_number=line_number,
            byte_offset=offset,
            raw_span=span,
            record_bytes=record_bytes,
            line_ending=line_ending,
            line_identity=line_identity,
            content_fingerprint=digest(value),
        ))
        offset += len(span)
    require(records and offset == len(raw), "HISTORICAL_JSONL_RECORD")
    archive = HistoricalArchive(source, expected_sha256, expected_bytes, tuple(records))
    require(archive.reconstruct_bytes() == raw, "HISTORICAL_SOURCE_BYTES")
    return archive


def build_identity_mapping(archive, dom_candidate_links=()):
    """Build non-authoritative typed candidates; never choose a canonical ID."""
    require(isinstance(archive, HistoricalArchive) and
            isinstance(dom_candidate_links, (list, tuple)), "IDENTITY_EVIDENCE_SCHEMA")
    valid_lines = {record.line_number for record in archive.records}
    by_line = {line: [] for line in valid_lines}
    by_dom_key = {}
    seen = set()
    for link in dom_candidate_links:
        require(isinstance(link, dict) and set(link) == DOM_LINK_FIELDS and
                type(link["source_line"]) is int and link["source_line"] in valid_lines and
                link["evidence_type"] == DOM_LINK_TYPE and
                isinstance(link["candidate_value"], str) and link["candidate_value"] and
                link["candidate_value"].strip() == link["candidate_value"] and
                isinstance(link["evidence_sha256"], str) and len(link["evidence_sha256"]) == 64 and
                all(ch in "0123456789abcdef" for ch in link["evidence_sha256"]),
                "IDENTITY_EVIDENCE_SCHEMA")
        key = (link["source_line"], link["candidate_value"], link["evidence_sha256"])
        require(key not in seen, "IDENTITY_EVIDENCE_DUPLICATE")
        seen.add(key)
        value = copy.deepcopy(link)
        by_line[link["source_line"]].append(value)
        by_dom_key.setdefault(link["candidate_value"], set()).add(link["source_line"])

    entries = []
    for record in archive.records:
        dom_candidates = by_line[record.line_number]
        ambiguous = (len({item["candidate_value"] for item in dom_candidates}) > 1 or
                     any(len(by_dom_key[item["candidate_value"]]) > 1 for item in dom_candidates))
        candidates = [
            {"evidence_type": "SOURCE_LINE_LOCAL_CANDIDATE", "source_line": record.line_number,
             "line_identity": record.line_identity},
            {"evidence_type": "CONTENT_FINGERPRINT_LOCAL_CANDIDATE",
             "content_fingerprint": record.content_fingerprint},
        ] + copy.deepcopy(dom_candidates)
        entries.append({
            "line_identity": record.line_identity,
            "source_line": record.line_number,
            "canonical_question_id": None,
            "selected_candidate": None,
            "status": "HOLD_AMBIGUOUS_LOCAL_MAPPING" if ambiguous else "HOLD_LOCAL_CANDIDATES_ONLY",
            "candidates": candidates,
        })
    return {
        "schema": "A24HistoricalIdentityCandidates/v1",
        "status": "HOLD_CANONICAL_ID_UNBOUND",
        "fresh_capture_proven": False,
        "write_allowed": False,
        "source_sha256": archive.source_sha256,
        "entries": entries,
    }
