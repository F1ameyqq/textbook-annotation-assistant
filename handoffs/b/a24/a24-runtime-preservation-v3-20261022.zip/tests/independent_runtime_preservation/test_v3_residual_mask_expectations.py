"""Independent V3 expectations for response-residual masking.

Run only against the frozen V3 candidate.  V2 is expected to fail these gates.
"""
from __future__ import annotations

import copy
import importlib.util
import sys
import tempfile
import unittest
from pathlib import Path

from annotation.delivery.live_pilot import wire
from annotation.delivery.live_pilot.usense import UsenseTransport
from annotation.quality.live_pilot import PilotError, check_input, check_preservation


SOURCE_ROOT = Path(wire.__file__).resolve().parents[4]
sys.path.insert(0, str(SOURCE_ROOT / "tests" / "a24_first_save_wire_r1"))
from fixture import FakeIO, bind_profile, fixture  # noqa: E402


def load_runtime_test_helpers():
    path = SOURCE_ROOT / "tests" / "a24_runtime_raw_preservation" / "test_runtime_raw_preservation.py"
    spec = importlib.util.spec_from_file_location("candidate_runtime_raw_helpers", path)
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def add_raw_records(state: dict) -> None:
    import json
    for content in state["view"]["question_content"].values():
        raw = copy.deepcopy(content)
        content["raw_record"] = raw
        content["raw_record_json"] = json.dumps(
            raw, ensure_ascii=False, separators=(",", ":"))


def append_legal_question(state: dict) -> str:
    import json
    pid = "q-new"
    target = state["view"]["target"]
    directory_id = target["questions"][0]["directory_id"]
    target["questions"].append({
        "platform_question_id": pid,
        "platform_order": max(item["platform_order"] for item in target["questions"]) + 1,
        "directory_id": directory_id,
    })
    rect_ids = [f"r-new-{index}" for index in range(6)]
    target["frames"].extend(
        {"platform_frame_id": rid, "platform_question_id": pid}
        for rid in rect_ids
    )
    state["view"]["internal_bindings"]["local-new"] = pid
    state["view"]["frame_projections"].update(
        {rid: {"index": index} for index, rid in enumerate(rect_ids)})
    raw = {
        "question_type": "ordinary_choice",
        "parts": [{}],
        "wire_zones": {zone: None for zone in wire.ZONES},
        "question_info": {},
        "rect_ids": rect_ids,
    }
    state["view"]["question_content"][pid] = {
        "status": "AVAILABLE",
        **copy.deepcopy(raw),
        "raw_record": copy.deepcopy(raw),
        "raw_record_json": json.dumps(raw, ensure_ascii=False, separators=(",", ":")),
    }
    return pid


class OrderedResponseIO(FakeIO):
    """Synthetic GET response whose wrapper order is explicitly controlled."""
    def __init__(self, initial, fact, pairs):
        super().__init__(initial, fact)
        self.pairs = copy.deepcopy(pairs)

    def request_once(self, method, path, *, params, payload, phase):
        if method == "GET" and path.endswith("complete-snapshot"):
            self.calls.append({"method": method, "path": path,
                               "params": copy.deepcopy(params), "phase": phase})
            body = {}
            for key, value in self.pairs:
                body[key] = self.state if key == "snapshot" else copy.deepcopy(value)
            return self.response(body)
        return super().request_once(method, path, params=params, payload=payload, phase=phase)


def legacy_observation(root: Path, pairs, *, append=False):
    request, initial, fact, profile = fixture(root)
    add_raw_records(initial)
    pid = append_legal_question(initial) if append else None
    transport = UsenseTransport(OrderedResponseIO(initial, fact, pairs))
    check_input(request, root, offline=True, wire=transport)
    return transport.observe("baseline"), pid


def call_bind_and_observe(request, root, transport):
    check_input(request, root, offline=True, wire=transport)
    return transport.observe("baseline")


class V3ResidualMaskExpectations(unittest.TestCase):
    def assert_rejected(self, before, after, pid):
        with self.assertRaises(PilotError):
            check_preservation(before, after, pid)

    def test_unchanged_wrapper_with_legal_append_is_positive_control(self):
        with tempfile.TemporaryDirectory(prefix="a24-v3-positive-") as tmp:
            root = Path(tmp)
            pairs = [("left", {"stable": True}), ("snapshot", None),
                     ("right", {"value": 0})]
            before, _ = legacy_observation(root / "before", pairs, append=False)
            after, pid = legacy_observation(root / "after", pairs, append=True)
            check_preservation(before, after, pid)

    def test_wrapper_add_delete_type_and_key_order_changes_reject_during_append(self):
        cases = [
            ([("snapshot", None)],
             [("snapshot", None), ("wrapper", {"value": 0})], "add"),
            ([("snapshot", None), ("wrapper", {"value": 0})],
             [("snapshot", None)], "delete"),
            ([("snapshot", None), ("wrapper", {"value": 0})],
             [("snapshot", None), ("wrapper", {"value": False})], "0_false"),
            ([("snapshot", None), ("wrapper", {"first": 1, "second": 2})],
             [("snapshot", None), ("wrapper", {"second": 2, "first": 1})], "nested_order"),
            ([("left", 1), ("snapshot", None), ("right", 2)],
             [("right", 2), ("snapshot", None), ("left", 1)], "outer_order"),
        ]
        with tempfile.TemporaryDirectory(prefix="a24-v3-wrapper-cases-") as tmp:
            root = Path(tmp)
            for index, (before_pairs, after_pairs, label) in enumerate(cases):
                with self.subTest(label=label):
                    before, _ = legacy_observation(
                        root / f"{index}-before", before_pairs, append=False)
                    after, pid = legacy_observation(
                        root / f"{index}-after", after_pairs, append=True)
                    self.assert_rejected(before, after, pid)

    def test_mapped_raw_entity_unknown_field_key_order_still_rejects(self):
        helpers = load_runtime_test_helpers()
        before = helpers.projected_observation(old_extra={"first": 1, "second": 2})
        after = helpers.projected_observation(
            old_extra={"second": 2, "first": 1}, append=True)
        with self.assertRaises(PilotError) as caught:
            check_preservation(before, after, "q-new")
        self.assertEqual(caught.exception.code, "OLD_RAW_ENTITY_CHANGED")

    def test_unbound_multi_request_residual_rejects(self):
        with tempfile.TemporaryDirectory(prefix="a24-v3-multi-unbound-") as tmp:
            root = Path(tmp)
            request, initial, fact, profile = fixture(root)
            projection = {
                name: {"from": {"response": "snapshot", "path": ["snapshot", name]}}
                for name in wire.SNAPSHOT_FIELDS
            }
            profile["reads"] = {
                phase: {
                    "requests": [{
                        "name": "snapshot",
                        "path": "/qieti/api/synthetic/complete-snapshot",
                        "params": {"file_id": "46007447"},
                        "count": 1,
                    }, {
                        "name": "unused",
                        "path": "/qieti/api/synthetic/complete-snapshot",
                        "params": {"file_id": "46007447", "unused": "1"},
                        "count": 1,
                    }],
                    "projection": copy.deepcopy(projection),
                }
                for phase in ("baseline", "prewrite", "get", "refresh", "reopen", "reconcile")
            }
            bind_profile(request, profile, root)
            transport = UsenseTransport(OrderedResponseIO(
                initial, fact, [("snapshot", None), ("wrapper", {"unknown": True})]))
            with self.assertRaises(PilotError) as caught:
                call_bind_and_observe(request, root, transport)
            self.assertEqual(caught.exception.code, "RAW_RESPONSE_RESIDUAL_UNBOUND")

    def test_ambiguous_legacy_mask_paths_reject(self):
        with tempfile.TemporaryDirectory(prefix="a24-v3-ambiguous-") as tmp:
            root = Path(tmp)
            request, initial, fact, profile = fixture(root)
            for spec in profile["reads"].values():
                # The whole snapshot path overlaps every other mapped leaf.
                spec["response_fields"]["view"] = ["snapshot"]
            bind_profile(request, profile, root)
            transport = UsenseTransport(OrderedResponseIO(
                initial, fact, [("snapshot", None), ("wrapper", {"stable": True})]))
            with self.assertRaises(PilotError) as caught:
                call_bind_and_observe(request, root, transport)
            self.assertIn(caught.exception.code, {
                "RAW_RESPONSE_RESIDUAL_PATH_AMBIGUOUS",
                "RAW_RESPONSE_RESIDUAL_UNBOUND",
            })


if __name__ == "__main__":
    unittest.main(verbosity=2)
