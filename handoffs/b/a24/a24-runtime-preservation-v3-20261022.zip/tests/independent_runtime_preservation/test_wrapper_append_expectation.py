"""Post-append preservation expectation for an unprojected response wrapper."""
from __future__ import annotations

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path
from typing import Optional, Tuple

from annotation.delivery.live_pilot import wire
from annotation.delivery.live_pilot.usense import UsenseTransport
from annotation.quality.live_pilot import PilotError, check_input, check_preservation


SOURCE_ROOT = Path(wire.__file__).resolve().parents[4]
sys.path.insert(0, str(SOURCE_ROOT / "tests" / "a24_first_save_wire_r1"))
from fixture import FakeIO, bind_profile, fixture  # noqa: E402


def direct(response: str, path: list[str]) -> dict:
    return {"from": {"response": response, "path": path}}


def local(path: list[str]) -> dict:
    return {"from": {"response": "$", "path": path}}


def projection() -> dict:
    return {
        "book_id": direct("snapshot", ["snapshot", "book_id"]),
        "platform_version": direct("snapshot", ["snapshot", "platform_version"]),
        "view": {"object": {
            "target": {"object": {
                "directories": direct("snapshot", ["snapshot", "view", "target", "directories"]),
                "questions": {"array": {
                    "source": direct("snapshot", ["snapshot", "view", "target", "questions"]),
                    "item": {"object": {
                        "platform_question_id": local(["platform_question_id"]),
                        "platform_order": local(["platform_order"]),
                        "directory_id": local(["directory_id"]),
                    }},
                }},
                "frames": {"array": {
                    "source": direct("snapshot", ["snapshot", "view", "target", "frames"]),
                    "item": {"object": {
                        "platform_frame_id": local(["platform_frame_id"]),
                        "platform_question_id": local(["platform_question_id"]),
                    }},
                }},
            }},
            "internal_bindings": direct("snapshot", ["snapshot", "view", "internal_bindings"]),
            "frame_projections": direct("snapshot", ["snapshot", "view", "frame_projections"]),
            "question_content": direct("snapshot", ["snapshot", "view", "question_content"]),
        }},
        "directory_details": {"array": {
            "source": direct("snapshot", ["snapshot", "directory_details"]),
            "item": {"object": {
                "directory_id": local(["directory_id"]),
                "parent_id": local(["parent_id"]),
            }},
        }},
        "source_bindings": direct("snapshot", ["snapshot", "source_bindings"]),
        "submission_status": direct("snapshot", ["snapshot", "submission_status"]),
        "complete": direct("snapshot", ["snapshot", "complete"]),
        "read_status": direct("snapshot", ["snapshot", "read_status"]),
    }


class WrapperIO(FakeIO):
    def __init__(self, initial, fact, wrapper):
        super().__init__(initial, fact)
        self.wrapper = copy.deepcopy(wrapper)

    def request_once(self, method, path, *, params, payload, phase):
        if method == "GET" and path.endswith("complete-snapshot"):
            self.calls.append({"method": method, "path": path,
                               "params": copy.deepcopy(params), "phase": phase})
            return self.response({
                "snapshot": self.state,
                "unknown_business_wrapper": copy.deepcopy(self.wrapper),
            })
        return super().request_once(method, path, params=params, payload=payload, phase=phase)


def add_raw_records(state: dict) -> None:
    for content in state["view"]["question_content"].values():
        raw = copy.deepcopy(content)
        content["raw_record"] = raw
        content["raw_record_json"] = json.dumps(
            raw, ensure_ascii=False, separators=(",", ":"))


def append_legal_question(state: dict) -> str:
    pid = "q-new"
    target = state["view"]["target"]
    directory_id = target["questions"][0]["directory_id"]
    target["questions"].append({
        "platform_question_id": pid,
        "platform_order": max(q["platform_order"] for q in target["questions"]) + 1,
        "directory_id": directory_id,
    })
    rect_ids = [f"r-new-{index}" for index in range(6)]
    target["frames"].extend(
        {"platform_frame_id": rid, "platform_question_id": pid}
        for rid in rect_ids
    )
    state["view"]["internal_bindings"]["internal-new"] = pid
    state["view"]["frame_projections"].update(
        {rid: {"index": index} for index, rid in enumerate(rect_ids)})
    raw = {
        "question_type": "ordinary_choice",
        "parts": [{}],
        "wire_zones": {zone: None for zone in wire.ZONES},
        "question_info": {},
        "rect_ids": rect_ids,
    }
    state["view"]["question_content"][pid] = {
        "status": "AVAILABLE",
        **copy.deepcopy(raw),
        "raw_record": copy.deepcopy(raw),
        "raw_record_json": json.dumps(raw, ensure_ascii=False, separators=(",", ":")),
    }
    return pid


def observed(root: Path, *, append: bool, wrapper: dict) -> Tuple[dict, Optional[str]]:
    request, initial, fact, profile = fixture(root)
    add_raw_records(initial)
    pid = append_legal_question(initial) if append else None
    codec = projection()
    profile["reads"] = {
        phase: {
            "requests": [{
                "name": "snapshot",
                "path": "/qieti/api/synthetic/complete-snapshot",
                "params": {"file_id": "46007447"},
                "count": 1,
            }],
            "projection": copy.deepcopy(codec),
        }
        for phase in ("baseline", "prewrite", "get", "refresh", "reopen", "reconcile")
    }
    bind_profile(request, profile, root)
    transport = UsenseTransport(WrapperIO(initial, fact, wrapper))
    check_input(request, root, offline=True, wire=transport)
    return transport.observe("baseline"), pid


class WrapperAppendExpectation(unittest.TestCase):
    def test_wrapper_unchanged_legal_append_passes_but_wrapper_type_change_rejects(self):
        with tempfile.TemporaryDirectory(prefix="a24-wrapper-append-") as tmp:
            base = Path(tmp)
            before, _ = observed(base / "before", append=False, wrapper={"value": 0})
            legal_after, pid = observed(base / "legal", append=True, wrapper={"value": 0})
            check_preservation(before, legal_after, pid)

            changed_after, changed_pid = observed(
                base / "changed", append=True, wrapper={"value": False})
            self.assertNotEqual(
                before["raw_business_responses"]["snapshot"]["body"],
                changed_after["raw_business_responses"]["snapshot"]["body"],
            )
            with self.assertRaises(PilotError):
                check_preservation(before, changed_after, changed_pid)


if __name__ == "__main__":
    unittest.main(verbosity=2)
