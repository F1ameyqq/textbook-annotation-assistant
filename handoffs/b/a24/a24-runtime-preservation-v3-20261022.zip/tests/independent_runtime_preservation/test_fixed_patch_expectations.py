"""Independent acceptance expectations for the frozen preservation patch.

Unlike ``test_runtime_preservation_false_pass.py``, this suite describes the
desired fixed behavior: old-business mutations must raise and a legal append
must still pass.  It imports a candidate source tree through PYTHONPATH and does
not modify that tree.
"""
from __future__ import annotations

import copy
import json
import sys
import tempfile
import unittest
from pathlib import Path

from annotation.delivery.live_pilot import wire
from annotation.delivery.live_pilot.usense import UsenseTransport
from annotation.quality.live_pilot import PilotError, check_input, check_preservation
from annotation.runtime.storage.common import digest


SOURCE_ROOT = Path(wire.__file__).resolve().parents[4]
sys.path.insert(0, str(SOURCE_ROOT / "tests" / "a24_first_save_wire_r1"))
from fixture import FakeIO, bind_profile, fixture  # noqa: E402


class SignatureSentinelSession:
    offline = True
    evidence_mode = "SYNTHETIC"
    actor = "author"
    session_id = "signature-sentinel-session"

    def request_once(self, method, path, *, params, payload, phase):
        assert method == "GET" and path == wire.SIGNATURE and phase == "upload"
        body = {"access_token": "SENTINEL-MUST-NOT-BE-RETAINED"}
        return {
            "http_status": 200,
            "body": json.dumps(body, separators=(",", ":")),
            "request_id": "signature-sentinel:1",
            "session_id": self.session_id,
            "fresh": True,
            "cache": False,
            "platform_version": "observed-v1",
        }


def observation() -> dict:
    value = {
        "book_id": "46007447",
        "platform_version": "observed-v1",
        "complete": True,
        "read_status": "OK",
        "submission_status": "NOT_SUBMITTED",
        "source_bindings": {},
        "business_envelope": {"zero": 0},
        "directory_details": [
            {"directory_id": "leaf", "parent_id": None, "business_extra": 0}
        ],
        "view": {
            "business_envelope": {"one": 1},
            "target": {
                "directories": ["leaf"],
                "questions": [{
                    "platform_question_id": "q-old",
                    "platform_order": 1,
                    "directory_id": "leaf",
                    "business_extra": 0,
                }],
                "frames": [{
                    "platform_frame_id": "r-old",
                    "platform_question_id": "q-old",
                    "business_extra": 1,
                }],
            },
            "internal_bindings": {},
            "frame_projections": {"r-old": {"business_extra": 0}},
            "question_content": {"q-old": {
                "status": "AVAILABLE",
                "question_type": "ordinary_choice",
                "parts": [{}],
                "wire_zones": {zone: None for zone in wire.ZONES},
                "question_info": {},
                "rect_ids": ["r-old"],
                "business_extra": {"nested": 0},
            }},
        },
    }
    return refresh_private_evidence(value)


def refresh_private_evidence(value: dict) -> dict:
    value["raw_business_projection"] = wire.build_business_preservation(value, direct_view=True)
    body = json.dumps({"snapshot": value_without_private_evidence(value)},
                      ensure_ascii=False, separators=(",", ":"))
    value["raw_business_responses"] = {"snapshot": {
        "body": body,
        "body_sha256": wire.sha_text(body),
        "json_body": True,
        "parsed": json.loads(body),
    }}
    return value


def value_without_private_evidence(value: dict) -> dict:
    return {k: copy.deepcopy(v) for k, v in value.items()
            if k not in ("raw_business_projection", "raw_business_responses")}


def direct(response: str, path: list[str]) -> dict:
    return {"from": {"response": response, "path": path}}


def local(path: list[str]) -> dict:
    return {"from": {"response": "$", "path": path}}


def lossy_projection() -> dict:
    """Profile-valid adapter that keeps identities but drops unknown members."""
    def content(qid: str) -> dict:
        return {"object": {
            key: direct("snapshot", ["snapshot", "view", "question_content", qid, key])
            for key in ("status", "question_type", "parts", "wire_zones", "question_info",
                        "raw_record", "raw_record_json")
        }}

    return {
        "book_id": direct("snapshot", ["snapshot", "book_id"]),
        "platform_version": direct("snapshot", ["snapshot", "platform_version"]),
        "view": {"object": {
            "target": {"object": {
                "directories": direct("snapshot", ["snapshot", "view", "target", "directories"]),
                "questions": {"array": {
                    "source": direct("snapshot", ["snapshot", "view", "target", "questions"]),
                    "item": {"object": {
                        "platform_question_id": local(["platform_question_id"]),
                        "platform_order": local(["platform_order"]),
                        "directory_id": local(["directory_id"]),
                    }},
                }},
                "frames": {"array": {
                    "source": direct("snapshot", ["snapshot", "view", "target", "frames"]),
                    "item": {"object": {
                        "platform_frame_id": local(["platform_frame_id"]),
                        "platform_question_id": local(["platform_question_id"]),
                    }},
                }},
            }},
            "internal_bindings": direct("snapshot", ["snapshot", "view", "internal_bindings"]),
            "frame_projections": direct("snapshot", ["snapshot", "view", "frame_projections"]),
            "question_content": {"object": {
                qid: content(qid) for qid in ("old-a", "old-b")
            }},
        }},
        "directory_details": {"array": {
            "source": direct("snapshot", ["snapshot", "directory_details"]),
            "item": {"object": {
                "directory_id": local(["directory_id"]),
                "parent_id": local(["parent_id"]),
            }},
        }},
        "source_bindings": direct("snapshot", ["snapshot", "source_bindings"]),
        "submission_status": direct("snapshot", ["snapshot", "submission_status"]),
        "complete": direct("snapshot", ["snapshot", "complete"]),
        "read_status": direct("snapshot", ["snapshot", "read_status"]),
    }


class FixedPatchExpectations(unittest.TestCase):
    def assert_rejected(self, before, after):
        with self.assertRaises(PilotError):
            check_preservation(before, after, None)

    def test_directory_question_frame_projection_and_content_mutations_reject(self):
        mutations = [
            lambda value: value["directory_details"][0].__setitem__("business_extra", False),
            lambda value: value["view"]["target"]["questions"][0].__setitem__("business_extra", False),
            lambda value: value["view"]["target"]["frames"][0].__setitem__("business_extra", 1.0),
            lambda value: value["view"]["frame_projections"]["r-old"].__setitem__("business_extra", False),
            lambda value: value["view"]["question_content"]["q-old"]["business_extra"].__setitem__("nested", False),
        ]
        for mutate in mutations:
            with self.subTest(mutation=mutate.__code__.co_firstlineno):
                before = observation()
                after = copy.deepcopy(before)
                mutate(after)
                refresh_private_evidence(after)
                self.assert_rejected(before, after)

    def test_unknown_top_level_mutation_rejects(self):
        before = observation()
        after = copy.deepcopy(before)
        after["business_envelope"]["zero"] = False
        refresh_private_evidence(after)
        self.assert_rejected(before, after)

    def test_unknown_view_mutation_rejects(self):
        before = observation()
        after = copy.deepcopy(before)
        after["view"]["business_envelope"]["one"] = 1.0
        refresh_private_evidence(after)
        self.assert_rejected(before, after)

    def test_actual_lossy_profile_raw_mutation_rejects_after_observe(self):
        with tempfile.TemporaryDirectory(prefix="a24-fixed-chain-") as tmp:
            root = Path(tmp)
            request, initial, fact, profile = fixture(root)
            initial["business_envelope"] = {"zero": 0}
            initial["view"]["business_envelope"] = {"one": 1}
            initial["directory_details"][0]["business_extra"] = 0
            initial["view"]["target"]["questions"][0]["business_extra"] = 0
            initial["view"]["target"]["frames"][0]["business_extra"] = 1
            initial["view"]["question_content"]["old-a"]["business_extra"] = {"nested": 0}
            for qid, content in initial["view"]["question_content"].items():
                raw_record = copy.deepcopy(content)
                content["raw_record"] = raw_record
                content["raw_record_json"] = json.dumps(
                    raw_record, ensure_ascii=False, separators=(",", ":"))

            projection = lossy_projection()
            profile["reads"] = {
                phase: {
                    "requests": [{
                        "name": "snapshot",
                        "path": "/qieti/api/synthetic/complete-snapshot",
                        "params": {"file_id": "46007447"},
                        "count": 1,
                    }],
                    "projection": copy.deepcopy(projection),
                }
                for phase in ("baseline", "prewrite", "get", "refresh", "reopen", "reconcile")
            }
            bind_profile(request, profile, root)
            session = FakeIO(initial, fact)
            transport = UsenseTransport(session)
            check_input(request, root, offline=True, wire=transport)
            before = transport.observe("baseline")

            session.state["business_envelope"]["zero"] = False
            session.state["view"]["business_envelope"]["one"] = 1.0
            session.state["directory_details"][0]["business_extra"] = False
            session.state["view"]["target"]["questions"][0]["business_extra"] = False
            session.state["view"]["target"]["frames"][0]["business_extra"] = 1.0
            session.state["view"]["question_content"]["old-a"]["business_extra"]["nested"] = False
            session.state["view"]["question_content"]["old-a"]["raw_record"]["business_extra"]["nested"] = False
            session.state["view"]["question_content"]["old-a"]["raw_record_json"] = json.dumps(
                session.state["view"]["question_content"]["old-a"]["raw_record"],
                ensure_ascii=False, separators=(",", ":"))
            after = transport.observe("prewrite")

            self.assertNotEqual(
                before["raw_business_responses"]["snapshot"]["body"],
                after["raw_business_responses"]["snapshot"]["body"],
            )
            self.assert_rejected(before, after)

    def test_actual_lossy_profile_top_and_view_only_raw_mutation_rejects(self):
        with tempfile.TemporaryDirectory(prefix="a24-fixed-envelope-chain-") as tmp:
            root = Path(tmp)
            request, initial, fact, profile = fixture(root)
            initial["business_envelope"] = {"zero": 0}
            initial["view"]["business_envelope"] = {"one": 1}
            for content in initial["view"]["question_content"].values():
                raw_record = copy.deepcopy(content)
                content["raw_record"] = raw_record
                content["raw_record_json"] = json.dumps(
                    raw_record, ensure_ascii=False, separators=(",", ":"))

            projection = lossy_projection()
            profile["reads"] = {
                phase: {
                    "requests": [{
                        "name": "snapshot",
                        "path": "/qieti/api/synthetic/complete-snapshot",
                        "params": {"file_id": "46007447"},
                        "count": 1,
                    }],
                    "projection": copy.deepcopy(projection),
                }
                for phase in ("baseline", "prewrite", "get", "refresh", "reopen", "reconcile")
            }
            bind_profile(request, profile, root)
            session = FakeIO(initial, fact)
            transport = UsenseTransport(session)
            check_input(request, root, offline=True, wire=transport)
            before = transport.observe("baseline")

            session.state["business_envelope"]["zero"] = False
            session.state["view"]["business_envelope"]["one"] = 1.0
            after = transport.observe("prewrite")
            self.assertNotEqual(
                before["raw_business_responses"]["snapshot"]["body"],
                after["raw_business_responses"]["snapshot"]["body"],
            )
            self.assert_rejected(before, after)

    def test_signature_response_is_not_retained_as_business_raw_evidence(self):
        session = SignatureSentinelSession()
        transport = UsenseTransport(session)
        profile = {"mode": "SYNTHETIC", "platform_version": "observed-v1"}
        profile_hash = digest(profile)
        transport.profile = profile
        transport._profile_hash = profile_hash
        transport._request = {"approval": {
            "wire_profile_hash": profile_hash,
            "starts_at": "2026-01-01T00:00:00Z",
            "ends_at": "2099-01-01T00:00:00Z",
        }}
        transport.session_id = session.session_id

        parsed = transport._read(
            wire.SIGNATURE,
            {"file_id": wire.BOOK, "dir_type": "annotate_images"},
            "upload",
            "signature",
        )
        self.assertEqual(parsed["access_token"], "SENTINEL-MUST-NOT-BE-RETAINED")
        retained = json.dumps(transport._raw_reads, ensure_ascii=False)
        self.assertNotIn("SENTINEL-MUST-NOT-BE-RETAINED", retained)
        self.assertNotIn(("upload", "signature"), transport._raw_reads)

    def test_private_sidecar_disappearance_rejects(self):
        before = observation()
        after = copy.deepcopy(before)
        del after["raw_business_projection"]
        with self.assertRaises(PilotError) as caught:
            check_preservation(before, after, None)
        self.assertEqual(caught.exception.code, "RAW_BUSINESS_PRESERVATION_MISSING")

    def test_recursive_directory_children_tree_is_explicitly_unsupported(self):
        value = observation()
        value.pop("raw_business_projection")
        tree = [{
            "id": "dir-root",
            "children": [{
                "id": "leaf",
                "children": [{
                    "id": "q-old",
                    "isQuestion": True,
                    "order_in_level": "1",
                    "children": [],
                }],
            }],
        }]
        traces = []
        rule = {"array": {
            "source": {"from": {"response": "directory", "path": []}},
            "children_path": ["children"],
            "item": {"object": {
                "directory_id": {"from": {"response": "$", "path": ["id"]}},
                "parent_id": {"literal": None},
            }},
        }}
        value["directory_details"] = wire.project(
            rule, {"directory": tree}, collector=traces, path=("directory_details",))
        value["view"]["target"]["directories"] = [
            item["directory_id"] for item in value["directory_details"]
        ]
        with self.assertRaises(PilotError) as caught:
            wire.build_business_preservation(value, traces=traces, direct_view=False)
        self.assertEqual(caught.exception.code, "RAW_ENTITY_RECURSIVE_CONTAINER_UNSUPPORTED")

    def test_legal_one_question_six_frame_append_passes(self):
        before = observation()
        after = copy.deepcopy(before)
        pid = "q-new"
        rect_ids = [f"r-new-{index}" for index in range(6)]
        after["view"]["target"]["questions"].append({
            "platform_question_id": pid,
            "platform_order": 2,
            "directory_id": "leaf",
        })
        after["view"]["target"]["frames"].extend(
            {"platform_frame_id": rid, "platform_question_id": pid}
            for rid in rect_ids
        )
        after["view"]["internal_bindings"]["internal-new"] = pid
        after["view"]["frame_projections"].update({rid: {"index": i}
                                                       for i, rid in enumerate(rect_ids)})
        after["view"]["question_content"][pid] = {
            "status": "AVAILABLE",
            "question_type": "ordinary_choice",
            "parts": [{}],
            "wire_zones": {zone: None for zone in wire.ZONES},
            "question_info": {},
            "rect_ids": rect_ids,
        }
        refresh_private_evidence(after)
        check_preservation(before, after, pid)


if __name__ == "__main__":
    unittest.main(verbosity=2)
