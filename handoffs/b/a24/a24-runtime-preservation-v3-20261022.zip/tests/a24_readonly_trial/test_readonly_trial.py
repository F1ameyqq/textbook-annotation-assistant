import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from annotation.quality.live_pilot import PilotError
from annotation.runtime.live_pilot.readonly_trial import (
    _field_evidence,
    load_precheck_diagnosis,
    run_readonly_trial,
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


class ReadonlyTrialTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="a24-readonly-")
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def source(self, records):
        raw = "\n".join(json.dumps(item, ensure_ascii=False, separators=(",", ":"))
                        for item in records).encode("utf-8")
        path = self.root / "source.jsonl"
        path.write_bytes(raw)
        return path, raw

    def test_historical_adapter_preserves_mapped_values_extras_and_reads_back(self):
        records = [
            {"question": "Q1", "option": ["B", "A"], "answer": "A",
             "extra": {"null": None, "empty": ""}},
            {"question": " ", "option": [], "answer": False, "count": 0},
        ]
        path, raw = self.source(records)
        public, receipt = run_readonly_trial(
            path, self.root / "out", sha(raw), len(raw), "HISTORICAL_EXPORT")
        self.assertEqual(public["record_count"], 2)
        self.assertEqual(public["source_type"], "HISTORICAL_EXPORT")
        self.assertEqual(public["source_type_basis"], "CALLER_DECLARED")
        self.assertIs(public["canonical_question_id"], None)
        self.assertIs(public["write_allowed"], False)
        self.assertEqual(receipt["result"], "PASS_EXACT_LOCAL_READBACK")
        self.assertEqual((self.root / "out/private/records.full.jsonl").read_bytes(), raw)
        adapted = json.loads((self.root / "out/private/records.adapted.json").read_text("utf-8"))
        self.assertEqual(adapted[0]["mapped_fields"], {
            "question": "Q1", "option": ["B", "A"], "answer": "A"})
        self.assertEqual(adapted[0]["extra_fields"], {"extra": {"null": None, "empty": ""}})
        self.assertEqual(adapted[1]["field_states"], {
            "question": "PRESENT", "option": "EMPTY", "answer": "PRESENT"})

    def test_field_states_do_not_collapse_missing_null_empty_or_present(self):
        record = {"null": None, "empty_s": "", "empty_a": [], "empty_o": {},
                  "space": " ", "zero": 0, "false": False}
        self.assertEqual(_field_evidence(record, "missing")["state"], "MISSING")
        self.assertEqual(_field_evidence(record, "null")["state"], "NULL")
        for name in ("empty_s", "empty_a", "empty_o"):
            self.assertEqual(_field_evidence(record, name)["state"], "EMPTY")
        for name in ("space", "zero", "false"):
            self.assertEqual(_field_evidence(record, name)["state"], "PRESENT")

    def test_current_mode_requires_exactly_one_record(self):
        path, raw = self.source([{"question": "Q1"}, {"question": "Q2"}])
        with self.assertRaises(PilotError) as caught:
            run_readonly_trial(path, self.root / "out", sha(raw), len(raw),
                               "CURRENT_RAW_RECORD")
        self.assertEqual(caught.exception.code, "CURRENT_RECORD_CARDINALITY")

    def test_invalid_precheck_rejects_before_output_creation(self):
        path, raw = self.source([{"question": "Q1", "option": [], "answer": "A"}])
        invalid = {"schema": "A24CurrentPlatformObservations/v3",
                   "export_questions_reconciliation": {
                       "error_count": 9, "warning_count": 0, "errors": []}}
        precheck_raw = json.dumps(invalid).encode("utf-8")
        precheck_path = self.root / "invalid-precheck.json"
        precheck_path.write_bytes(precheck_raw)
        out = self.root / "out"
        with self.assertRaises(PilotError) as caught:
            run_readonly_trial(path, out, sha(raw), len(raw), "HISTORICAL_EXPORT",
                               precheck={"path": precheck_path,
                                         "sha256": sha(precheck_raw),
                                         "bytes": len(precheck_raw)})
        self.assertEqual(caught.exception.code, "PRECHECK_ERROR_LEDGER")
        self.assertFalse(out.exists())
        self.assertEqual(path.read_bytes(), raw)

    def test_local_line_selection_is_explicit_and_identity_remains_null(self):
        path, raw = self.source([{"question": "Q1"}, {"question": "Q2"}])
        public, _ = run_readonly_trial(
            path, self.root / "out", sha(raw), len(raw), "HISTORICAL_EXPORT", 2)
        self.assertEqual(public["selection"], {
            "kind": "LOCAL_SOURCE_LINE", "local_source_line": 2})
        self.assertIs(public["records"][0]["canonical_question_id"], None)
        self.assertIn("NO_AUTOMATIC_JOIN_TO_DOM_OR_HISTORY_NUMBER", public["limits"])

    def test_precheck_diagnosis_keeps_underlying_field_state_unobserved(self):
        errors = [
            {"importShitiID": qid, "field": field, "message": message}
            for qid, field, message in (
                ("1", "choice", "tishi 为 xuanze/duoxuan 时 choice 必填"),
                ("2", "choice", "tishi 为 xuanze/duoxuan 时 choice 必填"),
                ("7", "question", "question 不能为空"),
                ("7", "answer", "answer 不能为空"),
                ("7", "choice", "tishi 为 xuanze/duoxuan 时 choice 必填"),
                ("19", "question", "question 不能为空"),
                ("19", "answer", "answer 不能为空"),
                ("22", "question", "question 不能为空"),
                ("22", "answer", "answer 不能为空"),
            )]
        value = {
            "schema": "A24CurrentPlatformObservations/v3",
            "export_questions_reconciliation": {
                "error_count": 9, "warning_count": 0, "errors": errors},
            "artifacts": [{"collection_method": "DOM_SNAPSHOT_TEXT",
                           "bytes": 20487, "sha256": "0" * 64}],
        }
        raw = json.dumps(value, ensure_ascii=False).encode("utf-8")
        path = self.root / "v3.json"
        path.write_bytes(raw)
        diagnosis = load_precheck_diagnosis(path, sha(raw), len(raw))
        self.assertEqual(diagnosis["error_count"], 9)
        self.assertTrue(all(item["underlying_field_state"] == "UNOBSERVED" and
                            item["missing"] is None and item["null"] is None and
                            item["empty"] is None for item in diagnosis["errors"]))
        self.assertIn("NOT_SERVER_QUESTION_ID", diagnosis["identity_boundary"])


if __name__ == "__main__":
    unittest.main()
