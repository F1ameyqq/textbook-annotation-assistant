import copy
import hashlib
import json
from pathlib import Path
import tempfile
import unittest

from annotation.quality.live_pilot import PilotError
from annotation.runtime.live_pilot.archived_target_preservation import (
    build_preservation,
    run,
    validate_preservation,
)


def sha(raw):
    return hashlib.sha256(raw).hexdigest()


class ArchivedTargetPreservationTests(unittest.TestCase):
    def setUp(self):
        self.temp = tempfile.TemporaryDirectory(prefix="a24-archived-target-")
        self.root = Path(self.temp.name)

    def tearDown(self):
        self.temp.cleanup()

    def fixtures(self, data_key="1792064001811"):
        target = {
            "book_id": "46007447",
            "directories": [{
                "id": "directory-1",
                "label": "section",
                "parent": None,
                "raw_node_fields": {"id": "directory-1", "label": "section",
                                    "directory_raw_extra": {"kept": True}},
                "directory_extra": [None, ""],
            }],
            "questions": [{
                "id": "1792064001811",
                "directory_id": "directory-1",
                "frames": [{
                    "belong_to_level": 1,
                    "content_type": "image",
                    "directory_id": "directory-1",
                    "file_id": "file-1",
                    "image_order_in_annotation_zone": 0,
                    "image_path_sha256": "a" * 64,
                    "is_pre_annotation": False,
                    "order_in_level": 1,
                    "page_index": 0,
                    "parent_rect_id": None,
                    "pre_annotations_id": None,
                    "rect_bbox": [1, 2, 3, 4],
                    "rect_id": "rect-1",
                    "type": "Q",
                    "frame_extra": {"zero": 0},
                }],
                "frontend_derivation": None,
                "frontend_derived_frame_candidates": [],
                "frontend_derived_global_order": 1,
                "frontend_derived_label": "1",
                "order": 1,
                "raw_label": "1",
                "raw_node_fields": {"id": "1792064001811", "isQuestion": True,
                                    "label": "1", "order_in_level": 1,
                                    "question_raw_extra": False},
                "raw_order_field_present": True,
                "raw_order_in_level": 1,
                "raw_order_status": "PRESENT",
                "content": {"status": "UNKNOWN", "reason": "NOT_FETCHED", "text": None,
                            "content_extra": "retain"},
                "question_extra": {"nested": [0, None]},
            }],
            "inventory_coverage": "PARTIAL",
            "content_coverage": "UNKNOWN",
            "raw_directory_tree_is_full_response_body": False,
            "target_extra": {"first": 1, "second": 2},
        }
        state = {
            "authentication": {"token": "DO-NOT-EXPORT-SECRET"},
            "account_identity_fields_available": ["username"],
            "target": target,
        }
        historical_records = [
            {"question": "old-1", "option": ["B", "A"], "answer": "A"},
            {"question": "old-2", "option": [], "answer": "D"},
        ]
        historical_raw = b"\n".join(
            json.dumps(item, ensure_ascii=False, separators=(",", ":")).encode("utf-8")
            for item in historical_records
        )
        dom = {"matches": [{"dataKey": data_key, "label": "1"}]}
        state_raw = (json.dumps(state, ensure_ascii=False) + "\n").encode("utf-8")
        dom_raw = (json.dumps(dom, ensure_ascii=False) + "\n").encode("utf-8")
        state_path = self.root / "current-state.json"
        historical_path = self.root / "historical.jsonl"
        dom_path = self.root / "current-dom.json"
        state_path.write_bytes(state_raw)
        historical_path.write_bytes(historical_raw)
        dom_path.write_bytes(dom_raw)
        return target, (state_path, state_raw), (historical_path, historical_raw), (dom_path, dom_raw)

    def invoke(self, data_key="1792064001811", output_name="out"):
        target, state, historical, dom = self.fixtures(data_key)
        public, receipt = run(
            state[0], self.root / output_name, sha(state[1]), len(state[1]),
            historical[0], sha(historical[1]), len(historical[1]),
            dom[0], sha(dom[1]), len(dom[1]),
        )
        return target, state, historical, dom, public, receipt

    def test_unknown_fields_roundtrip_and_credentials_are_not_exported(self):
        target, _, historical, _, public, receipt = self.invoke()
        output = self.root / "out"
        exported = (output / "private" / "archived-target.full.json").read_text("utf-8")
        preservation = json.loads(
            (output / "private" / "archived-target.preservation.json").read_text("utf-8"))
        self.assertEqual(json.loads(exported), target)
        self.assertTrue(validate_preservation(target, preservation))
        self.assertNotIn("DO-NOT-EXPORT-SECRET", exported)
        self.assertNotIn('"authentication"', exported)
        self.assertEqual(
            (output / "private" / "historical-records.full.jsonl").read_bytes(),
            historical[1],
        )
        extras = public["archived_target"]["extra_field_names"]
        self.assertEqual(extras["target"], ["target_extra"])
        self.assertEqual(extras["question"], ["question_extra"])
        self.assertEqual(extras["question_raw_node"], ["question_raw_extra"])
        self.assertEqual(extras["content"], ["content_extra"])
        self.assertEqual(extras["frame"], ["frame_extra"])
        self.assertEqual(extras["directory"], ["directory_extra"])
        self.assertEqual(extras["directory_raw_node"], ["directory_raw_extra"])
        self.assertEqual(public["identity_candidate"]["archived_match_count"], 1)
        self.assertIsNone(public["canonical_question_id"])
        self.assertFalse(public["write_allowed"])
        self.assertIsNone(public["comparison_boundary"]["authoritative_old_question_denominator"])
        self.assertEqual(receipt["result"], "PASS_EXACT_OFFLINE_READBACK")

    def test_deleting_nested_extra_from_projection_is_a_hard_failure(self):
        target, *_ = self.fixtures()
        for key in ("target_extra", "question_extra", "frame_extra"):
            with self.subTest(key=key):
                damaged = build_preservation(target)
                if key == "target_extra":
                    del damaged["target"]["extra_fields"][key]
                elif key == "question_extra":
                    del damaged["questions"][0]["object"]["extra_fields"][key]
                else:
                    del damaged["questions"][0]["frames"][0]["extra_fields"][key]
                with self.assertRaises(PilotError) as caught:
                    validate_preservation(target, damaged)
                self.assertEqual(caught.exception.code, "ARCHIVED_TARGET_LOSS")

    def test_nested_zero_to_false_is_not_equal(self):
        target, *_ = self.fixtures()
        damaged = build_preservation(target)
        nested = damaged["questions"][0]["object"]["extra_fields"]["question_extra"]
        self.assertEqual(nested["nested"][0], 0)
        nested["nested"][0] = False
        with self.assertRaises(PilotError) as caught:
            validate_preservation(target, damaged)
        self.assertEqual(caught.exception.code, "ARCHIVED_TARGET_LOSS")

    def test_nested_object_key_order_swap_is_not_equal(self):
        target, *_ = self.fixtures()
        damaged = build_preservation(target)
        damaged["target"]["extra_fields"]["target_extra"] = {
            "second": 2,
            "first": 1,
        }
        with self.assertRaises(PilotError) as caught:
            validate_preservation(target, damaged)
        self.assertEqual(caught.exception.code, "ARCHIVED_TARGET_LOSS")

    def test_duplicate_original_field_order_rejects(self):
        target, *_ = self.fixtures()
        damaged = build_preservation(target)
        damaged["target"]["original_field_order"].append("book_id")
        with self.assertRaises(PilotError) as caught:
            validate_preservation(target, damaged)
        self.assertEqual(caught.exception.code, "ARCHIVED_TARGET_LOSS")

    def test_printed_number_is_never_used_as_identity_join(self):
        _, _, _, _, public, _ = self.invoke(data_key="1")
        identity = public["identity_candidate"]
        self.assertEqual(identity["status"], "HOLD_NO_UNIQUE_ARCHIVED_NODE_MATCH")
        self.assertEqual(identity["archived_match_count"], 0)
        self.assertIsNone(identity["archived_question_id"])
        self.assertFalse(identity["same_number_join_used"])
        self.assertIsNone(identity["canonical_question_id"])

    def test_wrong_current_state_sha_fails_before_output_creation(self):
        _, state, historical, dom = self.fixtures()
        output = self.root / "must-not-exist"
        with self.assertRaises(PilotError) as caught:
            run(
                state[0], output, "0" * 64, len(state[1]),
                historical[0], sha(historical[1]), len(historical[1]),
                dom[0], sha(dom[1]), len(dom[1]),
            )
        self.assertEqual(caught.exception.code, "ARCHIVED_CURRENT_STATE_BYTES")
        self.assertFalse(output.exists())

    def test_duplicate_key_rejects_before_output_creation(self):
        _, _, historical, dom = self.fixtures()
        raw = b'{"target":{},"target":{}}'
        source = self.root / "duplicate.json"
        source.write_bytes(raw)
        output = self.root / "duplicate-out"
        with self.assertRaises(PilotError) as caught:
            run(
                source, output, sha(raw), len(raw),
                historical[0], sha(historical[1]), len(historical[1]),
                dom[0], sha(dom[1]), len(dom[1]),
            )
        self.assertEqual(caught.exception.code, "ARCHIVED_JSON_DUPLICATE_KEY")
        self.assertFalse(output.exists())


if __name__ == "__main__":
    unittest.main()
