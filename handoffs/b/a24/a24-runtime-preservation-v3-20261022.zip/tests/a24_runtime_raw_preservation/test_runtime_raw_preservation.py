"""Focused regressions for lossless runtime old-business preservation."""
import copy
import json
from pathlib import Path
import sys
import unittest

from annotation.delivery.live_pilot import wire
from annotation.delivery.live_pilot.usense import UsenseTransport
from annotation.quality.live_pilot import PilotError, check_preservation, json_same, state_facts
from annotation.runtime.storage.common import digest


def observation(extra=None):
    content = {
        "status": "AVAILABLE",
        "question_type": "ordinary_choice",
        "parts": [{"text": "old"}],
        "wire_zones": {zone: None for zone in wire.ZONES},
        "question_info": {},
        "rect_ids": ["r-old"],
    }
    if extra is not None:
        content["opaque"] = copy.deepcopy(extra)
    value = {
        "book_id": "46007447",
        "platform_version": "observed-v1",
        "complete": True,
        "read_status": "OK",
        "submission_status": "NOT_SUBMITTED",
        "source_bindings": {},
        "directory_details": [{"directory_id": "leaf", "parent_id": None}],
        "view": {
            "target": {
                "directories": ["leaf"],
                "questions": [{"platform_question_id": "q-old", "platform_order": 1,
                               "directory_id": "leaf"}],
                "frames": [{"platform_frame_id": "r-old", "platform_question_id": "q-old"}],
            },
            "internal_bindings": {},
            "frame_projections": {"r-old": {}},
            "question_content": {"q-old": content},
        },
    }
    value["raw_business_projection"] = wire.build_business_preservation(value, direct_view=True)
    return value


def content_record(pid, text):
    raw = {
        "platform_question_id": pid,
        "question_type": "ordinary_choice",
        "parts": [{"text": text}],
        "wire_zones": {zone: None for zone in wire.ZONES},
        "question_info": {},
        "rect_ids": ["r-old"] if pid == "q-old" else ["r-new-" + str(i) for i in range(6)],
    }
    value = copy.deepcopy(raw)
    value.update({"status": "AVAILABLE", "raw_record": copy.deepcopy(raw),
                  "raw_record_json": json.dumps(raw, ensure_ascii=False, separators=(",", ":"))})
    return value


def projected_observation(*, old_extra, append=False):
    """Build normalized state while retaining the original lossy-projection rows."""
    value = observation()
    value.pop("raw_business_projection")
    question_rows = [{"qid": "q-old", "order": 1, "directory": "leaf",
                      "unknown_extra": copy.deepcopy(old_extra)}]
    frame_rows = [{"rid": "r-old", "owner": "q-old", "unknown_frame": {"zero": 0}}]
    directory_rows = [{"did": "leaf", "parent": None, "unknown_directory": [1, None]}]
    if append:
        question_rows.append({"qid": "q-new", "order": 2, "directory": "leaf",
                              "unknown_extra": {"new": True}})
        frame_rows.extend({"rid": "r-new-" + str(i), "owner": "q-new",
                           "unknown_frame": {"index": i}} for i in range(6))
    traces = []
    def array_rule(response, fields):
        return {"array": {"source": {"from": {"response": response, "path": []}},
                          "item": {"object": fields}}}
    value["view"]["target"]["questions"] = wire.project(array_rule("questions", {
        "platform_question_id": {"from": {"response": "$", "path": ["qid"]}},
        "platform_order": {"from": {"response": "$", "path": ["order"]}},
        "directory_id": {"from": {"response": "$", "path": ["directory"]}},
    }), {"questions": question_rows}, collector=traces, path=("view", "target", "questions"))
    value["view"]["target"]["frames"] = wire.project(array_rule("frames", {
        "platform_frame_id": {"from": {"response": "$", "path": ["rid"]}},
        "platform_question_id": {"from": {"response": "$", "path": ["owner"]}},
    }), {"frames": frame_rows}, collector=traces, path=("view", "target", "frames"))
    value["directory_details"] = wire.project(array_rule("directories", {
        "directory_id": {"from": {"response": "$", "path": ["did"]}},
        "parent_id": {"from": {"response": "$", "path": ["parent"]}},
    }), {"directories": directory_rows}, collector=traces, path=("directory_details",))
    value["view"]["question_content"] = {"q-old": content_record("q-old", "old")}
    if append:
        value["view"]["internal_bindings"]["local-new"] = "q-new"
        value["view"]["question_content"]["q-new"] = content_record("q-new", "new")
        for index in range(6):
            value["view"]["frame_projections"]["r-new-" + str(index)] = {"index": index}
    value["raw_business_projection"] = wire.build_business_preservation(
        value, traces=traces, direct_view=False)
    return value


class FakeRawSession:
    offline = True
    evidence_mode = "SYNTHETIC"
    actor = "author"
    session_id = "raw-session"

    def __init__(self, state, *, reorder_prewrite=True):
        self.state = copy.deepcopy(state)
        self.serial = 0
        self.reorder_prewrite = reorder_prewrite

    def request_once(self, method, path, *, params, payload, phase):
        self.serial += 1
        if phase == "upload":
            body = {"credentials": {"accessid": "SENTINEL_ACCESS_ID",
                                     "policy": "SENTINEL_POLICY",
                                     "signature": "SENTINEL_SIGNATURE",
                                     "securityToken": "SENTINEL_SECURITY_TOKEN"}}
        else:
            body = {"snapshot": copy.deepcopy(self.state),
                    "unprojected_extra": {"first": 1, "second": 2}}
        if phase == "prewrite" and self.reorder_prewrite:
            body["unprojected_extra"] = {"second": 2, "first": 1}
        return {
            "http_status": 200,
            "body": json.dumps(body, ensure_ascii=False, separators=(",", ":")),
            "request_id": "raw-session:" + str(self.serial),
            "session_id": self.session_id,
            "fresh": True,
            "cache": False,
            "platform_version": "observed-v1",
        }


class RuntimeRawPreservationTests(unittest.TestCase):
    def observe_pair(self, *, reorder_prewrite):
        state = observation()
        state.pop("raw_business_projection")
        session = FakeRawSession(state, reorder_prewrite=reorder_prewrite)
        transport = UsenseTransport(session)
        spec = {"path": "/qieti/api/synthetic/complete-snapshot", "params": {}, "count": 1,
                "response_fields": {key: ["snapshot", key] for key in wire.SNAPSHOT_FIELDS}}
        profile = {"mode": "SYNTHETIC", "platform_version": "observed-v1",
                   "reads": {"baseline": spec, "prewrite": copy.deepcopy(spec)}}
        profile_hash = digest(profile)
        transport.profile = profile
        transport._profile_hash = profile_hash
        transport._request = {"approval": {"wire_profile_hash": profile_hash,
            "starts_at": "2026-01-01T00:00:00Z", "ends_at": "2099-01-01T00:00:00Z"}}
        transport.session_id = session.session_id
        baseline = transport.observe("baseline")
        pid = "q-new"
        session.state["view"]["target"]["questions"].append(
            {"platform_question_id": pid, "platform_order": 2, "directory_id": "leaf"})
        for index in range(6):
            rid = "r-new-" + str(index)
            session.state["view"]["target"]["frames"].append(
                {"platform_frame_id": rid, "platform_question_id": pid})
            session.state["view"]["frame_projections"][rid] = {"index": index}
        session.state["view"]["internal_bindings"]["local-new"] = pid
        session.state["view"]["question_content"][pid] = {
            "status": "AVAILABLE", "question_type": "ordinary_choice",
            "parts": [{"text": "new"}], "wire_zones": {zone: None for zone in wire.ZONES},
            "question_info": {}, "rect_ids": ["r-new-" + str(i) for i in range(6)],
        }
        return baseline, transport.observe("prewrite"), pid

    def test_old_json_type_and_key_order_changes_are_rejected(self):
        cases = [
            ({"value": 0}, {"value": False}),
            ({"first": 1, "second": 2}, {"second": 2, "first": 1}),
        ]
        for before_extra, after_extra in cases:
            with self.subTest(after=after_extra):
                with self.assertRaises(PilotError) as caught:
                    check_preservation(observation(before_extra), observation(after_extra))
                self.assertIn(caught.exception.code,
                              {"OLD_QUESTION_CONTENT_CHANGED", "OLD_RAW_BUSINESS_CHANGED"})

    def test_legal_one_question_six_frame_append_still_passes(self):
        before = observation({"nested": [0, None, ""]})
        after = copy.deepcopy(before)
        pid = "q-new"
        after["view"]["target"]["questions"].append(
            {"platform_question_id": pid, "platform_order": 2, "directory_id": "leaf"})
        for index in range(6):
            rid = "r-new-" + str(index)
            after["view"]["target"]["frames"].append(
                {"platform_frame_id": rid, "platform_question_id": pid})
            after["view"]["frame_projections"][rid] = {"index": index}
        after["view"]["internal_bindings"]["local-new"] = pid
        after["view"]["question_content"][pid] = {
            "status": "AVAILABLE", "question_type": "ordinary_choice",
            "parts": [{"text": "new"}], "wire_zones": {zone: None for zone in wire.ZONES},
            "question_info": {}, "rect_ids": ["r-new-" + str(i) for i in range(6)],
        }
        after["raw_business_projection"] = wire.build_business_preservation(after, direct_view=True)
        check_preservation(before, after, pid)

    def test_lossy_projection_legal_append_passes_but_old_raw_mutation_rejects(self):
        before = projected_observation(old_extra={"first": 1, "second": 2})
        legal_after = projected_observation(old_extra={"first": 1, "second": 2}, append=True)
        check_preservation(before, legal_after, "q-new")

        mutated_after = projected_observation(old_extra={"second": 2, "first": 1}, append=True)
        with self.assertRaises(PilotError) as caught:
            check_preservation(before, mutated_after, "q-new")
        self.assertEqual(caught.exception.code, "OLD_RAW_ENTITY_CHANGED")

    def test_lossy_projection_without_raw_entity_binding_is_rejected(self):
        value = observation()
        value.pop("raw_business_projection")
        with self.assertRaises(PilotError) as caught:
            wire.build_business_preservation(value, traces=(), direct_view=False)
        self.assertEqual(caught.exception.code, "RAW_ENTITY_PRESERVATION_UNBOUND")

    def test_recursive_raw_container_requires_a_declared_increment_model(self):
        value = observation()
        value.pop("raw_business_projection")
        rows = [{"did": "leaf", "parent": None, "children": []}]
        traces = []
        rule = {"array": {
            "source": {"from": {"response": "directories", "path": []}},
            "children_path": ["children"],
            "item": {"object": {
                "directory_id": {"from": {"response": "$", "path": ["did"]}},
                "parent_id": {"from": {"response": "$", "path": ["parent"]}},
            }},
        }}
        value["directory_details"] = wire.project(
            rule, {"directories": rows}, collector=traces, path=("directory_details",))
        with self.assertRaises(PilotError) as caught:
            wire.build_business_preservation(value, traces=traces, direct_view=False)
        self.assertEqual(caught.exception.code, "RAW_ENTITY_RECURSIVE_CONTAINER_UNSUPPORTED")

    def test_unknown_observation_view_and_target_fields_are_preserved(self):
        for location, code in (("observation", "OLD_OBSERVATION_EXTRA_CHANGED"),
                               ("view", "OLD_VIEW_EXTRA_CHANGED"),
                               ("target", "OLD_TARGET_EXTRA_CHANGED")):
            with self.subTest(location=location):
                before = observation()
                after = copy.deepcopy(before)
                owner = after if location == "observation" else after["view"]
                if location == "target":
                    owner = after["view"]["target"]
                owner["opaque_unknown"] = {"changed": True}
                with self.assertRaises(PilotError) as caught:
                    check_preservation(before, after)
                self.assertEqual(caught.exception.code, code)

    def test_runtime_sidecar_cannot_disappear(self):
        before = observation({"kept": True})
        after = copy.deepcopy(before)
        del after["raw_business_projection"]
        with self.assertRaises(PilotError) as caught:
            check_preservation(before, after)
        self.assertEqual(caught.exception.code, "RAW_BUSINESS_PRESERVATION_MISSING")

    def test_natural_export_retains_full_raw_record_and_exact_key_order(self):
        codec = {
            "schema": "A24NaturalExportCodec/v1",
            "question_fields": {key: [key] for key in
                ("platform_question_id", "question_type", "parts", "wire_zones",
                 "question_info", "rect_ids")},
            "qualification": {
                "schema": "A24FullBodyRouteQualification/v1", "status": "VERIFIED",
                "route": wire.EXPORT, "book_id": "46007447",
                "authoritative_catalog_complete": True,
                "all_business_fields_covered": True, "zones": list(wire.ZONES),
                "state_binding": "synthetic", "evidence_refs": ["synthetic"],
            },
        }
        record = {
            "platform_question_id": "q-old", "question_type": "ordinary_choice",
            "parts": [{"text": "old"}], "wire_zones": {zone: None for zone in wire.ZONES},
            "question_info": {}, "rect_ids": ["r-old"],
            "unknown_extra": {"second": 2, "first": 1},
        }
        raw_line = json.dumps(record, ensure_ascii=False, separators=(",", ":"))
        contents, _ = wire.decode_natural_export(
            raw_line, codec, [{"platform_question_id": "q-old"}])
        saved = contents["q-old"]
        self.assertEqual(saved["raw_record_json"], raw_line)
        self.assertEqual(list(saved["raw_record"]["unknown_extra"]), ["second", "first"])
        self.assertTrue(json_same(saved["raw_record"], record))

    def test_actual_observe_keeps_unprojected_response_and_prewrite_detects_it(self):
        state = observation()
        state.pop("raw_business_projection")
        session = FakeRawSession(state)
        transport = UsenseTransport(session)
        spec = {"path": "/qieti/api/synthetic/complete-snapshot", "params": {}, "count": 1,
                "response_fields": {key: ["snapshot", key] for key in wire.SNAPSHOT_FIELDS}}
        profile = {"mode": "SYNTHETIC", "platform_version": "observed-v1",
                   "reads": {"baseline": spec, "prewrite": copy.deepcopy(spec)}}
        profile_hash = digest(profile)
        transport.profile = profile
        transport._profile_hash = profile_hash
        transport._request = {"approval": {"wire_profile_hash": profile_hash,
            "starts_at": "2026-01-01T00:00:00Z", "ends_at": "2099-01-01T00:00:00Z"}}
        transport.session_id = session.session_id
        baseline = transport.observe("baseline")
        prewrite = transport.observe("prewrite")
        self.assertIn("raw_business_responses", baseline)
        self.assertIn("raw_business_projection", baseline)
        self.assertEqual(baseline["raw_business_responses"]["snapshot"]["representation"],
                         "UTF8_REENCODED_RESPONSE_TEXT")
        self.assertNotEqual(
            baseline["raw_business_responses"]["snapshot"]["body"],
            prewrite["raw_business_responses"]["snapshot"]["body"],
        )
        self.assertFalse(json_same(state_facts(baseline), state_facts(prewrite)))

    def test_actual_observe_residual_allows_append_but_rejects_wrapper_mutation(self):
        before, legal_after, pid = self.observe_pair(reorder_prewrite=False)
        check_preservation(before, legal_after, pid)
        self.assertTrue(json_same(before["raw_business_residuals"],
                                  legal_after["raw_business_residuals"]))
        new_entities = legal_after["raw_business_projection"]["raw_entities"]
        self.assertEqual(len([item for item in new_entities
                              if item["kind"] == "frame" and
                              item["owner_platform_question_id"] == pid]), 6)
        self.assertEqual({item["kind"] for item in new_entities if item["stable_id"] == pid},
                         {"question", "content"})
        content = next(item for item in new_entities
                       if item["kind"] == "content" and item["stable_id"] == pid)
        self.assertEqual(set(content["raw_record"]["wire_zones"]), set(wire.ZONES))

        before, mutated_after, pid = self.observe_pair(reorder_prewrite=True)
        with self.assertRaises(PilotError) as caught:
            check_preservation(before, mutated_after, pid)
        self.assertEqual(caught.exception.code, "OLD_RAW_RESPONSE_RESIDUAL_CHANGED")

    def test_typed_wrapper_mask_preserves_keys_order_types_and_unknown_structure(self):
        declared = [["snapshot", "view"]]
        baseline = {"snapshot": {"view": {"business": "changes legally"}},
                    "opaque": {"first": 0, "second": [None, ""]}}
        same_wrapper_new_business = copy.deepcopy(baseline)
        same_wrapper_new_business["snapshot"]["view"] = {"new_question": True}
        before = wire.response_residual(baseline, declared)
        after = wire.response_residual(same_wrapper_new_business, declared)
        self.assertTrue(json_same(before, after))
        snapshot_entry = before["entries"][0]
        self.assertEqual(snapshot_entry["key"], "snapshot")
        self.assertEqual(snapshot_entry["value"]["entries"][0]["value"],
                         {"node_type": "DECLARED_SUBTREE_MASK"})

        variants = []
        added = copy.deepcopy(baseline); added["new_unknown"] = 1; variants.append(added)
        deleted = copy.deepcopy(baseline); del deleted["opaque"]["second"]; variants.append(deleted)
        type_changed = copy.deepcopy(baseline); type_changed["opaque"]["first"] = False; variants.append(type_changed)
        reordered = {"opaque": {"first": 0, "second": [None, ""]},
                     "snapshot": copy.deepcopy(baseline["snapshot"])}; variants.append(reordered)
        for variant in variants:
            with self.subTest(variant=variant):
                self.assertFalse(json_same(before, wire.response_residual(variant, declared)))

    def test_multi_request_residual_without_coverage_binding_is_rejected(self):
        state = observation()
        state.pop("raw_business_projection")
        session = FakeRawSession(state)
        transport = UsenseTransport(session)
        spec = {
            "requests": [
                {"name": "snapshot", "path": "/qieti/api/synthetic/complete-snapshot", "params": {}},
                {"name": "unused", "path": "/qieti/api/synthetic/complete-snapshot", "params": {}},
            ],
            "projection": {key: {"from": {"response": "snapshot", "path": ["snapshot", key]}}
                           for key in wire.SNAPSHOT_FIELDS},
        }
        profile = {"mode": "SYNTHETIC", "platform_version": "observed-v1",
                   "reads": {"baseline": spec}}
        profile_hash = digest(profile)
        transport.profile = profile
        transport._profile_hash = profile_hash
        transport._request = {"approval": {"wire_profile_hash": profile_hash,
            "starts_at": "2026-01-01T00:00:00Z", "ends_at": "2099-01-01T00:00:00Z"}}
        transport.session_id = session.session_id
        with self.assertRaises(PilotError) as caught:
            transport.observe("baseline")
        self.assertEqual(caught.exception.code, "RAW_RESPONSE_RESIDUAL_UNBOUND")
        self.assertIn(("baseline", "snapshot"), transport._raw_reads)
        self.assertIn(("baseline", "unused"), transport._raw_reads)

    def test_signature_credentials_never_enter_business_raw_sidecar(self):
        state = observation()
        state.pop("raw_business_projection")
        session = FakeRawSession(state)
        transport = UsenseTransport(session)
        spec = {"path": "/qieti/api/synthetic/complete-snapshot", "params": {}, "count": 1,
                "response_fields": {key: ["snapshot", key] for key in wire.SNAPSHOT_FIELDS}}
        profile = {"mode": "SYNTHETIC", "platform_version": "observed-v1",
                   "reads": {"baseline": spec}}
        profile_hash = digest(profile)
        transport.profile = profile
        transport._profile_hash = profile_hash
        transport._request = {"approval": {"wire_profile_hash": profile_hash,
            "starts_at": "2026-01-01T00:00:00Z", "ends_at": "2099-01-01T00:00:00Z"}}
        transport.session_id = session.session_id
        baseline = transport.observe("baseline")
        transport._read(wire.SIGNATURE, {"file_id": wire.BOOK, "dir_type": "annotate_images"},
                        "upload", "signature")
        serialized_private = json.dumps(list(transport._raw_reads.values()), ensure_ascii=False)
        serialized_result = json.dumps(baseline["raw_business_responses"], ensure_ascii=False)
        self.assertNotIn(("upload", "signature"), transport._raw_reads)
        for sentinel in ("SENTINEL_ACCESS_ID", "SENTINEL_POLICY", "SENTINEL_SIGNATURE",
                         "SENTINEL_SECURITY_TOKEN"):
            self.assertNotIn(sentinel, serialized_private)
            self.assertNotIn(sentinel, serialized_result)


if __name__ == "__main__":
    unittest.main()
