# A04 coordinate-R2: bounded offline repair

Base `a86eca6ec87ced20dc3a8bcc8f2c87d329e87c39`; workflow
`e1b1475597f80d46c5ace5c004f5091d139ac6cc`. No floating coordinator merge.

The A04 source parser now verifies image structure and fully decodes the same
bytes, then binds decoded format/dimensions and their SHA256. It repeats the
complete check before SourceBundle publication. Supported PNG/JPEG/PGM formats
remain unchanged. The decoder's global permissive truncation flag is never
enabled or changed; a permissive ambient decoder fails closed. Errors retain a
controlled JSON location and fixed resource code, without raw decoder text.

The generic CLI separately states geometry dependency ACCEPTED at the exact A01
commit and geometry NOT_PERFORMED_BY_SOURCE. It does not promote an offline source
package to a real coordinate check. Historical R1 strings and evidence are intact.

Run from this worktree, using the already installed environment:

```powershell
$env:PYTHONPATH='src'
python -m unittest discover -s tests -p 'test_a04_decode_r2.py' -v
python -m unittest discover -s tests -p 'test_a04_*.py' -v
python docs/evidence/A04/execution/coordinate-R2/reproduce.py --root . --output '<new offline evidence directory>'
```

The evidence runner imports only this frozen tree's synthetic fixture builders,
calls the public `python -m annotation.source.usense offline` entry, and waits for
each Python child process to exit. It never opens a browser/profile/login session
or sends requests. The input and output folders retain normal and corrupt cases,
raw stdout/stderr, pixel-decoder results, output absence on failure, portable
package checks and process release. Do not run the historical renderer or live
entries as part of this R2 task.

`before-truncated-png` retains the original 24-byte defect at the frozen base.
`after-truncated-png` runs the same independent reproduction script after repair.
The file is rejected before the CLI creates its output directory. The dedicated
matrix also includes valid PNG structure/CRCs with broken IDAT pixels, a truncated
JPEG with a real frame header, a PGM with no pixels, and normal PNG/JPEG/PGM.

The C01 contract loader intentionally remains unchanged. A separately labelled
SYNTHETIC_TEST_FORGERY demonstrates that recomputed hashes and intact headers can
still satisfy that layer. A04's full source decode rejects the forged input.
That folder is a manufactured layer-boundary counterexample, not a valid package
published by the repaired source entry. Pure hash/header checks do not establish
image decodability.

All real platform scenarios R01–R06 remain BLOCKED/NOT_RUN. No previous GET timeout
was retried. No model calls, paid usage, root dependency changes, public contract
or geometry changes, profile inspection, coordinator-state write or messages to
other chats are part of this repair. Installation remains a separate D01 matter.
The executor hands off REVIEW; independent acceptance and integration are pending.
