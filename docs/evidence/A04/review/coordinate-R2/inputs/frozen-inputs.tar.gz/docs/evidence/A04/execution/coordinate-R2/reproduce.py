"""Strictly offline R2 evidence runner; only Python CLI subprocesses are started."""
import argparse
from datetime import datetime, timezone
import hashlib
import io
import json
import os
from pathlib import Path
import shutil
import subprocess
import sys

p = argparse.ArgumentParser()
p.add_argument('--root', type=Path, required=True)
p.add_argument('--output', type=Path, required=True)
a = p.parse_args()
root, out = a.root.resolve(), a.output.resolve()
out.mkdir(parents=True, exist_ok=False)
sys.path[:0] = [str(root / 'src'), str(root / 'tests')]
from PIL import Image
from annotation.contracts import load_bundle
from annotation.source.usense import SourceParseError, parse_capture
from test_a04_decode_r2 import corrupt_png_pixels, encoded, reseal_corrupt_hash_only_package


def save(path, value):
    path.write_text(json.dumps(value, ensure_ascii=False, indent=2) + '\n', encoding='utf-8')


def decoder(path):
    result = {}
    try:
        with Image.open(path) as image:
            result.update(format=image.format, size=list(image.size))
            image.verify()
        result['structure_verification'] = 'PASSED'
    except Exception as error:
        result.update(structure_verification='REJECTED', structure_error_type=type(error).__name__)
    try:
        with Image.open(path) as image:
            for frame in range(getattr(image, 'n_frames', 1)):
                image.seek(frame); image.load()
        result['complete_decode'] = 'PASSED'
    except Exception as error:
        result.update(complete_decode='REJECTED', decode_error_type=type(error).__name__)
    return result


children, results = [], []
fixture = root / 'tests/fixtures/a04/source'
cases = [
    ('truncated-png-24', b'\x89PNG\r\n\x1a\n\x00\x00\x00\rIHDR\x00\x00\x00\x04\x00\x00\x00\x03', False),
    ('valid-header-broken-pixel-png', corrupt_png_pixels(), False),
    ('valid-header-truncated-jpeg', encoded('JPEG')[:-12], False),
    ('pgm-header-without-pixels', b'P5\n4 3\n255\n', False),
    ('normal-png', encoded('PNG'), True),
    ('normal-jpeg', encoded('JPEG'), True),
    ('normal-pgm', None, True),
]
environment = dict(os.environ, PYTHONPATH=str(root / 'src'), PYTHONIOENCODING='utf-8')
for name, blob, valid in cases:
    case = out / name; case.mkdir()
    source = case / 'input'; shutil.copytree(fixture, source)
    capture = json.loads((source / 'capture.json').read_text(encoding='utf-8'))
    path = source / capture['pages'][0]['asset_path']
    if blob is not None: path.write_bytes(blob)
    target = case / 'output'
    command = [sys.executable, '-B', '-m', 'annotation.source.usense', 'offline', '--input', str(source),
               '--output', str(target), '--as-of', capture['observed_at']]
    process = subprocess.Popen(command, cwd=case, env=environment, stdout=subprocess.PIPE,
                               stderr=subprocess.PIPE, text=True, encoding='utf-8')
    stdout, stderr = process.communicate(timeout=60)
    children.append({'case':name, 'pid':process.pid, 'returncode':process.returncode,
                     'reaped':process.poll() is not None, 'kind':'python-offline-cli'})
    (case / 'stdout.txt').write_text(stdout, encoding='utf-8')
    (case / 'stderr.txt').write_text(stderr, encoding='utf-8')
    observation = {'case':name, 'evidence_mode':'SYNTHETIC', 'expected_valid':valid,
                   'input_bytes':path.stat().st_size, 'sha256':hashlib.sha256(path.read_bytes()).hexdigest(),
                   'independent_decoder':decoder(path), 'public_cli_returncode':process.returncode,
                   'output_directory_exists':target.exists(), 'final_bundle_exists':(target / 'bundle.json').exists()}
    if valid:
        assert process.returncode == 0, observation
        bundle = load_bundle(target / 'bundle.json')
        observation['public_loader_accepted'] = True
        observation['acquired_pages'] = len(next(v for v in bundle.artifacts if v.kind == 'SourceBundle').payload.pages_acquired)
        moved = case / 'relocated full package with spaces'; shutil.copytree(target, moved)
        moved_bundle = load_bundle(moved / 'bundle.json')
        for asset in next(v for v in moved_bundle.artifacts if v.kind == 'SourceBundle').payload.assets:
            assert decoder(moved / asset.path)['complete_decode'] == 'PASSED'
            assert hashlib.sha256((moved / asset.path).read_bytes()).hexdigest() == asset.sha256
        observation['relocation_and_full_decode_passed'] = True
        entry = json.loads((target / 'evidence/entry-result.json').read_text())
        assert entry['geometry_dependency_status'] == 'ACCEPTED'
        assert entry['geometry_status'] == 'NOT_PERFORMED_BY_SOURCE'
        assert not entry['network_used'] and entry['acceptance'] == 'NOT_ASSERTED'
        assert 'WAITING_ACCEPTED_COMMIT' not in stdout
        observation['entry_status'] = entry
    else:
        assert process.returncode == 2 and not target.exists(), observation
        assert 'RESOURCE_INVALID; LOCATION=$.pages[0].asset_path' in stdout
        observation['public_loader_accepted'] = False
    save(case / 'result.json', observation); results.append(observation)

# Deliberately manufactured, explicitly labelled test forgery. Unchanged C01
# proves its hash/header layer only. It must not be treated as A04 source output.
forgery = out / 'synthetic-hash-only-forgery'
shutil.copytree(out / 'normal-png/output', forgery)
forged = reseal_corrupt_hash_only_package(forgery, corrupt_png_pixels())
capture = json.loads((forgery / 'capture.json').read_text())
source_error = None
try:
    parse_capture(capture, forgery, now=capture['observed_at'])
except SourceParseError as error:
    source_error = {'code':error.code, 'path':error.path}
assert source_error and source_error['code'] == 'RESOURCE_INVALID'
save(forgery / 'LAYER-BOUNDARY.json', {'evidence_mode':'SYNTHETIC_TEST_FORGERY',
     'a04_source_output':False, 'hash_header_loader_accepts_resealed_test_input':True,
     'full_source_decoder_rejects':source_error, 'public_contracts_modified':False})

save(out / 'result.json', {'at':datetime.now(timezone.utc).isoformat(),
     'implementation_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
     'mode':'STRICTLY_OFFLINE_SYNTHETIC','cases':results,'all_expectations_met':True,
     'real_scenarios':{f'R{i:02d}':'BLOCKED_NOT_RUN' for i in range(1,7)}})
save(out / 'release.json', {'at':datetime.now(timezone.utc).isoformat(),'runner_pid':os.getpid(),
     'children':children,'all_recorded_children_reaped':all(c['reaped'] for c in children),
     'browser_started':False,'platform_or_network_used':False,'authorized_profile_opened':False,
     'authorized_profile_inspected':False,'authorized_credentials_read':False,'profile_lease_acquired':False,
     'actual_profile_current_state':'NOT_INSPECTED_PER_OFFLINE_SCOPE','model_calls':0})
print(json.dumps({'cases':len(results),'all_expectations_met':True,
                  'all_recorded_children_reaped':all(c['reaped'] for c in children)}))
