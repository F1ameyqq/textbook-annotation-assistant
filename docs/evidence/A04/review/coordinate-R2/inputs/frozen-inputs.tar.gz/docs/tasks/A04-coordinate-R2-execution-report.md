# A04 coordinate-R2 离线返修交付

2026-10-17（Asia/Shanghai）。状态：**REVIEW，等待独立复验**。本轮只修复原图完整解码拒绝和局部 CLI 过期状态；真实平台 R01～R06 仍 **BLOCKED / NOT_RUN**，不接受整个 A04、不释放下游。

## 版本、范围与边界

| 项目 | 确切值 |
|---|---|
| base | `a86eca6ec87ced20dc3a8bcc8f2c87d329e87c39` |
| workflow | `e1b1475597f80d46c5ace5c004f5091d139ac6cc`，从 Git 对象读取 AGENTS、调度、R2任务及R1复验报告 |
| 实现冻结提交 | `45150b57f5ae6cc8f4c55ffc6f7e417a0957f32e` |
| A01依赖 | 保持 `c6bebdf43eb93f7a6ae21e96ec07ed155686777d`，未再合并主目录 |
| 合同 / geometry | 保持 C01 `1.0.0-a-proposal`、A01 `a01-geometry-1` / `a01-geometry-1-r1` |
| 分支 / 工作目录 | `codex/a04-headless-readonly` / `C:\Users\ASUS\.codex\worktrees\a04-headless-readonly\1800` |
| 执行范围 | xhigh，有界离线修复；未派发其他子代理或消息 |

本报告及证据另行归档；最终冻结交付 HEAD 在交付消息中给出，可由 `git rev-parse HEAD` 核对。产品只改 `source/usense/parser.py`、`source/usense/cli.py`；测试仅 A04 专属路径，新证据仅 `execution/coordinate-R2/`。没有修改根依赖、公共合同、source/static、geometry、调度state或其他任务，没有推送/主线集成。

旧执行清单81项及 coordinate-R1 清单67项共 **148项摘要全部保持**，旧报告和失败不改。见 [保存检查](../evidence/A04/execution/coordinate-R2/checks/preservation.json)；输入版本、复验脚本摘要和环境见 [起点记录](../evidence/A04/execution/coordinate-R2/start-provenance.json)。

## 修复与实际效果

原 `_image_inventory` 只解析PNG/JPEG/PGM头部。修复后，在同一原始字节快照上先核对支持格式、真实解码尺寸与头部绑定，再 `verify()`，重开并 `load()` 完整像素；多帧逐帧读取。SHA256继续绑定原字节，不改图像、路径或身份。`parse_capture` 和 `build_source` 发布前复查都消费这一入口。

结构校验与像素解码分开执行：**有效IHDR、完整块结构及CRC但IDAT像素流损坏的PNG，单独 `verify()` 可通过，完整 `load()` 拒绝**。JPEG截断及PGM缺像素同样拒绝。未启用或修改 Pillow 的全局截断容忍参数；若环境已启用容忍，来源入口拒绝声称完成严格解码。

失败使用固定 `RESOURCE_INVALID` 和受控 JSON 定位，例如 `$.pages[0].asset_path`，公开CLI也保留该定位，不输出解码器原始异常或本机输入路径。离线CLI先完成输入校验才创建输出目录，因此坏图不发布 SourceBundle/PlatformSnapshot 或有效最终包；发布前文件损坏也在写来源历史前拒绝。

通用CLI的新状态明确分开：

```text
geometry_dependency_status = ACCEPTED
geometry_dependency_commit = c6bebdf43eb93f7a6ae21e96ec07ed155686777d
geometry_status = NOT_PERFORMED_BY_SOURCE
acceptance = NOT_ASSERTED
```

stdout 为 `GEOMETRY_DEPENDENCY_ACCEPTED; GEOMETRY_NOT_PERFORMED; ACCEPTANCE_NOT_ASSERTED`。只消除局部CLI的过期等待声明，没有把离线包升级为坐标PASS；旧归档中的等待字符串保留作历史。

## 复现、失败与测试结果

环境：既有 Python 3.9.13、Pillow 11.3.0、Pydantic 2.12.5。未安装软件或修改根依赖；D01清洁安装未测。以下命令从本工作树运行，所有输出须使用新目录。

```powershell
$env:PYTHONPATH='src'
python -m unittest discover -s tests -p 'test_a04_decode_r2.py' -v
python -m unittest discover -s tests -p 'test_a04_*.py' -v
python -m unittest discover -s tests -p 'test_contracts*.py' -v
python -m unittest discover -s tools -p 'test_usense_login.py' -v
python -B docs/evidence/A04/execution/coordinate-R2/scripts/repro_truncated_original.py --root . --output '<新的反例结果目录>'
python -B docs/evidence/A04/execution/coordinate-R2/reproduce.py --root . --output '<新的离线矩阵目录>'
```

独立反例脚本逐字节保留，没有改写其判定：脚本退出1表示缺陷存在，退出0表示未重现缺陷；内部产品CLI的正确拒绝码为2。

| 原24字节PNG，SHA256 `501c8a30dc5edc616c56ac49f6c38180b2ea7335fe42c57350484ae5356def29` | 冻结基线 | 修复后冻结实现 |
|---|---|---|
| 完整解码 | 拒绝 | 拒绝 |
| 公开CLI退出码 | **0，错误接受** | **2，RESOURCE_INVALID + 字段定位** |
| 最终包 / 公共loader | 生成并接受，取得页数3 | 输出目录/包均不存在，未进入loader |

完整前后证据分别为 [基线失败](../evidence/A04/execution/coordinate-R2/before-truncated-png/result.json) 和 [冻结实现重放](../evidence/A04/execution/coordinate-R2/frozen-original-repro/result.json)。中间修复验证也保留于 `after-truncated-png/`。

| 验证 | 结果 |
|---|---|
| A04离线回归（原141项 + 新增11项） | **152/152** |
| 公共合同回归 | **70/70** |
| 登录工具离线回归 | **8/8**；仅合成输入/mock，无实际配置/profile访问 |
| 冻结实现公开CLI矩阵 | **7/7符合预期**：24字节PNG、结构合法但坏像素PNG、有效头部截断JPEG、PGM无像素均拒绝且无输出；正常PNG/JPEG/PGM均完整解码、loader及含空格目录搬运通过 |
| 发布前再校验 | parse后损坏原图，build_source拒绝且不写来源历史 |
| 状态与脱敏 | 依赖ACCEPTED、坐标未执行、acceptance未声明；资源错误不含原始异常或本机路径 |

见 [测试摘要](../evidence/A04/execution/coordinate-R2/checks/tests.json) 及 [公开矩阵](../evidence/A04/execution/coordinate-R2/frozen-matrix/result.json)，矩阵逐例保留实际输入、stdout/stderr、结果及正常便携包。

原有正向JPEG测试此前使用只有frame header的合成文件；完整解码要求下改为真正编码的同尺寸合成JPEG，原PNG/尺寸断言保留。新增的首次CRC测试误改IEND末尾CRC，Pillow不拒绝该终止CRC；随后只修正测试，让其损坏IDAT的CRC，确认结构校验层拒绝。坏像素流测试始终独立通过，没有放宽解码容忍。该测试编写失败与更正见 [记录](../evidence/A04/execution/coordinate-R2/checks/test-correction.json)。

## 哈希层与完整解码层的区别

C01公共loader保持原字节。测试专门构造并重封摘要的 `SYNTHETIC_TEST_FORGERY`，证明纯哈希/头部层仍可接受该人为反例，而A04来源入口完整解码拒绝。见 [层级边界证据](../evidence/A04/execution/coordinate-R2/frozen-matrix/synthetic-hash-only-forgery/LAYER-BOUNDARY.json)。这个文件夹是人为制造的反例，**不是修复后A04发布的有效来源包**；不把loader的哈希通过宣称为像素可用，也不扩大本轮去修改公共合同。

## 离线边界、自有释放及限制

本轮未开启平台、浏览器或profile，未读取授权凭据、检查授权profile/锁或重试GET，没有网络或模型调用。公开矩阵只启动7个Python离线CLI子进程，全部等待并回收；矩阵runner和这7个自有PID在结束后再次查询均已退出，见 [自有释放复查](../evidence/A04/execution/coordinate-R2/checks/final-release.json) 和 [子进程记录](../evidence/A04/execution/coordinate-R2/frozen-matrix/release.json)。原始反例脚本及测试命令也均已结束，没有后台服务。

这证明本轮自有离线进程释放；**未检查授权profile当前状态，也不将历史释放当作现在空闲**。真实R01～R06仍BLOCKED，来源完整性S01、D01安装、B确认、保存/OCR/恢复、内容质量及真实坐标不因本次修复而通过。模型调用0、付费花费0。

交付仅进入REVIEW，由主调度续派原独立验收；未向B或验收者发消息。完整摘要、脚本、必要忽略日志清单及冻结版本见 [证据清单](../evidence/A04/execution/coordinate-R2/sha256-manifest.json)。
