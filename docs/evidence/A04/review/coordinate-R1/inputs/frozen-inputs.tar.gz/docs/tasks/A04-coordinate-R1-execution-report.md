# A04 coordinate-R1 执行交付

2026-10-17（Asia/Shanghai）。状态：**REVIEW；实现及离线坐标验证已交付，真实平台坐标必需项尚未完成**。当前有界目录/来源 GET 持续超时，根因未确定。不能据此接受整个 A04。

## 确切版本与改动范围

| 项目 | 版本 |
|---|---|
| 原 A04 冻结 HEAD / 本轮 base | `3e4dba5676c2dc4a71d7826827a76df11017a68b` |
| 本轮 workflow | `f15f7bc03fac8994ade1642fa7547cbd823c6d43`，从 Git 对象读取 AGENTS、调度及续派/原任务/验收文件 |
| 主调度指定的真实 A01 集成依赖 | `c6bebdf43eb93f7a6ae21e96ec07ed155686777d` |
| A04 分支内的依赖合并 | `3d4d10a0e12faa1af8d47e9f180d086ce401509c`，父提交为原 A04 HEAD 和确切依赖；无冲突 |
| 本轮实现冻结提交 | `66aa1a3754f31a831b38ca9894bd1c203498985d` |
| 合同 / 几何 | C01 `1.0.0-a-proposal`；A01 `a01-geometry-1` / `a01-geometry-1-r1` |
| 分支 / 工作树 | `codex/a04-headless-readonly` / `C:\Users\ASUS\.codex\worktrees\a04-headless-readonly\1800` |

本报告和证据在实现提交之后单独归档，最终冻结 HEAD 由交付消息及 `git rev-parse HEAD` 给出。没有主线集成、推送或更改主调度 state，没有联系 B。后续子代理未派发；本任务按正式续派的 xhigh 约定执行。

本轮自己的源码仅改 `source/usense`、`delivery/usense_readonly`、`runtime/browser`；专属测试/夹具与证据只在 A04 范围。公共 geometry、contracts、根依赖、父入口均与指定依赖一致。依赖合并带入的公共变更属于指定 A01 提交，本执行者未改写。原 [A04 部分交付报告](A04-execution-report.md) 及其清单中的 **81 个文件摘要全部未变**，见 [保存检查](../evidence/A04/execution/coordinate-R1/checks/preservation.json)。

合入前后提交/树、实际导入绝对路径、workflow 文档摘要和只读调度观察见 [起点证明](../evidence/A04/execution/coordinate-R1/start-provenance.json)。实际导入来自本工作树 `src/annotation/geometry`、`contracts`、`source/usense` 和 `delivery/usense_readonly`，公共 geometry Git blob 与依赖精确一致。

## 实现与独立检查方法

新增公开 API：`annotation.delivery.usense_readonly.ViewerMapping`、`binding_from_file`、`check_reference_points`；真实入口为 `python -m annotation.source.usense.coordinate_run`。

Usense 直接绘制原始栅格，故 A01 `Transform` 在原图域采用正确的恒等图像变换：整图、scale=1、整数零 padding、零旋转；绑定检查和正反原图域检查实际调用 A01 API。原图没有变成新的处理图，不能为凑非平凡 Transform 虚造 raster 或把小数 CSS 偏移塞入 padding。

平台层另记录实际 native `drawImage` 的源/目标矩形、图像自然尺寸、Canvas CTM、backing 尺寸、CSS rect、viewport、DPR、页面/面板滚动、推导 zoom、backing 平移和页面资源身份。绘制拦截只记录受控数字，不改变绘制调用、不画标记；响应 URL 不写入证据。

参考图块先在原图单独选定，绑定摘要和尺寸。匹配器在保留的**整张 canvas 像素**和**整张面板截图像素**中分别搜索，不以待测映射预测的平移缩窄搜索。截图参考点由面板 clip 转为 CSS 点，和 canvas 点独立比较；再从实测 CSS 点逆投原图。允许误差是 canvas/CSS 2.5 像素、原图 8 像素，不用于扩大公共 A01 的合法坐标域。错误 scale、canvas 平移、CSS origin 即使自身正反相消，也必须被参考点检查拒绝。

正文14、答案173各有3个参考点；错页、摘要、尺寸、asset 身份、非法裁片/旋转/非有限状态和错误映射反例均有离线拒绝测试。DPR 不被假设为 backing/CSS 比例。缩放和平移手势使用 wheel 和中键拖动，仅更改查看器展示；**本轮真实手势与当前原图落点因前置 GET 超时尚未运行到**。

## 复现与已运行结果

环境为本机既有 Windows / Python 3.9.13 / Playwright 1.58.0 / Pillow 11.3.0 / Pydantic 2.12.5 / headless Edge。依赖安装没有重做，清洁安装 **NOT_TESTED，归 D01**；没有新增根依赖。

```powershell
$env:PYTHONPATH='src'
python -m unittest discover -s tests -p 'test_a04_*.py' -v
python -m unittest discover -s tests -p 'test_a01_geometry.py' -v
python -m unittest discover -s tests -p 'test_contracts*.py' -v
python -m unittest discover -s tools -p 'test_usense_login.py' -v
python docs/evidence/A04/execution/coordinate-R1/run-local-renderer.py --output '<新的本地输出目录>'
```

| 层级 | 本轮结果 |
|---|---|
| A04 原测试与本轮增量 | **141/141** |
| 接受版本 A01 geometry | **8/8** |
| 合同回归 | **70/70** |
| 登录工具回归 | **8/8** |
| 冻结实现上的本地 DPR=2 renderer | 正文/答案各3点通过；含非平凡 draw scale、CTM 小数平移、非整数 CSS 尺寸；每页3种错误映射均拒绝 |
| 原 A04 报告/证据保存 | 81项摘要一致 |

测试摘要及完整命令输出见 [checks](../evidence/A04/execution/coordinate-R1/checks/tests.json)。原131项测试继续保留合法输入、便携包、错书、缺页/坏资源/引用、过期、登录/超时、锁冲突、请求阻断及异常释放检查；新增10项检查坐标与续派入口。

冻结实现上的 [本地 renderer 证据](../evidence/A04/execution/coordinate-R1/frozen-local-renderer-dpr2/MODE.json) 使用新临时、非 persistent 浏览器、DPR=2 和**历史原图像素**，所有请求在本地 fulfill 或 abort，真实网络发送0，不读授权配置/profile。正文三个点最大 CSS 误差约 **0.656px**，答案约 **0.502px**，且本地上下文/浏览器关闭。原图、测量 canvas、独立面板截图、原始观察参数、参考点误差和错误反例都在该包中。它证明离线 renderer/像素定位链路，不是当前 Usense 或真实平台多 DPR 验收。

## 真实平台尝试、失败与释放

真实复现命令（仅在主调度预留后、新查占用；输出必须不存在）：

```powershell
$env:PYTHONPATH='src'
python -m annotation.source.usense.coordinate_run --login-root D:\1800 --coordination-state D:\1800\docs\coordination-state.json --references tests/fixtures/a04/coordinate-r1/reference-patches.json --output '<新的真实输出目录>' --ignore-https-errors
```

仍仅限书46007447页14/15/173的 GET/导航及原有必要登录例外。配置只经既有 helper 内部读取，profile 不复制，凭据/token/header/请求体/敏感URL不输出。诊断中的既有会话 token 仅在内部用于同白名单 GET，不落日志或产物。证书参数仍显式、单次 context 使用，默认校验及全局设置均未改变。

| 本次尝试 | 实际结果 | 结束与释放（北京时间） |
|---|---|---|
| live-01 | 登录状态 REUSED；读当前状态阶段 TIMEOUT / fetch，未采原图 | 12:54:46，context关闭，profile进程/锁/lease均0 |
| live-02 | 相同阶段 TIMEOUT，未采原图 | 12:56:07，同上 |
| live-03 | 相同阶段 TIMEOUT；传输失败只记固定类别 | 12:57:47，同上 |
| transport-diagnostic-01 | 不选书，分别读取 DIRECTORY / SOURCE_INDEX；二者仍 TIMEOUT | 新释放记录正常 |
| transport-diagnostic-02 | 显式受相同策略控制的 APIRequestContext GET，禁重定向/重试，各10秒；二者均 TimeoutError | 13:02:04，context关闭，profile进程/锁/lease均0 |

见 [最终诊断](../evidence/A04/execution/coordinate-R1/transport-diagnostic-02/diagnostic.json)、[最终真实会话释放](../evidence/A04/execution/coordinate-R1/transport-diagnostic-02/session-release.json)、[网络审计](../evidence/A04/execution/coordinate-R1/transport-diagnostic-02/network-audit.json)。所有真实会话均先做新的实际进程/Chromium锁检查及原子 lease；没有抢锁、删除他人锁或关闭日常浏览器。全部新会话结束后另做 [当前只读释放复查](../evidence/A04/execution/coordinate-R1/checks/final-profile-release-check.json)，没有重新启动浏览器。

这些失败均在来源/坐标采集之前，没有发布 complete=true capture 或新 SourceBundle/PlatformSnapshot，**当前目录/题/框数量、原图、翻页和真实坐标均未知**。旧22题68框、121目录、214页元数据和旧页图仍是历史值，本轮没有将其写成本次事实。没有画框、编辑、OCR、保存、删除、送审/送交或重放题22；未向真实平台注入失败写请求。本轮实际没有触发 LOCAL_EMPTY_BOOTSTRAP；实现保留原有限定，本地空占位不能进入来源证据。

## 28场景与剩余条件

原验收准备的28个场景没有被单个坐标例替代。执行者的分层对应见 [28场景证据映射](../evidence/A04/execution/coordinate-R1/checks/scenario-map.json)，这是自测证据索引，独立验收仍由原验收对话执行。

- P01、O01～O03、F01～F17 有当前代码上的离线/替身测试证据；网络阻断使用本地请求替身，未把它宣称为真实平台接收计数。
- R01 仅确认本次独立无头受保护界面及会话复用；当前完整目标状态未取得。
- R02～R05 的本轮真实原图、翻页、当前快照、实际平台缩放/平移及独立坐标落点 **未完成**，阻断于上述 GET 超时。DPR=2 仅完成离线 renderer；真实多 DPR未测。
- R06 有上述全部新会话的真实关闭/释放证据；D01 场景编号是交付证据项，与另派的安装任务 D01 区别，均不构成安装验收。

恢复条件：当前授权 GET 可完成后，在同一冻结实现或明确后续修订上重新核对预留/实际占用，完整运行页14/15/173、14→15→14、正文/答案 baseline 与 zoom-pan、当前快照/前后一致性及新释放，再交原独立验收。现阶段 A04 全部必需项未齐，不应 ACCEPTED、集成或释放下游。

S01独立内容分母、D01清洁安装、B合同确认、写入/恢复、OCR及内容质量均保持未解决；能力保持 C01 UNKNOWN。模型调用0、付费花费0。完整文件摘要及必要忽略日志见 [清单](../evidence/A04/execution/coordinate-R1/sha256-manifest.json)。
