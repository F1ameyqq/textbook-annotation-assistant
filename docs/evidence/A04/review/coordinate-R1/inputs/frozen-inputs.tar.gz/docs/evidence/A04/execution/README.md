# A04 bounded read-only adapter

This is an A-side implementation delivery, pending independent review and the
accepted A01 geometry commit. It does not establish B acceptance, write/OCR
capability, content correctness or complete-book source acquisition.

From the A04 worktree in PowerShell:

```powershell
$env:PYTHONPATH='src'
python -m unittest discover -s tests -p 'test_a04_*.py' -v
python -m annotation.source.usense offline --input tests/fixtures/a04/source --output docs/evidence/A04/execution/new-synthetic-package --as-of 2026-10-16T13:00:00+00:00
```

The fixture and its pixels are explicitly SYNTHETIC. Outputs are new directories
and immutable C01 exchange files, with portable relative assets. Copy the entire
output directory, then call `annotation.contracts.load_bundle(<new-root>/bundle.json)`.
An old OBSERVED input requires explicit `--as-of`; offline replay retains its
original observation time and changes provenance to HISTORICAL, never LIVE.

Authorized live reproduction (only after coordinator reservation and actual
profile exclusivity; output must not already exist):

```powershell
$env:PYTHONPATH='src'
python -m annotation.source.usense live --login-root D:\1800 --coordination-state D:\1800\docs\coordination-state.json --output docs/evidence/A04/execution/new-live-package --ignore-https-errors
```

The explicit TLS flag is the existing per-run authorization. Omitting it retains
certificate validation. The existing authorized helper reads credentials internally
and reuses its original dedicated profile; credentials/profile are not copied.
The CLI accepts the coordinator's A04 execution or review reservation. Review must
wait for executor release and recheck actual processes and locks.

Only book46007447 and viewer pages14,15,173 are acquired. Navigation uses the page
inputs and returns the body pane14→15→14. Protected viewer, actual page props,
browser image timing, painted canvas and clipped pane screenshots support loading.
These observations do not implement or verify original-to-viewer geometry.

Platform initialization requests page1 before assigning its page count. Exactly
two fixed target/page1 GETs can receive **local empty bootstrap placeholders**
after authentication. They are audited BLOCK/LOCAL_EMPTY_BOOTSTRAP and are never
sent to the server. Their `pages` arrays are empty; they supply no image or frame
evidence and do not enter SourceBundle. All three retained originals come from
real bounded GETs. Other out-of-scope requests abort.

HTTP requests use a strict target/path/query whitelist. Browser requests fetch one
hop with redirects/retries disabled, then fulfill only nonredirect responses.
WebSockets close before any connection, service workers are blocked, and direct
image requests separately use the same whitelist with no redirect/retry. Necessary
login POST has one explicit slot; no password/token/header/body/URL is audited.
Audit fields are method, controlled category, decision, status and timestamp.
Unknown mutation, save, OCR, delete, review and delivery paths are not allowed,
including mutation-looking GETs. Live runs do not inject forbidden requests.

`SourceBundle` includes the three acquired originals, image identities, separate
viewer/source indices, directory metadata and explicitly bounded completeness.
`PlatformSnapshot` includes all directory/question references but only frames on
the acquired originals. All full-state frame records remain in redacted history
and contribute to the observation hash; omitted frames are counted separately.
Unmeasured capabilities remain C01 UNKNOWN (task wording UNVERIFIED). The required
exchange policy is the existing A_INTERNAL_PROPOSAL, without joint confirmation.

Public APIs:

```python
from annotation.source.usense import parse_capture, build_source, source_evidence
from annotation.delivery.usense_readonly import build_snapshot, snapshot_evidence
from annotation.source.usense.cli import build_exchange
```

The parser accepts this task's raw-response capture schema; the CLI republishes
only its validated scalar fields and raw annotation keys. This is not a general
normalized-annotation migration utility. Asset bytes and hashes are verified at
parse/build and by C01 `load_bundle`. Failed runs preserve failure/audit/release
records and available incomplete data. Only successful owned-resource release
permits publishing `capture.json` with complete=true.

`live-probe-01` and `live-run-02` through `07` preserve development failures. They
are not successful platform evidence. `live-run-08` records the first successful
bounded capture. The final execution report identifies the frozen-code run and
exact version; geometry remains pending until A01 is explicitly released.
