"""Offline renderer surrogate; all URL requests fulfilled locally, never forwarded."""
import argparse
import json
from pathlib import Path

from playwright.sync_api import sync_playwright
from annotation.source.usense.viewer_observation import DRAW_OBSERVER
from annotation.source.usense.coordinate_probe import check_case

root=next(p for p in Path(__file__).resolve().parents if (p/'AGENTS.md').is_file())
p=argparse.ArgumentParser();p.add_argument('--output',type=Path,required=True);args=p.parse_args()
out=args.output
(out/'assets').mkdir(parents=True,exist_ok=False)
refs=json.loads((root/'tests/fixtures/a04/coordinate-r1/reference-patches.json').read_text())
for page in (14,173):
    (out/f'assets/page-{page}.jpg').write_bytes((root/f'docs/evidence/A04/execution/live-run-09/assets/page-{page}.jpg').read_bytes())
closed=False;network_forwarded=0
try:
    with sync_playwright() as pw:
        browser=pw.chromium.launch(channel='msedge',headless=True)
        context=browser.new_context(viewport={'width':1440,'height':1000},device_scale_factor=2,service_workers='block')
        def route(r):
            name=r.request.url.rsplit('/',1)[-1]
            if name=='46007447_page_13.jpg':body=(out/'assets/page-14.jpg').read_bytes()
            elif name=='46007447_page_172.jpg':body=(out/'assets/page-173.jpg').read_bytes()
            else:r.abort();return
            r.fulfill(status=200,content_type='image/jpeg',headers={'access-control-allow-origin':'*'},body=body)
        try:
            context.route('**/*',route)
            page=context.new_page()
            page.set_content('<div class="pdf-zone" style="width:520px;height:880px"><canvas width="500" height="846" style="width:499.5px;height:845.25px"></canvas></div><div class="pdf-zone" style="width:520px;height:880px;position:absolute;left:550px;top:8px"><canvas width="500" height="846" style="width:499.5px;height:845.25px"></canvas></div>')
            page.evaluate(DRAW_OBSERVER)
            for page_number,zone,index in [(14,0,13),(173,1,172)]:
                page.evaluate('''async ([zone,index])=>{
                  const image=new Image();image.crossOrigin='anonymous';
                  image.src='https://oss-ef-bd-2026-gz.oss-cn-guangzhou.aliyuncs.com/upload_images/46007447/46007447_page_'+index+'.jpg';
                  await image.decode();const ctx=document.querySelectorAll('canvas')[zone].getContext('2d');
                  ctx.translate(13.25,19.5);ctx.drawImage(image,15.5,22.25,430,700);
                }''',[zone,index])
                report=check_case(page,out,page_number,zone,index,refs,'local-dpr2',renderer_mode='LOCAL_SYNTHETIC_RENDERER')
                print(page_number,len(report['checks']),max(r['css_error'] for r in report['checks']),flush=True)
        finally:
            context.close();browser.close();closed=True
finally:
    (out/'MODE.json').write_text(json.dumps({'mode':'LOCAL_SYNTHETIC_RENDERER_WITH_HISTORICAL_ORIGINAL_PIXELS',
      'platform_observation':False,'dpr':2,'real_network_requests':network_forwarded,
      'profile':'temporary nonpersistent; no authorized credentials or profile read','closed':closed},indent=2)+'\n',encoding='utf-8')
