# A04 coordinate-R1

The exact accepted dependency `c6bebdf43eb93f7a6ae21e96ec07ed155686777d`
was merged into the original A04 branch, without public conflicts. The dependency
merge is `3d4d10a0e12faa1af8d47e9f180d086ce401509c`; workflow instructions were
read from `f15f7bc03fac8994ade1642fa7547cbd823c6d43`. See `start-provenance.json`.

`annotation.delivery.usense_readonly.ViewerMapping` consumes the accepted A01
`Transform` and `ImageBinding`. The platform draws the unchanged original raster,
so the original-image transform correctly has identity scale, integer zero padding
and no crop/rotation. A01 performs binding/domain validation in both directions.
Fractional draw destinations, Canvas CTM translation, letterboxing, CSS rectangles
and backing/CSS ratios remain platform presentation state, never A01 padding or
fractional raster dimensions. DPR is separately observed, not assumed to equal the
backing/CSS ratio.

The render observer records the actual native `drawImage` call, its natural
image size, source/destination rectangle and CTM. It does not modify the call or
draw any marker. Source bindings are checked against decoded original bytes and
preselected original-only patch references. Each patch is independently searched
across the whole retained canvas and whole pane screenshot. No mapper-predicted
translation narrows either search. Independently located screenshot pixels become
viewport CSS points using the pane clip. Forward and inverse errors are checked;
wrong scale, canvas offset and CSS origin must fail even when their own roundtrip
is self-consistent. This pixel localization is a coordinate test, not OCR or a
content-quality assertion.

All commands run from this worktree with the existing environment:

```powershell
$env:PYTHONPATH='src'
python -m unittest discover -s tests -p 'test_a04_*.py' -v
python -m unittest discover -s tests -p 'test_a01_geometry.py' -v
python -m unittest discover -s tests -p 'test_contracts*.py' -v
python -m unittest discover -s tools -p 'test_usense_login.py' -v
python docs/evidence/A04/execution/coordinate-R1/run-local-renderer.py --output '<new local output directory>'
```

The local renderer command uses a new temporary, nonpersistent headless browser,
DPR=2 and historical original pixels. All requests are fulfilled locally or
aborted; it never reads the authorized profile or credentials. Its output is
explicitly **LOCAL_SYNTHETIC_RENDERER**, not a current platform observation.
`local-renderer-dpr2-03` is the final such run; `-02` is an earlier successful
diagnostic whose enclosing MODE.json supplies that same limitation. The first
local renderer attempt failed on an about:blank URL-base issue; retained as a
failure and corrected in the observer.

Authorized real reproduction, only under the coordinator's fresh reservation:

```powershell
$env:PYTHONPATH='src'
python -m annotation.source.usense.coordinate_run --login-root D:\1800 --coordination-state D:\1800\docs\coordination-state.json --references tests/fixtures/a04/coordinate-r1/reference-patches.json --output '<new real output directory>' --ignore-https-errors
```

This entry restricts book46007447 to acquired pages14/15/173 and checks the exact
dependency and coordinate-R1 reservation. It uses the original login helper,
actual process/lock/lease preflight, same read-only network guard and normal/failure
cleanup. The explicit TLS flag retains the previously authorized per-run scope.
Reference pages14/173 get baseline and wheel-zoom/middle-button-pan checks; these
gestures change presentation only. Page15 and return14 remain in the original
navigation sequence. Local empty page1 bootstrap remains clearly audited and
cannot become source-image evidence. Complete captures publish only after release.

**Current live limitation:** three bounded attempts reused authenticated sessions
but timed out reading current directory/source state before original-image or
coordinate capture. Separate bounded diagnostics reproduced the same failure
without book-selection requests and with explicit same-policy APIRequestContext
GETs. These failed runs are not platform coordinate evidence. Their new release
records show context closed and profile processes/locks/lease all zero. The final
report names the remaining real-platform checks, with no promotion of historical
22/68/121/214 counts, source completeness, D01 installation or capabilities.

The original A04 evidence/report are retained unchanged. Installation uses the
already recorded Pillow/Playwright environment; clean installation belongs to D01.
The delivery remains REVIEW and requires independent review plus successful real
coordinate verification before any A04 acceptance or integration decision.
