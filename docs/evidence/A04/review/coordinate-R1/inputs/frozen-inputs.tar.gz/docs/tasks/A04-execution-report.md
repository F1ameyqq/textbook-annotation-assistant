# A04 执行交付：离线与真实只读阶段

2026-10-16（Asia/Shanghai）。状态：**REVIEW，阶段性交付；正式坐标联调待 A01 接受提交**。
本报告是执行者的实现和复现记录，不是独立验收 ACCEPTED，也不释放下游。

## 版本与范围

| 项目 | 精确值 |
|---|---|
| base_commit / workflow_commit | `39341c98d73c354d639f3beeb55429f55d0e9be5` |
| 代码提交 / 冻结代码版本 | `d28a58f1859d00c70fc86aeecbb11ec2e7f06f89` |
| 分支 | `codex/a04-headless-readonly` |
| 工作目录 | `C:\Users\ASUS\.codex\worktrees\a04-headless-readonly\1800` |
| 公共合同 | C01 `1.0.0-a-proposal`，消费派发基线已集成实现 |
| geometry 接受提交 | **未取得、未消费**；最新主调度仍为 `WAITING_ACCEPTED_COMMIT` |
| 线上范围 | 仅书 `46007447`，查看器 14、15、173 页；正文 14→15→14 |
| 模型调用 / 花费 | 0 / 0；未测模型识别质量、成本 |
| 推送 / 集成 / B 接受 | 均未进行或未宣称 |

本报告及归档证据在上述代码提交之后单独提交；最终交付 HEAD 由本对话的交付消息给出，可用 `git rev-parse HEAD` 核对。实现文件在代码提交后未改动。源码、测试和证据摘要见 [执行目录](../evidence/A04/execution/README.md)。

唯一改动为 `source/usense`、`delivery/usense_readonly`、`runtime/browser` 和 A04 专属测试/样例/执行证据/本报告。未改公共合同、geometry、根依赖、父入口、旧工具、B 模块或主目录；主目录调度状态只读。

## 实现与复现

- `parse_capture / build_source / source_evidence`：脱敏响应、目录/题/框全量引用校验、过期/不完整响应分类、真实资产字节摘要和尺寸、相对路径及来源证据。
- `build_snapshot / snapshot_evidence`：完整目录和题节点、范围内原图绑定框；全量帧状态参与摘要，未采原图的框单列省略数量。不会裁边或修正历史框。
- `HeadlessSession / ProfileLease / RequestPolicy`：独立无头会话、真实进程与 Chromium 锁检查、原子自有 lease、单次登录、失败释放、方法/目标/路径/查询白名单、单跳 HTTP 和 WebSocket 阻断。
- 公开入口 `python -m annotation.source.usense`：新目录输出、不覆盖旧包、C01 公共 API 校验和便携包；没有写入/OCR/保存入口。

环境：Windows、Python 3.9.13、Playwright 1.58.0、Pillow 11.3.0、Pydantic 2.12.5、专用 headless Edge，viewport 1440×1000。未修改根依赖；使用本机既有工具和运行库。

```powershell
$env:PYTHONPATH='src'
python -m unittest discover -s tests -p 'test_a04_*.py' -v
python -m unittest discover -s tests -p 'test_contracts*.py' -v
python -m unittest discover -s tools -p 'test_usense_login.py' -v
python -m annotation.source.usense offline --input tests/fixtures/a04/source --output docs/evidence/A04/execution/new-synthetic-package --as-of 2026-10-16T13:00:00+00:00
```

真实复现命令（输出须为新目录；验收会话须由主调度预留，并重新检查实际占用）：

```powershell
$env:PYTHONPATH='src'
python -m annotation.source.usense live --login-root D:\1800 --coordination-state D:\1800\docs\coordination-state.json --output docs/evidence/A04/execution/new-live-package --ignore-https-errors
```

配置由既有登录 helper 内部读取，profile 留在原授权目录；未用文件工具读取/输出凭据，不复制 profile。证书参数仅作用本次 context，默认校验不变。CLI 可消费主调度的 A04 execution 或 review 预留，不修改调度状态。

## 离线与模拟证据

| 检查 | 执行结果与证据 |
|---|---|
| A04 专属测试 | **131/131**，见 [测试摘要](../evidence/A04/execution/checks/tests.json) 和 [完整输出](../evidence/A04/execution/checks/a04.txt) |
| 既有 C01 回归 | **70/70**，见 [输出](../evidence/A04/execution/checks/c01.txt) |
| 既有登录工具回归 | **8/8**，见 [输出](../evidence/A04/execution/checks/login.txt) |
| 合成固定样例 | [offline-synthetic-01](../evidence/A04/execution/offline-synthetic-01/bundle.json)，明确 SYNTHETIC，不是平台观察 |
| 真实包搬运与历史回放 | [便携检查](../evidence/A04/execution/checks/portable-real-package.json)：整包复制到含空格目录后 `load_bundle` 成功；公开 offline 入口成功，原图摘要一致、原观察时间不变、回放身份 HISTORICAL |

故障覆盖错书、缺页、损坏/不完整/过期/未来响应、引用缺失和循环、范围外坏帧、原图损坏/变更、登录失效、超时、进程/锁/lease 冲突、重定向、WebSocket、非只读请求、关闭异常和失败后重取。网络写入阻断、登录故障和关闭故障采用离线 mock/本地 fake fetch，未向真实平台注入保存/删除/OCR 请求。真实历史 A05 样例只用于标明 HISTORICAL 的离线联调。

## 真实只读证据

冻结代码版本上的最终运行是 [live-run-09](../evidence/A04/execution/live-run-09/bundle.json)。观察时间 `2026-10-16T13:52:04.979785+00:00`（北京时间 21:52:04）；释放时间 `13:52:17.470220+00:00`（21:52:17）。

| 项目 | 本次真实结果 |
|---|---|
| 登录与目标 | 专用 headless 登录状态 **REUSED**；保护界面、目标书 ID 核对成功；本次无登录 POST |
| 当前书级状态 | 22 题、68 框、标注中；这是本次 GET，不沿用 A05 数字 |
| 来源完整性 | 元数据 **214 页**；本任务实际取得 **3 张原图**；不代表整书或全部题目内容已取得 |
| 目录/框视图 | 121 个目录节点、22 个题节点；快照含绑定三页原图的 **25 框**；43 框未有原图绑定而省略，仍保留在历史证据并进入全量摘要 |
| 原图与查看器 | 页 14、15、173 的 API 资源身份、浏览器加载 timing、非空绘制 canvas、截图均取得；正文 14→15→14 返回成功 |
| 前后状态 | 允许字段的书状态、完整目录及完整帧记录前后一致；见 [状态检查](../evidence/A04/execution/live-run-09/evidence/read-only-state.json) |
| 网络 | 70 条审计事件（请求尝试/响应均可记录，不是 70 个独立请求）；允许的非 GET 条目为 **0**；见 [只读审计](../evidence/A04/execution/live-run-09/evidence/network-audit.json) |
| 释放 | 自有 context 正常关闭；profile 后验进程/Chromium 锁/lease 均 **0**；见 [释放证明](../evidence/A04/execution/live-run-09/evidence/session-release.json) |

原图清单（本次观察到的各页映射，不外推为全局偏移）：

| 查看器页 | source_index | 实际尺寸 | 原图 SHA-256 |
|---|---|---|---|
| 14 | 13 | 1218×1694 | `4186d57ffad14f576fe7c967c96697d25c83ffe3512217c79b8371134181c1d9` |
| 15 | 14 | 1219×1703 | `7c1a4afec69a94371fa31b6111969ca3d6ec39d7d7c6b1c73764f90316a610dd` |
| 173 | 172 | 1148×1621 | `a231f0247cd0444cc34ed699c4cca99245d2ac6cfda5ef10a38ca3f8164510be` |

平台选书初始化固定先读第 1 页，直接 abort 会使页数初始化中断。因此仅两次固定目标/page1 GET 收到明确标记的**本地空占位**：不发服务器、`pages=[]`、不提供原图/框、不进入来源产物。审计为 BLOCK / LOCAL_EMPTY_BOOTSTRAP；4 条事件是两次请求和对应响应，释放报告 count=2。之后三页均真实 GET 加载，见 [翻页证明](../evidence/A04/execution/live-run-09/evidence/navigation.json)、[正文截图](../evidence/A04/execution/live-run-09/evidence/viewer-14.png)、[相邻页截图](../evidence/A04/execution/live-run-09/evidence/viewer-15.png)、[答案截图](../evidence/A04/execution/live-run-09/evidence/viewer-173.png)。截图仅 PDF 区域，无账号头部。

其它被阻断类别为 ORIGIN_BLOCKED 与 URL_BLOCKED 各一条；不记录原始敏感 URL。HTTP 重定向一律在单跳取回处阻断，WebSocket 关闭，直接图片 GET 禁止重定向/重试。未画框、编辑、删除、OCR、保存、送审/送交或重放题 22；页面上题 22 的框是已有数据的只读显示。

首个成功运行 [live-run-08](../evidence/A04/execution/live-run-08/bundle.json) 是开发验证。`live-probe-01` 与 `live-run-02`～`07` 保留真实失败：早期白名单、列表参数/别名、账户过滤及初始化页阻断问题，均未标为成功；失败会话也各自关闭释放，后续可重新获取。06/07 只取得页 14 原图，保留 complete=false 的 incomplete capture，不能消费成完整来源。

## 仍未执行及限制

1. **正式 geometry 集成未执行**：最新只读调度快照仍缺 A01 接受提交。没有复制/自建通用 geometry，没有独立参考点或原图↔查看器正反坐标验证。CSS/canvas 观察只证明当前页加载；缩放/平移与坐标精度须在已接受 A01 版本上另行联调。
2. 所有能力保持 C01 `UNKNOWN`（任务文字 UNVERIFIED）；只读采集不升级保存、OCR、批量、重启恢复或内容检查能力。包内使用既有 A 内部提案政策；A05 有界历史说明不等于本模块实测，也不等于 B 确认。
3. 源产物 scope_manifest 是目录中的稳定题节点清单，basis 明确其为元数据；不证明未取得原图的题目内容覆盖、切题或配答质量。
4. 最终内容检查、真实写入、最终提交、算法质量及费用性能均未测。未知保存恢复只保留合同语义，本只读入口不执行保存。
5. 独立验收须在本次冻结交付及释放后运行。执行者未把自报测试成功记为 ACCEPTED；是否缩小验收范围、何时释放 A01 及集成由主调度决定。

附：[最终真实摘要](../evidence/A04/execution/checks/final-live-summary.json)、[脱敏检查](../evidence/A04/execution/checks/redaction.json)、[文件摘要清单](../evidence/A04/execution/sha256-manifest.json)。
