B fixed next batch / HOLD / A extension proposal only.
B baseline5970f15; A reference e37606d.
4 cases, 1 question-answer candidate and 3 answer-evidence-only cases; no inferred question IDs.
Read docs/b-q4-q9-q16-a-extension.md first.
Replay staging with packaged tools/prepare_complex_batch_b.py --package <published Q15 revision9 ZIP> --output <new-dir>.
Source package SHA8c812330b93cc60b920f6ccd1cd7784f0afe8d293336166a586e1aeaab8231ad.
The B staging mutation checks are not an A/C01 consumer guarantee.
A07 old-approval test is a fixed authorization rejection, not positive batch simulation.
DeepSeek startup attempts failed MISSING_CREDENTIAL before model dispatch; no model result was used.
No website, OCR, positive simulation, submission, human or chapter acceptance.
