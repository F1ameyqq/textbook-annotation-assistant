"""Reproduce fail-open cases in viewer13 reviewed-layout patch v1.

Usage:
  python -X utf8 viewer13-v1-adversarial-repro.py <patched-repository-root>

The script is offline, creates only a temporary fixture directory, and exits 1
while any of the documented vulnerabilities is still accepted.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path
import sys
import tempfile


if len(sys.argv) != 2:
    raise SystemExit("usage: viewer13-v1-adversarial-repro.py <patched-repository-root>")

repo = Path(sys.argv[1]).resolve()
sys.path.insert(0, str(repo / "src"))
sys.path.insert(0, str(repo))

from annotation.recognition import offline, pipeline_quality
from annotation.recognition.baseline import digest
from tests.test_viewer13_reviewed_layout import fixture


def graph_issues(evidence, graph, units):
    found = []
    pipeline_quality._graph_sources(
        evidence, graph, units, lambda code, **kwargs: found.append(code)
    )
    return found


def quality_issues(evidence, graph, check, review):
    found = []
    pipeline_quality._quality_bindings(
        evidence, graph, check, review,
        lambda code, **kwargs: found.append(code),
    )
    return found


results = {}
with tempfile.TemporaryDirectory() as temp:
    source_path, baseline, context, review = fixture(Path(temp))
    source = json.loads(source_path.read_text(encoding="utf-8"))
    evidence = offline.refine(source_path, baseline, context)
    graph = offline.assemble(evidence)
    check = offline.quality_check(evidence, graph, review)

    source_findings = []
    units = pipeline_quality._source_evidence(
        evidence, source, context,
        lambda code, **kwargs: source_findings.append(code),
        source_path,
    )
    assert not source_findings

    forged_ids = copy.deepcopy(graph)
    material = forged_ids["payload"]["shared_materials"][0]
    material["material_id"] = "forged-material"
    task_id_map = {}
    for index, task in enumerate(material["tasks"]):
        task_id_map[task["task_id"]] = f"forged-task-{index}"
        task["task_id"] = f"forged-task-{index}"
        task["material_id"] = "forged-material"
    for row in forged_ids["payload"]["question_source_coverage"]:
        if row["owner_kind"] == "shared_material":
            row["owner_id"] = "forged-material"
        elif row["owner_kind"] == "task":
            row["owner_id"] = task_id_map[row["owner_id"]]
    forged_ids["content_hash"] = digest(forged_ids["payload"])
    forged_ids_check = offline.quality_check(evidence, forged_ids, review)
    id_graph_issues = graph_issues(evidence, forged_ids, units)
    id_quality_issues = quality_issues(
        evidence, forged_ids, forged_ids_check, review
    )
    results["forged_material_and_task_ids_accepted"] = (
        not id_graph_issues and not id_quality_issues
    )
    results["forged_id_graph_issues"] = id_graph_issues
    results["forged_id_quality_issues"] = id_quality_issues

    graph_attacks = {
        "selection_verified": lambda value: value["payload"].__setitem__(
            "selection_status", "VERIFIED"
        ),
        "platform_action": lambda value: value["payload"].__setitem__(
            "platform_actions", [{"action": "PUBLISH"}]
        ),
        "extra_question_human_flag": lambda value: value["payload"]["questions"][0][
            "flags"
        ].append("HUMAN_VERIFIED"),
        "dropped_material_figure_flag": lambda value: value["payload"][
            "shared_materials"
        ][0].__setitem__(
            "flags", ["TITLE_SEPARATOR_UNCAPTURED", "BUSINESS_REVIEW_REQUIRED"]
        ),
        "dropped_task_figure_flag": lambda value: value["payload"][
            "shared_materials"
        ][0]["tasks"][0].__setitem__("flags", ["BUSINESS_REVIEW_REQUIRED"]),
    }
    results["graph_false_claims"] = {}
    for name, mutate in graph_attacks.items():
        attacked = copy.deepcopy(graph)
        mutate(attacked)
        attacked["content_hash"] = digest(attacked["payload"])
        attacked_check = offline.quality_check(evidence, attacked, review)
        g_issues = graph_issues(evidence, attacked, units)
        q_issues = quality_issues(evidence, attacked, attacked_check, review)
        results["graph_false_claims"][name] = {
            "accepted": not g_issues and not q_issues,
            "graph_issues": g_issues,
            "quality_issues": q_issues,
        }

    check_attacks = {
        "accepted_true": ("accepted", True),
        "business_true": ("business_acceptance", True),
        "transcription_true": ("transcription_verified", True),
        "platform_action": ("platform_actions", [{"action": "PUBLISH"}]),
    }
    results["check_false_claims"] = {}
    for name, (key, value) in check_attacks.items():
        attacked = copy.deepcopy(check)
        attacked["payload"][key] = value
        attacked["content_hash"] = digest(attacked["payload"])
        found = quality_issues(evidence, graph, attacked, review)
        results["check_false_claims"][name] = {
            "accepted": not found,
            "quality_issues": found,
        }

fixture_root = repo / "tests" / "fixtures" / "book46007447"
legacy_evidence = json.loads(
    (fixture_root / "ocr-evidence.json").read_text(encoding="utf-8")
)
legacy_review = json.loads(
    (fixture_root / "review.json").read_text(encoding="utf-8")
)
legacy_counts = {}
for mode in ("UNRESOLVED_LAYOUT", "two_columns_with_reviewed_spanning_headers"):
    attacked = copy.deepcopy(legacy_evidence)
    for page in attacked["payload"]["pages"]:
        page["layout"]["mode"] = mode
    attacked["content_hash"] = digest(attacked["payload"])
    attacked_graph = offline.assemble(attacked)
    attacked_check = offline.quality_check(attacked, attacked_graph, legacy_review)
    legacy_counts[mode] = sum(
        issue["code"] == "UNRESOLVED_LAYOUT"
        for issue in attacked_check["payload"]["issues"]
    )
results["legacy_layout_issue_counts"] = legacy_counts
results["legacy_reviewed_mode_bypass"] = (
    legacy_counts["UNRESOLVED_LAYOUT"] > 0
    and legacy_counts["two_columns_with_reviewed_spanning_headers"] == 0
)

print(json.dumps(results, ensure_ascii=False, indent=2))

still_vulnerable = (
    results["forged_material_and_task_ids_accepted"]
    or any(value["accepted"] for value in results["graph_false_claims"].values())
    or any(value["accepted"] for value in results["check_false_claims"].values())
    or results["legacy_reviewed_mode_bypass"]
)
raise SystemExit(1 if still_vulnerable else 0)
