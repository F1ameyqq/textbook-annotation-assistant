"""Extended fail-open reproducer for viewer13 reviewed-layout patch v2.

Usage:
  python -X utf8 viewer13-v2-extended-adversarial-repro.py <patched-repo>

Exit 1 means at least one attack was accepted; exit 0 means all were rejected.
"""

from __future__ import annotations

import copy
import json
from pathlib import Path
import sys
import tempfile


repo = Path(sys.argv[1]).resolve()
sys.path[:0] = [str(repo / "src"), str(repo)]

from annotation.recognition import offline, pipeline_quality
from annotation.recognition.baseline import digest
from tests.test_viewer13_reviewed_layout import fixture


def audit_graph(evidence, graph, units):
    found = []
    pipeline_quality._graph_sources(
        evidence, graph, units, lambda code, **kwargs: found.append(code)
    )
    return found


def audit_quality(evidence, graph, check, review):
    found = []
    pipeline_quality._quality_bindings(
        evidence, graph, check, review,
        lambda code, **kwargs: found.append(code),
    )
    return found


results = {}
with tempfile.TemporaryDirectory() as temp:
    source_path, baseline, context, review = fixture(Path(temp))
    source = json.loads(source_path.read_text(encoding="utf-8"))
    evidence = offline.refine(source_path, baseline, context)
    graph = offline.assemble(evidence)
    check = offline.quality_check(evidence, graph, review)
    units = {
        line["line_id"]: (evidence["payload"]["pages"][0], line)
        for line in evidence["payload"]["pages"][0]["ocr_lines"]
    }

    context_attacks = {
        "printed_number_rebound": lambda value: (
            value["pages"]["viewer-13"]["reviewed_layout"]["groups"][0].update(
                printed_number="9"
            ),
            value["pages"]["viewer-13"]["reviewed_layout"]["groups"][1].update(
                printed_number="9:variant"
            ),
        ),
        "response_kind_promoted": lambda value: value["pages"]["viewer-13"][
            "reviewed_layout"
        ]["groups"][6].update(response_kind="HUMAN_GRADED"),
        "root_reference_quality_promoted": lambda value: value.update(
            reference_quality="HUMAN_VERIFIED"
        ),
        "root_provenance_promoted": lambda value: value.update(
            provenance="HUMAN APPROVED"
        ),
    }
    results["context_attacks"] = {}
    for name, mutate in context_attacks.items():
        attacked_context = copy.deepcopy(context)
        mutate(attacked_context)
        try:
            attacked_evidence = offline.refine(
                source_path, baseline, attacked_context
            )
            attacked_graph = offline.assemble(attacked_evidence)
            attacked_check = offline.quality_check(
                attacked_evidence, attacked_graph, review
            )
            source_issues = []
            attacked_units = pipeline_quality._source_evidence(
                attacked_evidence, source, attacked_context,
                lambda code, **kwargs: source_issues.append(code),
                source_path,
            )
            graph_issues = audit_graph(
                attacked_evidence, attacked_graph, attacked_units
            )
            quality_issues = audit_quality(
                attacked_evidence, attacked_graph, attacked_check, review
            )
            results["context_attacks"][name] = {
                "accepted": not source_issues and not graph_issues and not quality_issues,
                "source_issues": source_issues,
                "graph_issues": graph_issues,
                "quality_issues": quality_issues,
            }
        except Exception as exc:
            results["context_attacks"][name] = {
                "accepted": False,
                "producer_error": type(exc).__name__ + ": " + str(exc),
            }

    evidence_attacks = {
        "layout_verified_true": lambda value: value["payload"]["pages"][0][
            "layout"
        ].__setitem__("verified", True),
        "receipt_human_verified": lambda value: value["payload"]["pages"][0][
            "reviewed_layout_receipt"
        ].update(human_verified=True),
        "payload_human_verified": lambda value: value["payload"].update(
            human_verified=True
        ),
    }
    results["evidence_attacks"] = {}
    for name, mutate in evidence_attacks.items():
        attacked = copy.deepcopy(evidence)
        mutate(attacked)
        attacked["content_hash"] = digest(attacked["payload"])
        found = []
        pipeline_quality._source_evidence(
            attacked, source, context,
            lambda code, **kwargs: found.append(code),
            source_path,
        )
        results["evidence_attacks"][name] = {
            "accepted": not found,
            "issues": found,
        }

    graph_attacks = {
        "questions_reversed": lambda value: value["payload"]["questions"].reverse(),
        "tasks_reversed": lambda value: value["payload"]["shared_materials"][0][
            "tasks"
        ].reverse(),
        "type_candidate_approval": lambda value: value["payload"]["questions"][0].__setitem__(
            "type_candidate", {"question_type": "open_response", "human_verified": True}
        ),
        "material_asset_rebound": lambda value: (
            value["payload"]["shared_materials"][0].update(asset_id="forged-asset"),
            [
                task.update(asset_id="forged-asset")
                for task in value["payload"]["shared_materials"][0]["tasks"]
            ],
        ),
        "material_section_rebound": lambda value: value["payload"]["shared_materials"][0].update(
            section_path=["FORGED"]
        ),
        "matching_approval": lambda value: value["payload"].__setitem__(
            "matching", "HUMAN_APPROVED"
        ),
        "unmatched_answer_forged": lambda value: value["payload"].__setitem__(
            "unmatched_answer_ids", ["approved-answer"]
        ),
        "graph_issue_forged": lambda value: value["payload"].__setitem__(
            "issues", [{"code": "APPROVED"}]
        ),
    }
    results["graph_attacks"] = {}
    for name, mutate in graph_attacks.items():
        attacked = copy.deepcopy(graph)
        mutate(attacked)
        attacked["content_hash"] = digest(attacked["payload"])
        found = audit_graph(evidence, attacked, units)
        results["graph_attacks"][name] = {
            "accepted": not found,
            "issues": found,
        }

    check_attacks = {
        "reason_approval": lambda value: value["payload"].__setitem__(
            "reason", "APPROVED FOR PUBLISH"
        ),
        "summary_approval": lambda value: value["payload"]["summary"].update(
            accepted=True, business_acceptance=True
        ),
        "issues_made_nonblocking": lambda value: [
            issue.update(
                severity="INFO", blocks=[], suggested_strategy="AUTO_PUBLISH"
            )
            for issue in value["payload"]["issues"]
        ],
        "issue_nested_approval": lambda value: value["payload"]["issues"][0].update(
            accepted=True
        ),
    }
    results["check_attacks"] = {}
    for name, mutate in check_attacks.items():
        attacked = copy.deepcopy(check)
        mutate(attacked)
        attacked["content_hash"] = digest(attacked["payload"])
        found = audit_quality(evidence, graph, attacked, review)
        results["check_attacks"][name] = {
            "accepted": not found,
            "issues": found,
        }

    review_attacks = {
        "reference_quality_promoted": lambda value: value.update(
            reference_quality="HUMAN_VERIFIED"
        ),
        "provenance_promoted": lambda value: value.update(
            provenance="HUMAN APPROVED"
        ),
    }
    results["review_attacks"] = {}
    for name, mutate in review_attacks.items():
        attacked_review = copy.deepcopy(review)
        mutate(attacked_review)
        try:
            attacked_check = offline.quality_check(
                evidence, graph, attacked_review
            )
            found = audit_quality(
                evidence, graph, attacked_check, attacked_review
            )
            results["review_attacks"][name] = {
                "accepted": not found,
                "issues": found,
            }
        except Exception as exc:
            results["review_attacks"][name] = {
                "accepted": False,
                "producer_error": type(exc).__name__ + ": " + str(exc),
            }

print(json.dumps(results, ensure_ascii=False, indent=2))
accepted = [
    category + ":" + name
    for category, attacks in results.items()
    for name, result in attacks.items()
    if result.get("accepted")
]
raise SystemExit(1 if accepted else 0)
